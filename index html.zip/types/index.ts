export interface User {
  id: string;
  name: string;
  username: string;
  avatar: string;
  banner?: string;
  bio?: string;
  website?: string;
  followers: number;
  following: number;
  videos?: number;
  isVerified?: boolean;
  joinedAt: string;
}

export interface Video {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  videoUrl: string;
  duration: number; // in seconds
  views: number;
  likes: number;
  comments: number;
  createdAt: string;
  userId: string;
  user?: User;
  tags: string[];
  category: string;
  type: 'video' | 'reel' | 'stage'; // type of video content
  aspectRatio: number; // width/height
  isPremium?: boolean; // Flag to indicate if content requires premium subscription
}

export interface Photo {
  id: string;
  url: string;
  caption?: string;
  createdAt: string;
  userId: string;
  likes: number;
  location?: string;
  tags?: string[];
}

export interface Comment {
  id: string;
  text: string;
  userId: string;
  user?: User;
  videoId: string;
  likes: number;
  createdAt: string;
  replies?: Comment[];
}

export interface Notification {
  id: string;
  type: 'like' | 'comment' | 'follow' | 'mention' | 'collab' | 'system';
  userId: string; // user who triggered the notification
  targetId?: string; // video id, comment id, etc.
  message: string;
  read: boolean;
  createdAt: string;
  user?: User;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  color?: string;
}

export interface CollabRequest {
  id: string;
  senderId: string;
  receiverId: string;
  message: string;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: string;
  sender?: User;
  receiver?: User;
}

export interface Earnings {
  id: string;
  userId: string;
  amount: number;
  source: 'views' | 'tips' | 'sponsorship' | 'subscription';
  date: string;
}

export interface VideoAnalytics {
  videoId: string;
  views: number;
  watchTime: number; // in seconds
  completionRate: number; // percentage
  engagement: number; // likes + comments / views
  date: string;
}

export interface Playlist {
  id: string;
  title: string;
  description?: string;
  thumbnail: string;
  userId: string;
  videoIds: string[];
  createdAt: string;
  updatedAt: string;
  isPublic: boolean;
  viewCount: number;
}