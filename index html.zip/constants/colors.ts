const Colors = {
  primary: '#3B82F6', // Blue
  secondary: '#EF4444', // Red for Collab button
  background: '#FFFFFF',
  card: '#F9FAFB',
  text: '#1F2937',
  textLight: '#6B7280',
  textSecondary: '#6B7280', // Added for VideoCard
  textTertiary: '#9CA3AF', // Added for VideoCard
  border: '#E5E7EB',
  notification: '#EF4444',
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
  info: '#3B82F6',
  inactive: '#D1D5DB',
  premium: '#8B5CF6', // Added for premium content badge
  
  // Dark mode colors (if needed)
  darkBackground: '#121212',
  darkCard: '#1E1E1E',
  darkText: '#F9FAFB',
  darkTextLight: '#9CA3AF',
  darkTextSecondary: '#9CA3AF', // Added for dark mode
  darkTextTertiary: '#6B7280', // Added for dark mode
  darkBorder: '#2D2D2D',
};

export default Colors;