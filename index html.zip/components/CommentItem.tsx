import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { useRouter } from 'expo-router';
import { ThumbsUp, MessageCircle } from 'lucide-react-native';
import { Comment } from '@/types';
import Colors from '@/constants/colors';
import { formatTimeAgo } from '@/utils/format';

interface CommentItemProps {
  comment: Comment;
  isReply?: boolean;
}

const CommentItem: React.FC<CommentItemProps> = ({ comment, isReply = false }) => {
  const router = useRouter();
  const [liked, setLiked] = useState(false);
  const [showReplies, setShowReplies] = useState(false);
  
  const handleLike = () => {
    setLiked(!liked);
  };
  
  const handleUserPress = () => {
    router.push(`/profile/${comment.userId}`);
  };
  
  const handleToggleReplies = () => {
    setShowReplies(!showReplies);
  };
  
  return (
    <View style={[styles.container, isReply && styles.replyContainer]}>
      <TouchableOpacity onPress={handleUserPress}>
        <Image 
          source={{ uri: comment.user.avatar }} 
          style={styles.avatar} 
        />
      </TouchableOpacity>
      
      <View style={styles.contentContainer}>
        <View style={styles.headerContainer}>
          <TouchableOpacity onPress={handleUserPress}>
            <Text style={styles.username}>
              {comment.user.name}
              {comment.user.isVerified && ' ✓'}
            </Text>
          </TouchableOpacity>
          <Text style={styles.time}>{formatTimeAgo(comment.createdAt)}</Text>
        </View>
        
        <Text style={styles.commentText}>{comment.text}</Text>
        
        <View style={styles.actionsContainer}>
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={handleLike}
          >
            <ThumbsUp 
              size={16} 
              color={liked ? Colors.primary : Colors.textLight} 
              fill={liked ? Colors.primary : 'transparent'} 
            />
            <Text 
              style={[
                styles.actionText,
                liked && styles.likedText
              ]}
            >
              {comment.likes + (liked ? 1 : 0)}
            </Text>
          </TouchableOpacity>
          
          {comment.replies && comment.replies.length > 0 && (
            <TouchableOpacity 
              style={styles.actionButton}
              onPress={handleToggleReplies}
            >
              <MessageCircle size={16} color={Colors.textLight} />
              <Text style={styles.actionText}>
                {comment.replies.length} {comment.replies.length === 1 ? 'reply' : 'replies'}
              </Text>
            </TouchableOpacity>
          )}
        </View>
        
        {showReplies && comment.replies && comment.replies.length > 0 && (
          <View style={styles.repliesContainer}>
            {comment.replies.map((reply) => (
              <CommentItem 
                key={reply.id} 
                comment={reply} 
                isReply={true} 
              />
            ))}
          </View>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  replyContainer: {
    paddingLeft: 0,
    paddingVertical: 8,
    borderBottomWidth: 0,
  },
  avatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    marginRight: 12,
  },
  contentContainer: {
    flex: 1,
  },
  headerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  username: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.text,
  },
  time: {
    fontSize: 12,
    color: Colors.textLight,
  },
  commentText: {
    fontSize: 14,
    color: Colors.text,
    lineHeight: 20,
    marginBottom: 8,
  },
  actionsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16,
  },
  actionText: {
    fontSize: 12,
    color: Colors.textLight,
    marginLeft: 4,
  },
  likedText: {
    color: Colors.primary,
  },
  repliesContainer: {
    marginTop: 8,
    paddingLeft: 16,
    borderLeftWidth: 1,
    borderLeftColor: Colors.border,
  },
});

export default CommentItem;