import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Dimensions } from 'react-native';
import { useRouter } from 'expo-router';
import { Video } from '@/types';
import { formatDuration, formatNumber, formatTimeAgo } from '@/utils/format';
import Colors from '@/constants/colors';
import { Lock } from 'lucide-react-native';

interface VideoCardProps {
  video: Video;
  horizontal?: boolean;
  showChannel?: boolean;
}

const VideoCard: React.FC<VideoCardProps> = ({ 
  video, 
  horizontal = false,
  showChannel = true
}) => {
  const router = useRouter();
  const screenWidth = Dimensions.get('window').width;
  
  const handlePress = () => {
    router.push(`/video/${video.id}`);
  };
  
  const handleChannelPress = (e: any) => {
    e.stopPropagation();
    if (video.user) {
      router.push(`/profile/${video.user.id}`);
    }
  };
  
  if (horizontal) {
    return (
      <TouchableOpacity 
        style={styles.horizontalContainer} 
        onPress={handlePress}
        activeOpacity={0.8}
      >
        <View style={styles.horizontalThumbnailContainer}>
          <Image 
            source={{ uri: video.thumbnail }} 
            style={styles.horizontalThumbnail} 
          />
          <View style={styles.durationBadge}>
            <Text style={styles.durationText}>
              {formatDuration(video.duration)}
            </Text>
          </View>
          
          {video.isPremium && (
            <View style={styles.premiumBadge}>
              <Lock size={12} color="white" />
              <Text style={styles.premiumText}>PREMIUM</Text>
            </View>
          )}
        </View>
        
        <View style={styles.horizontalInfoContainer}>
          <Text 
            style={styles.horizontalTitle}
            numberOfLines={2}
          >
            {video.title}
          </Text>
          
          <Text style={styles.horizontalStats}>
            {formatNumber(video.views)} views • {formatTimeAgo(video.createdAt)}
          </Text>
          
          {showChannel && video.user && (
            <TouchableOpacity 
              style={styles.horizontalChannelContainer}
              onPress={handleChannelPress}
            >
              <Image 
                source={{ uri: video.user.avatar }} 
                style={styles.horizontalChannelAvatar} 
              />
              <Text style={styles.horizontalChannelName}>
                {video.user.name}
              </Text>
            </TouchableOpacity>
          )}
        </View>
      </TouchableOpacity>
    );
  }
  
  return (
    <TouchableOpacity 
      style={styles.container} 
      onPress={handlePress}
      activeOpacity={0.8}
    >
      <View style={styles.thumbnailContainer}>
        <Image 
          source={{ uri: video.thumbnail }} 
          style={styles.thumbnail} 
        />
        <View style={styles.durationBadge}>
          <Text style={styles.durationText}>
            {formatDuration(video.duration)}
          </Text>
        </View>
        
        {video.isPremium && (
          <View style={styles.premiumBadge}>
            <Lock size={12} color="white" />
            <Text style={styles.premiumText}>PREMIUM</Text>
          </View>
        )}
      </View>
      
      <View style={styles.infoContainer}>
        {video.user && (
          <TouchableOpacity 
            style={styles.channelAvatarContainer}
            onPress={handleChannelPress}
          >
            <Image 
              source={{ uri: video.user.avatar }} 
              style={styles.channelAvatar} 
            />
          </TouchableOpacity>
        )}
        
        <View style={styles.textContainer}>
          <Text 
            style={styles.title}
            numberOfLines={2}
          >
            {video.title}
          </Text>
          
          {video.user && (
            <TouchableOpacity onPress={handleChannelPress}>
              <Text style={styles.channelName}>
                {video.user.name}
              </Text>
            </TouchableOpacity>
          )}
          
          <Text style={styles.stats}>
            {formatNumber(video.views)} views • {formatTimeAgo(video.createdAt)}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
    paddingHorizontal: 0, // Removed horizontal padding to make videos full-width
  },
  thumbnailContainer: {
    width: '100%',
    aspectRatio: 16 / 9,
    backgroundColor: Colors.card,
    position: 'relative',
  },
  thumbnail: {
    width: '100%',
    height: '100%',
  },
  durationBadge: {
    position: 'absolute',
    bottom: 8,
    right: 8,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    paddingHorizontal: 4,
    paddingVertical: 2,
    borderRadius: 4,
  },
  durationText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '500',
  },
  infoContainer: {
    flexDirection: 'row',
    paddingTop: 10,
    paddingBottom: 4,
    paddingHorizontal: 12, // Added horizontal padding to the info section only
  },
  channelAvatarContainer: {
    marginRight: 12,
  },
  channelAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
  },
  textContainer: {
    flex: 1,
  },
  title: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 4,
    lineHeight: 20,
  },
  channelName: {
    fontSize: 13,
    color: Colors.textSecondary,
    marginBottom: 2,
  },
  stats: {
    fontSize: 12,
    color: Colors.textTertiary,
  },
  premiumBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: Colors.premium,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  premiumText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: '700',
  },
  // Horizontal styles
  horizontalContainer: {
    flexDirection: 'row',
    marginBottom: 16,
    height: 90,
    paddingHorizontal: 12,
  },
  horizontalThumbnailContainer: {
    width: 160,
    height: '100%',
    borderRadius: 8,
    overflow: 'hidden',
    backgroundColor: Colors.card,
    position: 'relative',
  },
  horizontalThumbnail: {
    width: '100%',
    height: '100%',
  },
  horizontalInfoContainer: {
    flex: 1,
    marginLeft: 12,
    justifyContent: 'space-between',
  },
  horizontalTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 4,
    lineHeight: 20,
  },
  horizontalStats: {
    fontSize: 12,
    color: Colors.textTertiary,
    marginBottom: 4,
  },
  horizontalChannelContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  horizontalChannelAvatar: {
    width: 20,
    height: 20,
    borderRadius: 10,
    marginRight: 8,
  },
  horizontalChannelName: {
    fontSize: 12,
    color: Colors.textSecondary,
  },
});

export default VideoCard;