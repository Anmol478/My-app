import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { useRouter } from 'expo-router';
import { Video } from '@/types';
import { formatNumber } from '@/utils/format';
import { Play } from 'lucide-react-native';
import Colors from '@/constants/colors';
import { useAppStore } from '@/store/app-store';

interface ReelCardProps {
  video: Video;
  fromProfile?: boolean;
}

const ReelCard: React.FC<ReelCardProps> = ({ video, fromProfile = false }) => {
  const router = useRouter();
  const { title, thumbnail, views } = video;
  const { setSelectedReel } = useAppStore();

  const handlePress = () => {
    if (fromProfile) {
      // Set the selected reel in the store and navigate to the reels tab
      setSelectedReel(video.id);
      router.push('/(tabs)/reels');
    } else {
      // Regular navigation to video detail
      router.push(`/video/${video.id}`);
    }
  };

  return (
    <TouchableOpacity 
      style={styles.container} 
      onPress={handlePress}
      activeOpacity={0.8}
    >
      <View style={styles.thumbnailContainer}>
        <Image source={{ uri: thumbnail }} style={styles.thumbnail} />
        <View style={styles.overlay}>
          <Play size={24} color="white" />
          <Text style={styles.viewsText}>{formatNumber(views)}</Text>
        </View>
      </View>
      <Text style={styles.title} numberOfLines={1}>{title}</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    width: '48%',
    marginBottom: 16,
  },
  thumbnailContainer: {
    width: '100%',
    aspectRatio: 9 / 16,
    borderRadius: 8,
    overflow: 'hidden',
    marginBottom: 8,
    position: 'relative',
  },
  thumbnail: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  overlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    padding: 8,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  viewsText: {
    color: 'white',
    fontSize: 12,
    fontWeight: '500',
  },
  title: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.text,
  },
});

export default ReelCard;