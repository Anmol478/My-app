import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Dimensions } from 'react-native';
import { useRouter } from 'expo-router';
import { Play, ListVideo } from 'lucide-react-native';
import { Playlist } from '@/types';
import { formatNumber } from '@/utils/format';
import Colors from '@/constants/colors';

interface PlaylistCardProps {
  playlist: Playlist;
  videoCount: number;
}

const { width } = Dimensions.get('window');
const cardWidth = (width - 48) / 2;

const PlaylistCard: React.FC<PlaylistCardProps> = ({ playlist, videoCount }) => {
  const router = useRouter();

  const handlePress = () => {
    router.push(`/playlist/${playlist.id}`);
  };

  return (
    <TouchableOpacity 
      style={styles.container}
      onPress={handlePress}
      activeOpacity={0.8}
    >
      <View style={styles.thumbnailContainer}>
        <Image 
          source={{ uri: playlist.thumbnail }} 
          style={styles.thumbnail}
        />
        <View style={styles.overlay}>
          <Play size={24} color="#fff" />
        </View>
        <View style={styles.countBadge}>
          <ListVideo size={12} color="#fff" />
          <Text style={styles.countText}>{videoCount}</Text>
        </View>
      </View>
      <View style={styles.infoContainer}>
        <Text style={styles.title} numberOfLines={2}>{playlist.title}</Text>
        <Text style={styles.viewCount}>{formatNumber(playlist.viewCount)} views</Text>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    width: cardWidth,
    marginBottom: 16,
  },
  thumbnailContainer: {
    width: '100%',
    height: cardWidth * 0.6,
    borderRadius: 8,
    overflow: 'hidden',
    position: 'relative',
  },
  thumbnail: {
    width: '100%',
    height: '100%',
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  countBadge: {
    position: 'absolute',
    bottom: 8,
    right: 8,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
    flexDirection: 'row',
    alignItems: 'center',
  },
  countText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '500',
    marginLeft: 4,
  },
  infoContainer: {
    paddingTop: 8,
  },
  title: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.text,
    marginBottom: 4,
  },
  viewCount: {
    fontSize: 12,
    color: Colors.textLight,
  },
});

export default PlaylistCard;