import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { DollarSign, TrendingUp, ArrowUpRight, ArrowDownRight, Users } from 'lucide-react-native';
import Colors from '@/constants/colors';
import { earnings } from '@/mocks/earnings';
import { EarningsData } from '@/types';

// Simple bar chart component
const BarChart = ({ 
  data, 
  maxValue, 
  barColor 
}: { 
  data: number[]; 
  maxValue: number; 
  barColor: string;
}) => {
  return (
    <View style={styles.chartContainer}>
      {data.map((value: number, index: number) => (
        <View key={index} style={styles.barContainer}>
          <View 
            style={[
              styles.bar, 
              { 
                height: `${(value / maxValue) * 100}%`,
                backgroundColor: barColor
              }
            ]} 
          />
        </View>
      ))}
    </View>
  );
};

const EarningsChart = () => {
  const [timeframe, setTimeframe] = useState<'week' | 'month' | 'year'>('month');
  
  const getEarningsData = (): EarningsData => {
    switch (timeframe) {
      case 'week':
        return earnings.weekly;
      case 'month':
        return earnings.monthly;
      case 'year':
        return earnings.yearly;
      default:
        return earnings.monthly;
    }
  };
  
  const earningsData = getEarningsData();
  const maxValue = Math.max(...earningsData.values);
  const totalEarnings = earningsData.values.reduce((sum, value) => sum + value, 0);
  const previousTotal = earningsData.previousTotal;
  const percentageChange = ((totalEarnings - previousTotal) / previousTotal) * 100;
  
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Earnings</Text>
        <View style={styles.timeframeSelector}>
          <TouchableOpacity
            style={[
              styles.timeframeButton,
              timeframe === 'week' && styles.activeTimeframeButton,
            ]}
            onPress={() => setTimeframe('week')}
          >
            <Text
              style={[
                styles.timeframeButtonText,
                timeframe === 'week' && styles.activeTimeframeButtonText,
              ]}
            >
              Week
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.timeframeButton,
              timeframe === 'month' && styles.activeTimeframeButton,
            ]}
            onPress={() => setTimeframe('month')}
          >
            <Text
              style={[
                styles.timeframeButtonText,
                timeframe === 'month' && styles.activeTimeframeButtonText,
              ]}
            >
              Month
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.timeframeButton,
              timeframe === 'year' && styles.activeTimeframeButton,
            ]}
            onPress={() => setTimeframe('year')}
          >
            <Text
              style={[
                styles.timeframeButtonText,
                timeframe === 'year' && styles.activeTimeframeButtonText,
              ]}
            >
              Year
            </Text>
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.earningsSummary}>
        <View style={styles.totalEarnings}>
          <Text style={styles.totalEarningsLabel}>Total Earnings</Text>
          <View style={styles.totalEarningsValue}>
            <DollarSign size={24} color={Colors.text} />
            <Text style={styles.totalEarningsAmount}>{totalEarnings.toFixed(2)}</Text>
          </View>
          <View style={styles.percentageChange}>
            {percentageChange >= 0 ? (
              <ArrowUpRight size={16} color={Colors.success} />
            ) : (
              <ArrowDownRight size={16} color={Colors.error} />
            )}
            <Text
              style={[
                styles.percentageChangeText,
                { color: percentageChange >= 0 ? Colors.success : Colors.error },
              ]}
            >
              {Math.abs(percentageChange).toFixed(1)}% from previous {timeframe}
            </Text>
          </View>
        </View>
      </View>
      
      <View style={styles.chartCard}>
        <Text style={styles.chartTitle}>
          {timeframe === 'week' ? 'Daily' : timeframe === 'month' ? 'Weekly' : 'Monthly'} Earnings
        </Text>
        <View style={styles.chartWrapper}>
          <BarChart 
            data={earningsData.values} 
            maxValue={maxValue} 
            barColor={Colors.primary} 
          />
          
          <View style={styles.chartLabels}>
            {earningsData.labels.map((label, index) => (
              <Text key={index} style={styles.chartLabel}>
                {label}
              </Text>
            ))}
          </View>
        </View>
      </View>
      
      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <View style={styles.statIconContainer}>
            <TrendingUp size={20} color={Colors.primary} />
          </View>
          <Text style={styles.statValue}>{earningsData.viewsRevenue.toFixed(2)}</Text>
          <Text style={styles.statLabel}>From Views</Text>
        </View>
        
        <View style={styles.statCard}>
          <View style={styles.statIconContainer}>
            <DollarSign size={20} color={Colors.primary} />
          </View>
          <Text style={styles.statValue}>{earningsData.tipsRevenue.toFixed(2)}</Text>
          <Text style={styles.statLabel}>From Tips</Text>
        </View>
        
        <View style={styles.statCard}>
          <View style={styles.statIconContainer}>
            <Users size={20} color={Colors.primary} />
          </View>
          <Text style={styles.statValue}>{earningsData.collabRevenue.toFixed(2)}</Text>
          <Text style={styles.statLabel}>From Collabs</Text>
        </View>
      </View>
      
      <View style={styles.payoutCard}>
        <Text style={styles.payoutTitle}>Next Payout</Text>
        <Text style={styles.payoutDate}>June 15, 2023</Text>
        <Text style={styles.payoutAmount}>${earningsData.nextPayout.toFixed(2)}</Text>
        <TouchableOpacity style={styles.payoutButton}>
          <Text style={styles.payoutButtonText}>View Payment History</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.text,
  },
  timeframeSelector: {
    flexDirection: 'row',
    backgroundColor: Colors.card,
    borderRadius: 20,
    padding: 2,
  },
  timeframeButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 18,
  },
  activeTimeframeButton: {
    backgroundColor: Colors.primary,
  },
  timeframeButtonText: {
    fontSize: 14,
    color: Colors.text,
  },
  activeTimeframeButtonText: {
    color: Colors.background,
    fontWeight: '500',
  },
  earningsSummary: {
    backgroundColor: Colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  totalEarnings: {
    alignItems: 'center',
  },
  totalEarningsLabel: {
    fontSize: 14,
    color: Colors.textLight,
    marginBottom: 8,
  },
  totalEarningsValue: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  totalEarningsAmount: {
    fontSize: 32,
    fontWeight: 'bold',
    color: Colors.text,
  },
  percentageChange: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  percentageChangeText: {
    fontSize: 14,
    marginLeft: 4,
  },
  chartCard: {
    backgroundColor: Colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  chartTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 16,
  },
  chartWrapper: {
    height: 200,
  },
  chartContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    height: 180,
  },
  barContainer: {
    flex: 1,
    height: '100%',
    justifyContent: 'flex-end',
    alignItems: 'center',
    paddingHorizontal: 2,
  },
  bar: {
    width: '80%',
    minHeight: 4,
    borderTopLeftRadius: 4,
    borderTopRightRadius: 4,
  },
  chartLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  chartLabel: {
    fontSize: 12,
    color: Colors.textLight,
    textAlign: 'center',
    flex: 1,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: Colors.card,
    borderRadius: 12,
    padding: 12,
    alignItems: 'center',
    marginHorizontal: 4,
  },
  statIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0, 119, 182, 0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  statValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: Colors.textLight,
  },
  payoutCard: {
    backgroundColor: Colors.card,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  payoutTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 8,
  },
  payoutDate: {
    fontSize: 14,
    color: Colors.textLight,
    marginBottom: 8,
  },
  payoutAmount: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.primary,
    marginBottom: 16,
  },
  payoutButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: Colors.primary,
    borderRadius: 20,
  },
  payoutButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.background,
  },
});

export default EarningsChart;