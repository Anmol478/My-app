import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image } from 'react-native';
import { Eye, ThumbsUp, MessageCircle, TrendingUp, TrendingDown } from 'lucide-react-native';
import Colors from '@/constants/colors';
import { formatNumber, formatTimeAgo } from '@/utils/format';
import { Video } from '@/types';

interface VideoAnalyticsProps {
  videos: Video[];
}

const VideoAnalytics: React.FC<VideoAnalyticsProps> = ({ videos }) => {
  const [sortBy, setSortBy] = useState('views');
  const [timeframe, setTimeframe] = useState('week');
  
  // Calculate total stats
  const totalViews = videos.reduce((sum, video) => sum + video.views, 0);
  const totalLikes = videos.reduce((sum, video) => sum + video.likes, 0);
  const totalComments = videos.reduce((sum, video) => sum + video.comments, 0);
  
  // Sort videos based on selected criteria
  const sortedVideos = [...videos].sort((a, b) => {
    if (sortBy === 'views') return b.views - a.views;
    if (sortBy === 'likes') return b.likes - a.likes;
    if (sortBy === 'comments') return b.comments - a.comments;
    if (sortBy === 'recent') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    return 0;
  });
  
  // Mock growth data
  const getGrowthData = () => {
    switch (timeframe) {
      case 'week':
        return {
          views: 12.5,
          likes: 8.3,
          comments: -2.1,
        };
      case 'month':
        return {
          views: 28.7,
          likes: 15.2,
          comments: 5.8,
        };
      case 'year':
        return {
          views: 142.3,
          likes: 87.5,
          comments: 63.9,
        };
      default:
        return {
          views: 0,
          likes: 0,
          comments: 0,
        };
    }
  };
  
  const growthData = getGrowthData();
  
  const renderVideoItem = ({ item }: { item: Video }) => {
    return (
      <TouchableOpacity style={styles.videoItem}>
        <Image source={{ uri: item.thumbnail }} style={styles.videoThumbnail} />
        
        <View style={styles.videoDetails}>
          <Text style={styles.videoTitle} numberOfLines={2}>{item.title}</Text>
          <Text style={styles.videoTimestamp}>{formatTimeAgo(item.createdAt)}</Text>
          
          <View style={styles.videoStats}>
            <View style={styles.videoStat}>
              <Eye size={14} color={Colors.textLight} />
              <Text style={styles.videoStatText}>{formatNumber(item.views)}</Text>
            </View>
            
            <View style={styles.videoStat}>
              <ThumbsUp size={14} color={Colors.textLight} />
              <Text style={styles.videoStatText}>{formatNumber(item.likes)}</Text>
            </View>
            
            <View style={styles.videoStat}>
              <MessageCircle size={14} color={Colors.textLight} />
              <Text style={styles.videoStatText}>{formatNumber(item.comments)}</Text>
            </View>
          </View>
        </View>
      </TouchableOpacity>
    );
  };
  
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Video Analytics</Text>
        <View style={styles.timeframeSelector}>
          <TouchableOpacity
            style={[
              styles.timeframeButton,
              timeframe === 'week' && styles.activeTimeframeButton,
            ]}
            onPress={() => setTimeframe('week')}
          >
            <Text
              style={[
                styles.timeframeButtonText,
                timeframe === 'week' && styles.activeTimeframeButtonText,
              ]}
            >
              Week
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.timeframeButton,
              timeframe === 'month' && styles.activeTimeframeButton,
            ]}
            onPress={() => setTimeframe('month')}
          >
            <Text
              style={[
                styles.timeframeButtonText,
                timeframe === 'month' && styles.activeTimeframeButtonText,
              ]}
            >
              Month
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.timeframeButton,
              timeframe === 'year' && styles.activeTimeframeButton,
            ]}
            onPress={() => setTimeframe('year')}
          >
            <Text
              style={[
                styles.timeframeButtonText,
                timeframe === 'year' && styles.activeTimeframeButtonText,
              ]}
            >
              Year
            </Text>
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <View style={styles.statHeader}>
            <Text style={styles.statTitle}>Views</Text>
            <View style={styles.growthIndicator}>
              {growthData.views >= 0 ? (
                <TrendingUp size={14} color={Colors.success} />
              ) : (
                <TrendingDown size={14} color={Colors.error} />
              )}
              <Text
                style={[
                  styles.growthText,
                  { color: growthData.views >= 0 ? Colors.success : Colors.error },
                ]}
              >
                {Math.abs(growthData.views).toFixed(1)}%
              </Text>
            </View>
          </View>
          <Text style={styles.statValue}>{formatNumber(totalViews)}</Text>
        </View>
        
        <View style={styles.statCard}>
          <View style={styles.statHeader}>
            <Text style={styles.statTitle}>Likes</Text>
            <View style={styles.growthIndicator}>
              {growthData.likes >= 0 ? (
                <TrendingUp size={14} color={Colors.success} />
              ) : (
                <TrendingDown size={14} color={Colors.error} />
              )}
              <Text
                style={[
                  styles.growthText,
                  { color: growthData.likes >= 0 ? Colors.success : Colors.error },
                ]}
              >
                {Math.abs(growthData.likes).toFixed(1)}%
              </Text>
            </View>
          </View>
          <Text style={styles.statValue}>{formatNumber(totalLikes)}</Text>
        </View>
        
        <View style={styles.statCard}>
          <View style={styles.statHeader}>
            <Text style={styles.statTitle}>Comments</Text>
            <View style={styles.growthIndicator}>
              {growthData.comments >= 0 ? (
                <TrendingUp size={14} color={Colors.success} />
              ) : (
                <TrendingDown size={14} color={Colors.error} />
              )}
              <Text
                style={[
                  styles.growthText,
                  { color: growthData.comments >= 0 ? Colors.success : Colors.error },
                ]}
              >
                {Math.abs(growthData.comments).toFixed(1)}%
              </Text>
            </View>
          </View>
          <Text style={styles.statValue}>{formatNumber(totalComments)}</Text>
        </View>
      </View>
      
      <View style={styles.videosSection}>
        <View style={styles.videosSectionHeader}>
          <Text style={styles.videosSectionTitle}>Your Videos</Text>
          <View style={styles.sortOptions}>
            <TouchableOpacity
              style={[
                styles.sortButton,
                sortBy === 'views' && styles.activeSortButton,
              ]}
              onPress={() => setSortBy('views')}
            >
              <Text
                style={[
                  styles.sortButtonText,
                  sortBy === 'views' && styles.activeSortButtonText,
                ]}
              >
                Views
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.sortButton,
                sortBy === 'likes' && styles.activeSortButton,
              ]}
              onPress={() => setSortBy('likes')}
            >
              <Text
                style={[
                  styles.sortButtonText,
                  sortBy === 'likes' && styles.activeSortButtonText,
                ]}
              >
                Likes
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.sortButton,
                sortBy === 'comments' && styles.activeSortButton,
              ]}
              onPress={() => setSortBy('comments')}
            >
              <Text
                style={[
                  styles.sortButtonText,
                  sortBy === 'comments' && styles.activeSortButtonText,
                ]}
              >
                Comments
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.sortButton,
                sortBy === 'recent' && styles.activeSortButton,
              ]}
              onPress={() => setSortBy('recent')}
            >
              <Text
                style={[
                  styles.sortButtonText,
                  sortBy === 'recent' && styles.activeSortButtonText,
                ]}
              >
                Recent
              </Text>
            </TouchableOpacity>
          </View>
        </View>
        
        <FlatList
          data={sortedVideos}
          keyExtractor={(item) => item.id}
          renderItem={renderVideoItem}
          scrollEnabled={false}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Text style={styles.emptyText}>No videos found</Text>
            </View>
          }
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.text,
  },
  timeframeSelector: {
    flexDirection: 'row',
    backgroundColor: Colors.card,
    borderRadius: 20,
    padding: 2,
  },
  timeframeButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 18,
  },
  activeTimeframeButton: {
    backgroundColor: Colors.primary,
  },
  timeframeButtonText: {
    fontSize: 14,
    color: Colors.text,
  },
  activeTimeframeButtonText: {
    color: Colors.background,
    fontWeight: '500',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: Colors.card,
    borderRadius: 12,
    padding: 12,
    marginHorizontal: 4,
  },
  statHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  statTitle: {
    fontSize: 14,
    color: Colors.textLight,
  },
  growthIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  growthText: {
    fontSize: 12,
    marginLeft: 2,
  },
  statValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
  },
  videosSection: {
    backgroundColor: Colors.card,
    borderRadius: 12,
    padding: 16,
  },
  videosSectionHeader: {
    marginBottom: 16,
  },
  videosSectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 12,
  },
  sortOptions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  sortButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: Colors.background,
  },
  activeSortButton: {
    backgroundColor: Colors.primary,
  },
  sortButtonText: {
    fontSize: 12,
    color: Colors.text,
  },
  activeSortButtonText: {
    color: Colors.background,
    fontWeight: '500',
  },
  videoItem: {
    flexDirection: 'row',
    marginBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
    paddingBottom: 16,
  },
  videoThumbnail: {
    width: 120,
    height: 68,
    borderRadius: 8,
    marginRight: 12,
  },
  videoDetails: {
    flex: 1,
    justifyContent: 'space-between',
  },
  videoTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.text,
    marginBottom: 4,
  },
  videoTimestamp: {
    fontSize: 12,
    color: Colors.textLight,
    marginBottom: 8,
  },
  videoStats: {
    flexDirection: 'row',
    gap: 12,
  },
  videoStat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  videoStatText: {
    fontSize: 12,
    color: Colors.textLight,
  },
  emptyContainer: {
    padding: 16,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 14,
    color: Colors.textLight,
  },
});

export default VideoAnalytics;