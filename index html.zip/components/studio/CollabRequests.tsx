import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image } from 'react-native';
import { Check, X, MessageCircle, Send } from 'lucide-react-native';
import Colors from '@/constants/colors';
import { formatTimeAgo } from '@/utils/format';

interface CollabRequest {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  message: string;
  timestamp: string;
  status: 'pending' | 'accepted' | 'declined';
  videoTitle: string;
}

// Mock collab requests data
const collabRequests: CollabRequest[] = [
  {
    id: '1',
    userId: '2',
    userName: 'Chris Hemsworth',
    userAvatar: 'https://images.unsplash.com/photo-1568602471122-7832951cc4c5',
    message: "I'd love to collaborate on an underwater photography tutorial. Let me know if you're interested!",
    timestamp: '2023-10-15T14:30:00Z',
    status: 'pending',
    videoTitle: 'Exploring the Great Barrier Reef',
  },
  {
    id: '2',
    userId: '3',
    userName: 'Zendaya',
    userAvatar: 'https://images.unsplash.com/photo-1531123897727-8f129e1688ce',
    message: "Would you like to join me for a live stream about marine conservation next week?",
    timestamp: '2023-10-14T09:15:00Z',
    status: 'pending',
    videoTitle: 'Ocean Conservation: How You Can Help',
  },
  {
    id: '3',
    userId: '4',
    userName: 'Tom Holland',
    userAvatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61',
    message: "Let's create a series about the Great Barrier Reef together. I have some amazing footage to share.",
    timestamp: '2023-10-12T18:45:00Z',
    status: 'accepted',
    videoTitle: 'Deep Sea Creatures You Won\'t Believe Exist',
  },
  {
    id: '4',
    userId: '5',
    userName: 'Margot Robbie',
    userAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2',
    message: "I saw your surfing videos and would love to feature you in my upcoming documentary about ocean sports.",
    timestamp: '2023-10-10T12:00:00Z',
    status: 'declined',
    videoTitle: 'Surfing the Biggest Waves in Hawaii',
  },
];

// Mock sent requests data
const sentRequests: CollabRequest[] = [
  {
    id: '5',
    userId: '6',
    userName: 'John Doe',
    userAvatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36',
    message: "I noticed your amazing underwater footage. Would you be interested in collaborating on a coral reef documentary?",
    timestamp: '2023-10-08T16:20:00Z',
    status: 'pending',
    videoTitle: 'Coral Reef Ecosystems',
  },
  {
    id: '6',
    userId: '7',
    userName: 'Jane Smith',
    userAvatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956',
    message: "Your marine biology knowledge would be perfect for my educational series. Let's collaborate!",
    timestamp: '2023-10-05T11:45:00Z',
    status: 'accepted',
    videoTitle: 'Marine Biology 101',
  },
];

const CollabRequests = () => {
  const [activeTab, setActiveTab] = useState<'received' | 'sent'>('received');
  const [requests, setRequests] = useState<CollabRequest[]>(collabRequests);
  const [sent, setSent] = useState<CollabRequest[]>(sentRequests);
  
  const handleAccept = (id: string) => {
    setRequests(requests.map(request => 
      request.id === id ? { ...request, status: 'accepted' } : request
    ));
  };
  
  const handleDecline = (id: string) => {
    setRequests(requests.map(request => 
      request.id === id ? { ...request, status: 'declined' } : request
    ));
  };
  
  const handleCancel = (id: string) => {
    setSent(sent.filter(request => request.id !== id));
  };
  
  const renderRequestItem = ({ item }: { item: CollabRequest }) => {
    return (
      <View style={styles.requestCard}>
        <View style={styles.requestHeader}>
          <View style={styles.userInfo}>
            <Image source={{ uri: item.userAvatar }} style={styles.userAvatar} />
            <View>
              <Text style={styles.userName}>{item.userName}</Text>
              <Text style={styles.timestamp}>{formatTimeAgo(item.timestamp)}</Text>
            </View>
          </View>
          
          {activeTab === 'received' ? (
            item.status === 'pending' ? (
              <View style={styles.actionButtons}>
                <TouchableOpacity 
                  style={[styles.actionButton, styles.acceptButton]}
                  onPress={() => handleAccept(item.id)}
                >
                  <Check size={16} color={Colors.background} />
                </TouchableOpacity>
                
                <TouchableOpacity 
                  style={[styles.actionButton, styles.declineButton]}
                  onPress={() => handleDecline(item.id)}
                >
                  <X size={16} color={Colors.background} />
                </TouchableOpacity>
              </View>
            ) : (
              <View style={[
                styles.statusBadge,
                item.status === 'accepted' ? styles.acceptedBadge : styles.declinedBadge
              ]}>
                <Text style={[
                  styles.statusText,
                  item.status === 'accepted' ? styles.acceptedText : styles.declinedText
                ]}>
                  {item.status === 'accepted' ? 'Accepted' : 'Declined'}
                </Text>
              </View>
            )
          ) : (
            item.status === 'pending' ? (
              <TouchableOpacity 
                style={[styles.actionButton, styles.cancelButton]}
                onPress={() => handleCancel(item.id)}
              >
                <X size={16} color={Colors.background} />
              </TouchableOpacity>
            ) : (
              <View style={[
                styles.statusBadge,
                item.status === 'accepted' ? styles.acceptedBadge : styles.declinedBadge
              ]}>
                <Text style={[
                  styles.statusText,
                  item.status === 'accepted' ? styles.acceptedText : styles.declinedText
                ]}>
                  {item.status === 'accepted' ? 'Accepted' : 'Declined'}
                </Text>
              </View>
            )
          )}
        </View>
        
        <Text style={styles.videoTitle}>For video: {item.videoTitle}</Text>
        <Text style={styles.message}>{item.message}</Text>
        
        {((activeTab === 'received' && item.status === 'accepted') || 
          (activeTab === 'sent' && item.status === 'accepted')) && (
          <View style={styles.buttonsContainer}>
            <TouchableOpacity style={styles.messageButton}>
              <MessageCircle size={16} color={Colors.background} />
              <Text style={styles.buttonText}>Message</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.detailsButton}>
              <Text style={styles.detailsButtonText}>View Details</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    );
  };
  
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Collaboration Requests</Text>
        <TouchableOpacity style={styles.newRequestButton}>
          <Send size={16} color={Colors.background} />
          <Text style={styles.newRequestButtonText}>New Request</Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.tabsContainer}>
        <TouchableOpacity
          style={[
            styles.tabItem,
            activeTab === 'received' && styles.activeTabItem,
          ]}
          onPress={() => setActiveTab('received')}
        >
          <Text
            style={[
              styles.tabText,
              activeTab === 'received' && styles.activeTabText,
            ]}
          >
            Received
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.tabItem,
            activeTab === 'sent' && styles.activeTabItem,
          ]}
          onPress={() => setActiveTab('sent')}
        >
          <Text
            style={[
              styles.tabText,
              activeTab === 'sent' && styles.activeTabText,
            ]}
          >
            Sent
          </Text>
        </TouchableOpacity>
      </View>
      
      <FlatList
        data={activeTab === 'received' ? requests : sent}
        keyExtractor={(item) => item.id}
        renderItem={renderRequestItem}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>
              {activeTab === 'received' 
                ? 'No collaboration requests received' 
                : 'No collaboration requests sent'
              }
            </Text>
          </View>
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.text,
  },
  newRequestButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: Colors.primary,
    borderRadius: 16,
    gap: 6,
  },
  newRequestButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.background,
  },
  tabsContainer: {
    flexDirection: 'row',
    backgroundColor: Colors.card,
    borderRadius: 8,
    marginBottom: 16,
    padding: 2,
  },
  tabItem: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: 6,
  },
  activeTabItem: {
    backgroundColor: Colors.primary,
  },
  tabText: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.text,
  },
  activeTabText: {
    color: Colors.background,
  },
  listContent: {
    gap: 16,
  },
  requestCard: {
    backgroundColor: Colors.card,
    borderRadius: 12,
    padding: 16,
  },
  requestHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  userAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 12,
  },
  userName: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 2,
  },
  timestamp: {
    fontSize: 12,
    color: Colors.textLight,
  },
  videoTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.primary,
    marginBottom: 8,
  },
  message: {
    fontSize: 14,
    color: Colors.text,
    marginBottom: 16,
    lineHeight: 20,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  actionButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  acceptButton: {
    backgroundColor: Colors.success,
  },
  declineButton: {
    backgroundColor: Colors.error,
  },
  cancelButton: {
    backgroundColor: Colors.error,
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  acceptedBadge: {
    backgroundColor: 'rgba(82, 196, 26, 0.1)',
    borderWidth: 1,
    borderColor: Colors.success,
  },
  declinedBadge: {
    backgroundColor: 'rgba(255, 77, 79, 0.1)',
    borderWidth: 1,
    borderColor: Colors.error,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '500',
  },
  acceptedText: {
    color: Colors.success,
  },
  declinedText: {
    color: Colors.error,
  },
  buttonsContainer: {
    flexDirection: 'row',
    gap: 12,
  },
  messageButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: Colors.primary,
    borderRadius: 20,
    gap: 6,
  },
  buttonText: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.background,
  },
  detailsButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  detailsButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.text,
  },
  emptyContainer: {
    padding: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyText: {
    fontSize: 14,
    color: Colors.textLight,
    textAlign: 'center',
  },
});

export default CollabRequests;