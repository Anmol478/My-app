import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Compass } from 'lucide-react-native';
import { categories } from '@/mocks/categories';
import { useAppStore } from '@/store/app-store';
import Colors from '@/constants/colors';

interface CategoryListProps {
  onExplorePress: () => void;
  isExploreActive: boolean;
}

const CategoryList: React.FC<CategoryListProps> = ({ onExplorePress, isExploreActive }) => {
  const { selectedCategory, setSelectedCategory } = useAppStore();
  
  const handleCategoryPress = (categoryName: string) => {
    setSelectedCategory(categoryName === selectedCategory ? null : categoryName);
  };
  
  return (
    <View style={styles.container}>
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* Explore option - now positioned to the left of All */}
        <TouchableOpacity 
          style={[
            styles.categoryItem,
            styles.exploreItem,
            isExploreActive && styles.selectedCategoryItem
          ]}
          onPress={onExplorePress}
        >
          <Compass size={16} color={isExploreActive ? Colors.background : Colors.text} />
          <Text 
            style={[
              styles.categoryText,
              isExploreActive && styles.selectedCategoryText
            ]}
          >
            Explore
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[
            styles.categoryItem, 
            !selectedCategory && styles.selectedCategoryItem
          ]}
          onPress={() => setSelectedCategory(null)}
        >
          <Text 
            style={[
              styles.categoryText,
              !selectedCategory && styles.selectedCategoryText
            ]}
          >
            All
          </Text>
        </TouchableOpacity>
        
        {categories.map((category) => (
          <TouchableOpacity 
            key={category.id}
            style={[
              styles.categoryItem,
              selectedCategory === category.name && styles.selectedCategoryItem
            ]}
            onPress={() => handleCategoryPress(category.name)}
          >
            <Text 
              style={[
                styles.categoryText,
                selectedCategory === category.name && styles.selectedCategoryText
              ]}
            >
              {category.name}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      
      <View style={styles.divider} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingVertical: 8,
    backgroundColor: Colors.background,
  },
  scrollContent: {
    paddingHorizontal: 12,
    gap: 8,
  },
  categoryItem: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: Colors.card,
    borderRadius: 16,
  },
  selectedCategoryItem: {
    backgroundColor: Colors.primary,
  },
  categoryText: {
    fontSize: 13,
    color: Colors.text,
    fontWeight: '500',
  },
  selectedCategoryText: {
    color: Colors.background,
  },
  exploreItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  divider: {
    height: 1,
    backgroundColor: Colors.border,
    marginTop: 12,
  },
});

export default CategoryList;