import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Platform } from 'react-native';
import { Play, Pause, Volume2, VolumeX, Maximize2 } from 'lucide-react-native';
import Colors from '@/constants/colors';
import { formatDuration } from '@/utils/format';

interface VideoPlayerProps {
  thumbnail?: string;
  thumbnailUri?: string;
  videoUri?: string;
  duration?: number;
  isPlaying?: boolean;
  onPlayPause?: () => void;
  onFullScreen?: () => void;
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({
  thumbnail,
  thumbnailUri,
  videoUri,
  duration = 0,
  isPlaying = false,
  onPlayPause,
  onFullScreen,
}) => {
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [showControls, setShowControls] = useState(true);
  const [controlsTimeout, setControlsTimeout] = useState<NodeJS.Timeout | null>(null);

  // Use either thumbnail or thumbnailUri, with thumbnailUri taking precedence
  const thumbnailSource = thumbnailUri || thumbnail;

  // Simulate progress for demo purposes
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying) {
      interval = setInterval(() => {
        setProgress((prev) => {
          const newProgress = prev + 0.005;
          if (newProgress >= 1) {
            clearInterval(interval);
            return 1;
          }
          return newProgress;
        });
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  // Auto-hide controls after a delay
  useEffect(() => {
    if (isPlaying && showControls) {
      if (controlsTimeout) {
        clearTimeout(controlsTimeout);
      }
      
      const timeout = setTimeout(() => {
        setShowControls(false);
      }, 3000);
      
      setControlsTimeout(timeout);
    }
    
    return () => {
      if (controlsTimeout) {
        clearTimeout(controlsTimeout);
      }
    };
  }, [isPlaying, showControls]);

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  const handleVideoPress = () => {
    if (showControls) {
      if (onPlayPause) {
        onPlayPause();
      }
    } else {
      setShowControls(true);
    }
  };

  const handleControlsPress = (e: any) => {
    // Prevent the touch event from bubbling up to the video press handler
    e.stopPropagation();
    
    // Reset the auto-hide timer
    if (controlsTimeout) {
      clearTimeout(controlsTimeout);
    }
    
    const timeout = setTimeout(() => {
      if (isPlaying) {
        setShowControls(false);
      }
    }, 3000);
    
    setControlsTimeout(timeout);
  };

  const currentTime = Math.floor(progress * duration);

  return (
    <View style={styles.container}>
      <TouchableOpacity 
        activeOpacity={1} 
        style={styles.videoContainer}
        onPress={handleVideoPress}
      >
        <Image source={{ uri: thumbnailSource }} style={styles.video} />
        
        {/* Play/Pause button overlay (only shown when paused) */}
        {!isPlaying && (
          <View style={styles.playPauseOverlay}>
            <View style={styles.playButton}>
              <Play size={24} color={Colors.background} fill={Colors.background} />
            </View>
          </View>
        )}
        
        {/* Controls overlay */}
        {showControls && (
          <View 
            style={styles.controlsOverlay}
            onTouchEnd={handleControlsPress}
          >
            <View style={styles.progressContainer}>
              <View style={styles.progressBarBackground}>
                <View style={[styles.progressBar, { width: `${progress * 100}%` }]} />
                <View 
                  style={[
                    styles.progressThumb, 
                    { left: `${progress * 100}%` }
                  ]} 
                />
              </View>
              <View style={styles.timeContainer}>
                <Text style={styles.timeText}>{formatDuration(currentTime)}</Text>
                <Text style={styles.timeText}>{formatDuration(duration)}</Text>
              </View>
            </View>
            
            <View style={styles.controlsRow}>
              <TouchableOpacity onPress={onPlayPause}>
                {isPlaying ? (
                  <Pause size={24} color={Colors.background} />
                ) : (
                  <Play size={24} color={Colors.background} />
                )}
              </TouchableOpacity>
              
              <TouchableOpacity onPress={toggleMute}>
                {isMuted ? (
                  <VolumeX size={24} color={Colors.background} />
                ) : (
                  <Volume2 size={24} color={Colors.background} />
                )}
              </TouchableOpacity>
              
              <View style={{ flex: 1 }} />
              
              <TouchableOpacity onPress={onFullScreen}>
                <Maximize2 size={24} color={Colors.background} />
              </TouchableOpacity>
            </View>
          </View>
        )}
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: '100%',
    aspectRatio: 16 / 9,
    backgroundColor: '#000',
    borderRadius: Platform.OS === 'web' ? 8 : 0,
    overflow: 'hidden',
    position: 'relative',
  },
  videoContainer: {
    width: '100%',
    height: '100%',
  },
  video: {
    width: '100%',
    height: '100%',
    position: 'absolute',
  },
  playPauseOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
  },
  playButton: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  controlsOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'flex-end',
    padding: 16,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
  },
  progressContainer: {
    marginBottom: 16,
  },
  progressBarBackground: {
    height: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderRadius: 2,
    position: 'relative',
  },
  progressBar: {
    height: '100%',
    backgroundColor: Colors.primary,
    borderRadius: 2,
  },
  progressThumb: {
    position: 'absolute',
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: Colors.primary,
    top: -4,
    marginLeft: -6,
  },
  timeContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  timeText: {
    color: Colors.background,
    fontSize: 12,
  },
  controlsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 20,
  },
});

export default VideoPlayer;