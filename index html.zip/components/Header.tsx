import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Modal, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { Bell, Search, MessageSquare, Tv, ArrowLeft } from 'lucide-react-native';
import Colors from '@/constants/colors';
import { useUserStore } from '@/store/user-store';

interface HeaderProps {
  showBackButton?: boolean;
  onBackPress?: () => void;
}

const Header: React.FC<HeaderProps> = ({ showBackButton = false, onBackPress }) => {
  const router = useRouter();
  const { currentUser } = useUserStore();
  const [tvLinkModalVisible, setTvLinkModalVisible] = useState(false);

  const handleSearchPress = () => {
    router.push('/search');
  };

  const handleNotificationsPress = () => {
    router.push('/notifications');
  };

  const handleMessagesPress = () => {
    router.push('/messages-hub');
  };

  const handleTvLinkPress = () => {
    setTvLinkModalVisible(true);
  };

  // Check if user follows anyone to determine whether to show notifications
  const showNotifications = currentUser?.following && currentUser.following > 0;

  return (
    <>
      <View style={styles.container}>
        {showBackButton ? (
          <TouchableOpacity onPress={onBackPress} style={styles.backButton}>
            <ArrowLeft size={22} color={Colors.text} />
          </TouchableOpacity>
        ) : (
          <View style={styles.logoContainer}>
            <Text style={styles.logoText}>Prosea</Text>
          </View>
        )}
        
        <View style={styles.actionsContainer}>
          <TouchableOpacity style={styles.iconButton} onPress={handleSearchPress}>
            <Search size={22} color={Colors.text} />
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.iconButton} onPress={handleTvLinkPress}>
            <Tv size={22} color={Colors.text} />
          </TouchableOpacity>
          
          {showNotifications && (
            <TouchableOpacity style={styles.iconButton} onPress={handleNotificationsPress}>
              <Bell size={22} color={Colors.text} />
            </TouchableOpacity>
          )}
          
          <TouchableOpacity style={styles.iconButton} onPress={handleMessagesPress}>
            <MessageSquare size={22} color={Colors.text} />
          </TouchableOpacity>
        </View>
      </View>

      {/* TV Link Modal */}
      <Modal
        animationType="fade"
        transparent={true}
        visible={tvLinkModalVisible}
        onRequestClose={() => setTvLinkModalVisible(false)}
      >
        <Pressable 
          style={styles.modalOverlay} 
          onPress={() => setTvLinkModalVisible(false)}
        >
          <View style={styles.modalContainer}>
            <Pressable style={styles.modalContent} onPress={(e) => e.stopPropagation()}>
              <Text style={styles.modalTitle}>Link with TV</Text>
              
              <TouchableOpacity style={styles.linkButton}>
                <Text style={styles.linkButtonText}>Scan QR Code</Text>
              </TouchableOpacity>
              
              <TouchableOpacity style={styles.linkButton}>
                <Text style={styles.linkButtonText}>Enter Code</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.learnMoreButton}
                onPress={() => {
                  setTvLinkModalVisible(false);
                  // Navigate to learn more page or show more info
                }}
              >
                <Text style={styles.learnMoreText}>Learn More</Text>
              </TouchableOpacity>
            </Pressable>
          </View>
        </Pressable>
      </Modal>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingVertical: 6, // Reduced from 10 to 6
    backgroundColor: Colors.background,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  logoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logoText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.primary,
  },
  backButton: {
    padding: 4,
  },
  actionsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  iconButton: {
    padding: 4,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    width: '80%',
    maxWidth: 300,
    backgroundColor: Colors.background,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  modalContent: {
    padding: 20,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 16,
    textAlign: 'center',
  },
  linkButton: {
    backgroundColor: Colors.primary,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginBottom: 12,
    alignItems: 'center',
  },
  linkButtonText: {
    color: Colors.background,
    fontSize: 16,
    fontWeight: '500',
  },
  learnMoreButton: {
    paddingVertical: 8,
    alignItems: 'center',
  },
  learnMoreText: {
    color: Colors.primary,
    fontSize: 14,
    fontWeight: '500',
  },
});

export default Header;