import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Linking, Share, Platform, Modal, TextInput } from 'react-native';
import { User } from '@/types';
import { Check, Bell, ExternalLink, Share2, X } from 'lucide-react-native';
import { useUserStore } from '@/store/user-store';
import { formatNumber } from '@/utils/format';
import Colors from '@/constants/colors';

interface UserProfileHeaderProps {
  user: User;
  isCurrentUser?: boolean;
  onEditProfile?: () => void;
  onCollab?: () => void;
}

const UserProfileHeader: React.FC<UserProfileHeaderProps> = ({
  user,
  isCurrentUser = false,
  onEditProfile,
  onCollab,
}) => {
  const { isUserFollowed, toggleFollowUser } = useUserStore();
  const isFollowing = isUserFollowed?.(user.id) || false;
  const [bioExpanded, setBioExpanded] = useState(false);
  const [collabModalVisible, setCollabModalVisible] = useState(false);
  const [collabMessage, setCollabMessage] = useState('');

  const handleFollowToggle = () => {
    if (toggleFollowUser) {
      toggleFollowUser(user.id);
    }
  };

  const handleWebsitePress = () => {
    if (user.website) {
      Linking.openURL(user.website);
    }
  };

  const handleShareProfile = async () => {
    try {
      const result = await Share.share({
        message: `Check out ${user.name}'s profile on ProSea: https://prosea.app/profile/${user.id}`,
        title: `${user.name}'s ProSea Profile`,
        url: Platform.OS === 'ios' ? `https://prosea.app/profile/${user.id}` : undefined,
      });
    } catch (error) {
      console.error('Error sharing profile:', error);
    }
  };

  const handleCollabPress = () => {
    if (onCollab) {
      onCollab();
    } else {
      setCollabModalVisible(true);
    }
  };

  const handleSendCollabRequest = () => {
    // Here you would send the collab request
    console.log('Sending collab request to:', user.name);
    console.log('Message:', collabMessage);
    
    // Close the modal and reset the message
    setCollabModalVisible(false);
    setCollabMessage('');
    
    // Show a success message or notification (in a real app)
  };

  const handleCloseModal = () => {
    setCollabModalVisible(false);
    setCollabMessage('');
  };

  return (
    <View style={styles.container}>
      {/* Banner Image */}
      <View style={styles.bannerContainer}>
        <Image 
          source={{ uri: user.banner || 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?q=80&w=2070&auto=format&fit=crop' }} 
          style={styles.banner} 
        />
      </View>
      
      {/* Profile Picture (centered, overlapping banner) */}
      <View style={styles.avatarContainer}>
        <Image 
          source={{ uri: user.avatar }} 
          style={styles.avatar} 
        />
      </View>
      
      <View style={styles.userInfo}>
        {/* Name and Verified Badge */}
        <View style={styles.nameContainer}>
          <Text style={styles.name}>{user.name}</Text>
          {user.isVerified && (
            <Check size={16} color={Colors.primary} style={styles.verifiedIcon} />
          )}
        </View>
        
        {/* Username */}
        <Text style={styles.username}>@{user.username}</Text>
        
        {/* Stats: Followers and Videos */}
        <View style={styles.statsContainer}>
          <Text style={styles.statValue}>{formatNumber(user.followers)}</Text>
          <Text style={styles.statLabel}>Followers</Text>
          
          <Text style={styles.statValue}>{formatNumber(user.videos || 0)}</Text>
          <Text style={styles.statLabel}>Videos</Text>
        </View>
        
        {/* Bio Section */}
        {user.bio && (
          <View style={styles.bioContainer}>
            <Text 
              style={styles.bioText} 
              numberOfLines={bioExpanded ? undefined : 2}
            >
              {user.bio}
            </Text>
            {user.bio.length > 80 && (
              <TouchableOpacity onPress={() => setBioExpanded(!bioExpanded)}>
                <Text style={styles.expandBioText}>
                  {bioExpanded ? 'Show less' : '...more'}
                </Text>
              </TouchableOpacity>
            )}
          </View>
        )}
        
        {/* Website/Link Section */}
        {user.website && (
          <TouchableOpacity 
            style={styles.websiteContainer}
            onPress={handleWebsitePress}
          >
            <ExternalLink size={14} color={Colors.primary} />
            <Text style={styles.websiteText}>{user.website}</Text>
          </TouchableOpacity>
        )}
      </View>
      
      {/* Action Buttons */}
      <View style={styles.actionsContainer}>
        {isCurrentUser ? (
          <View style={styles.currentUserActions}>
            <TouchableOpacity 
              style={styles.editProfileButton} 
              onPress={onEditProfile}
            >
              <Text style={styles.editProfileText}>Edit Profile</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.shareProfileButton}
              onPress={handleShareProfile}
            >
              <Share2 size={16} color={Colors.text} style={styles.shareIcon} />
              <Text style={styles.shareProfileText}>Share Profile</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.actionButtonsRow}>
            <TouchableOpacity 
              style={styles.followButton} 
              onPress={handleFollowToggle}
            >
              <Text style={styles.followButtonText}>
                {isFollowing ? 'Following' : 'Follow'}
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.collabButton}
              onPress={handleCollabPress}
            >
              <Text style={styles.collabButtonText}>Collab</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.shareProfileButton}
              onPress={handleShareProfile}
            >
              <Share2 size={16} color={Colors.text} />
            </TouchableOpacity>
            
            {isFollowing && (
              <TouchableOpacity style={styles.notificationButton}>
                <Bell size={20} color={Colors.text} />
              </TouchableOpacity>
            )}
          </View>
        )}
      </View>

      {/* Collab Request Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={collabModalVisible}
        onRequestClose={handleCloseModal}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Collaboration Request</Text>
              <TouchableOpacity onPress={handleCloseModal}>
                <X size={24} color={Colors.text} />
              </TouchableOpacity>
            </View>
            
            <Text style={styles.modalSubtitle}>
              Send a collaboration request to {user.name}
            </Text>
            
            <TextInput
              style={styles.messageInput}
              placeholder="Write your collaboration request..."
              placeholderTextColor={Colors.textLight}
              multiline
              numberOfLines={4}
              value={collabMessage}
              onChangeText={setCollabMessage}
            />
            
            <TouchableOpacity 
              style={[
                styles.sendButton,
                !collabMessage.trim() && styles.sendButtonDisabled
              ]}
              onPress={handleSendCollabRequest}
              disabled={!collabMessage.trim()}
            >
              <Text style={styles.sendButtonText}>Send Request</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.background,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  bannerContainer: {
    width: '100%',
    height: 150,
  },
  banner: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  avatarContainer: {
    marginTop: -40,
    borderWidth: 4,
    borderColor: Colors.background,
    borderRadius: 50,
    width: 80,
    height: 80,
    alignSelf: 'center',
  },
  avatar: {
    width: '100%',
    height: '100%',
    borderRadius: 40,
  },
  userInfo: {
    width: '100%',
    paddingHorizontal: 16,
    paddingTop: 12,
    alignItems: 'center',
  },
  nameContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  name: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.text,
    marginRight: 4,
  },
  verifiedIcon: {
    marginLeft: 4,
  },
  username: {
    fontSize: 14,
    color: Colors.textLight,
    marginBottom: 12,
  },
  statsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    gap: 24,
  },
  statValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.text,
    marginRight: 4,
  },
  statLabel: {
    fontSize: 14,
    color: Colors.textLight,
    marginRight: 24,
  },
  bioContainer: {
    marginBottom: 12,
    width: '100%',
  },
  bioText: {
    fontSize: 14,
    color: Colors.text,
    lineHeight: 20,
    textAlign: 'center',
  },
  expandBioText: {
    fontSize: 14,
    color: Colors.primary,
    marginTop: 4,
    textAlign: 'center',
  },
  websiteContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  websiteText: {
    fontSize: 14,
    color: Colors.primary,
    marginLeft: 6,
  },
  actionsContainer: {
    width: '100%',
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  currentUserActions: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  actionButtonsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  editProfileButton: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'center',
  },
  editProfileText: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.text,
  },
  shareProfileButton: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'center',
    flexDirection: 'row',
  },
  shareIcon: {
    marginRight: 6,
  },
  shareProfileText: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.text,
  },
  followButton: {
    paddingVertical: 10,
    paddingHorizontal: 32,
    borderRadius: 20,
    backgroundColor: Colors.primary,
    alignItems: 'center',
  },
  followButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.background,
  },
  collabButton: {
    paddingVertical: 10,
    paddingHorizontal: 32,
    borderRadius: 20,
    backgroundColor: '#E53935', // Red color for Collab button
    alignItems: 'center',
  },
  collabButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.background,
  },
  notificationButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  // Modal styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: '90%',
    backgroundColor: Colors.background,
    borderRadius: 12,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
  },
  modalSubtitle: {
    fontSize: 14,
    color: Colors.textLight,
    marginBottom: 16,
  },
  messageInput: {
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    padding: 12,
    height: 120,
    textAlignVertical: 'top',
    marginBottom: 16,
    color: Colors.text,
  },
  sendButton: {
    backgroundColor: Colors.primary,
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  sendButtonDisabled: {
    backgroundColor: Colors.border,
  },
  sendButtonText: {
    color: Colors.background,
    fontWeight: '600',
    fontSize: 16,
  },
});

export default UserProfileHeader;