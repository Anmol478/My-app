import React from 'react';
import { View, Text, StyleSheet, Modal, TouchableOpacity, Pressable } from 'react-native';
import Colors from '@/constants/colors';
import { useAppStore } from '@/store/app-store';

interface TvLinkModalProps {
  visible: boolean;
  onClose: () => void;
}

const TvLinkModal = ({ visible, onClose }: TvLinkModalProps) => {
  const { isTvLinked, linkTv, unlinkTv } = useAppStore();
  
  const handleScanQR = () => {
    // In a real app, this would open the camera to scan a QR code
    // For demo purposes, we'll just generate a random code
    const randomCode = Math.random().toString(36).substring(2, 8).toUpperCase();
    linkTv(randomCode);
    onClose();
  };
  
  const handleEnterCode = () => {
    // In a real app, this would open a screen to enter a code
    // For demo purposes, we'll just generate a random code
    const randomCode = Math.random().toString(36).substring(2, 8).toUpperCase();
    linkTv(randomCode);
    onClose();
  };
  
  const handleUnlink = () => {
    unlinkTv();
    onClose();
  };
  
  return (
    <Modal
      animationType="fade"
      transparent={true}
      visible={visible}
      onRequestClose={onClose}
    >
      <Pressable 
        style={styles.modalOverlay} 
        onPress={onClose}
      >
        <View style={styles.modalContainer}>
          <Pressable style={styles.modalContent} onPress={(e) => e.stopPropagation()}>
            <Text style={styles.modalTitle}>
              {isTvLinked ? 'TV Link Options' : 'Link with TV'}
            </Text>
            
            {!isTvLinked ? (
              <>
                <TouchableOpacity style={styles.linkButton} onPress={handleScanQR}>
                  <Text style={styles.linkButtonText}>Scan QR Code</Text>
                </TouchableOpacity>
                
                <TouchableOpacity style={styles.linkButton} onPress={handleEnterCode}>
                  <Text style={styles.linkButtonText}>Enter Code</Text>
                </TouchableOpacity>
              </>
            ) : (
              <>
                <Text style={styles.linkedText}>
                  Your TV is currently linked
                </Text>
                
                <TouchableOpacity style={styles.unlinkButton} onPress={handleUnlink}>
                  <Text style={styles.unlinkButtonText}>Unlink TV</Text>
                </TouchableOpacity>
              </>
            )}
            
            <TouchableOpacity 
              style={styles.learnMoreButton}
              onPress={() => {
                onClose();
                // Navigate to learn more page or show more info
              }}
            >
              <Text style={styles.learnMoreText}>Learn More</Text>
            </TouchableOpacity>
          </Pressable>
        </View>
      </Pressable>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    width: '80%',
    maxWidth: 300,
    backgroundColor: Colors.background,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  modalContent: {
    padding: 20,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 16,
    textAlign: 'center',
  },
  linkButton: {
    backgroundColor: Colors.primary,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginBottom: 12,
    alignItems: 'center',
  },
  linkButtonText: {
    color: Colors.background,
    fontSize: 16,
    fontWeight: '500',
  },
  linkedText: {
    fontSize: 16,
    color: Colors.text,
    textAlign: 'center',
    marginBottom: 16,
  },
  unlinkButton: {
    backgroundColor: Colors.error,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginBottom: 12,
    alignItems: 'center',
  },
  unlinkButtonText: {
    color: Colors.background,
    fontSize: 16,
    fontWeight: '500',
  },
  learnMoreButton: {
    paddingVertical: 8,
    alignItems: 'center',
  },
  learnMoreText: {
    color: Colors.primary,
    fontSize: 14,
    fontWeight: '500',
  },
});

export default TvLinkModal;