import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { usePathname, useRouter } from 'expo-router';
import { Home, Clapperboard, Plus, Theater, User } from 'lucide-react-native';
import Colors from '@/constants/colors';
import { BottomTabBarProps } from '@react-navigation/bottom-tabs';

// Add proper type definition for the component
const BottomTabBar = (props: BottomTabBarProps) => {
  const router = useRouter();
  const pathname = usePathname();

  const isActive = (path: string) => {
    return pathname === path;
  };

  const navigateTo = (path: string) => {
    router.push(path);
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={styles.tabItem}
        onPress={() => navigateTo('/')}
      >
        <Home
          size={22}
          color={isActive('/') ? Colors.primary : Colors.textLight}
          strokeWidth={isActive('/') ? 2.5 : 2}
        />
        <Text
          style={[
            styles.tabLabel,
            isActive('/') && styles.activeTabLabel,
          ]}
        >
          Home
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.tabItem}
        onPress={() => navigateTo('/reels')}
      >
        <Clapperboard
          size={22}
          color={isActive('/reels') ? Colors.primary : Colors.textLight}
          strokeWidth={isActive('/reels') ? 2.5 : 2}
        />
        <Text
          style={[
            styles.tabLabel,
            isActive('/reels') && styles.activeTabLabel,
          ]}
        >
          Reels
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.uploadButton}
        onPress={() => navigateTo('/upload')}
      >
        <Plus size={22} color={Colors.background} />
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.tabItem}
        onPress={() => navigateTo('/stage')}
      >
        <Theater
          size={22}
          color={isActive('/stage') ? Colors.primary : Colors.textLight}
          strokeWidth={isActive('/stage') ? 2.5 : 2}
        />
        <Text
          style={[
            styles.tabLabel,
            isActive('/stage') && styles.activeTabLabel,
          ]}
        >
          Stage
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.tabItem}
        onPress={() => navigateTo('/profile')}
      >
        <User
          size={22}
          color={isActive('/profile') ? Colors.primary : Colors.textLight}
          strokeWidth={isActive('/profile') ? 2.5 : 2}
        />
        <Text
          style={[
            styles.tabLabel,
            isActive('/profile') && styles.activeTabLabel,
          ]}
        >
          Profile
        </Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    height: 56,
    backgroundColor: Colors.background,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    paddingBottom: 4,
  },
  tabItem: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  uploadButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: -10,
  },
  tabLabel: {
    fontSize: 11,
    color: Colors.textLight,
    marginTop: 2,
  },
  activeTabLabel: {
    color: Colors.primary,
    fontWeight: '500',
  },
});

export default BottomTabBar;