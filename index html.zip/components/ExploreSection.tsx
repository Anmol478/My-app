import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Share, Linking } from 'react-native';
import { useRouter } from 'expo-router';
import { 
  ArrowLeft, 
  Hash, 
  Clock, 
  Image, 
  Award, 
  BarChart3, 
  Video, 
  Trophy,
  MessageSquare, 
  Share2, 
  Briefcase, 
  Crown,
  HelpCircle,
  Timer,
  Mail,
  ExternalLink,
  FileText,
  Users,
  Shield
} from 'lucide-react-native';
import Colors from '@/constants/colors';
import PremiumPlansSheet from './PremiumPlansSheet';

interface ExploreSectionProps {
  onBackPress: () => void;
}

interface ExploreItem {
  id: string;
  title: string;
  icon: React.ReactNode;
  expandable: boolean;
  buttonStyle?: boolean;
  premiumButton?: boolean;
  expandedContent?: React.ReactNode;
}

const ExploreSection: React.FC<ExploreSectionProps> = ({ onBackPress }) => {
  const router = useRouter();
  const [expandedItems, setExpandedItems] = useState<string[]>([]);
  const [showPremiumPlans, setShowPremiumPlans] = useState(false);

  const toggleItemExpansion = (id: string) => {
    if (expandedItems.includes(id)) {
      setExpandedItems(expandedItems.filter(itemId => itemId !== id));
    } else {
      setExpandedItems([...expandedItems, id]);
    }
  };

  const handleShare = async () => {
    try {
      await Share.share({
        message: "Check out Prosea - the platform for creators to share their content and earn rewards!",
        url: "https://prosea.app",
        title: "Share Prosea App"
      });
    } catch (error) {
      console.error("Error sharing:", error);
    }
  };

  const handleStudioPress = () => {
    router.push('/settings/studio');
  };

  const handlePremiumPress = () => {
    setShowPremiumPlans(true);
  };

  const handleHelpPress = () => {
    // Toggle expansion for help section
    toggleItemExpansion('help');
  };

  const handleTimeWatchedPress = () => {
    // Toggle expansion for time watched section
    if (exploreItems.find(item => item.id === 'timeWatched')?.expandable) {
      toggleItemExpansion('timeWatched');
    } else {
      console.log("Time Watched pressed");
      // You could implement: router.push('/time-watched');
    }
  };

  const handleSubscribe = (plan: string) => {
    console.log(`Subscribed to ${plan} plan`);
    setShowPremiumPlans(false);
    // Here you would implement the actual subscription logic
  };

  const handleOpenLink = (url: string) => {
    Linking.openURL(url).catch(err => console.error("Couldn't open link", err));
  };

  const exploreItems: ExploreItem[] = [
    {
      id: 'tips',
      title: 'Prosea Tips / Learn & Earn',
      icon: <Hash size={18} color={Colors.primary} />,
      expandable: true,
      expandedContent: (
        <View style={styles.expandedContent}>
          <TouchableOpacity style={styles.tipItem}>
            <Hash size={16} color={Colors.primary} />
            <Text style={styles.tipText}>Benefits of Hashtags</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.tipItem}>
            <Clock size={16} color={Colors.primary} />
            <Text style={styles.tipText}>Best Upload Timing</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.tipItem}>
            <Image size={16} color={Colors.primary} />
            <Text style={styles.tipText}>Thumbnail Tips</Text>
          </TouchableOpacity>
        </View>
      )
    },
    {
      id: 'rewards',
      title: 'Your Weekly Reward Summary',
      icon: <Award size={18} color={Colors.primary} />,
      expandable: true,
      expandedContent: (
        <View style={styles.expandedContent}>
          <Text style={styles.rewardTitle}>120 Points this Week</Text>
          <View style={styles.progressBarContainer}>
            <View style={styles.progressBar}>
              <View style={[styles.progressFill, { width: '60%' }]} />
            </View>
            <Text style={styles.progressText}>60% to next level</Text>
          </View>
          <TouchableOpacity style={styles.seeMoreButton}>
            <Text style={styles.seeMoreText}>See More</Text>
          </TouchableOpacity>
        </View>
      )
    },
    {
      id: 'features',
      title: 'Upcoming Features',
      icon: <BarChart3 size={18} color={Colors.primary} />,
      expandable: true,
      expandedContent: (
        <View style={styles.expandedContent}>
          <View style={styles.featureItem}>
            <Video size={16} color={Colors.primary} />
            <Text style={styles.featureText}>Live Room feature</Text>
          </View>
          <View style={styles.featureItem}>
            <Trophy size={16} color={Colors.primary} />
            <Text style={styles.featureText}>Creator leaderboard</Text>
          </View>
          <View style={styles.featureItem}>
            <MessageSquare size={16} color={Colors.primary} />
            <Text style={styles.featureText}>Collab-based ranking</Text>
          </View>
        </View>
      )
    },
    {
      id: 'feedback',
      title: 'Feedback',
      icon: <MessageSquare size={18} color={Colors.primary} />,
      expandable: true,
      expandedContent: (
        <View style={styles.expandedContent}>
          <Text style={styles.feedbackTitle}>Help us improve Prosea</Text>
          <TouchableOpacity style={styles.feedbackButton}>
            <Text style={styles.feedbackButtonText}>Send Feedback</Text>
          </TouchableOpacity>
        </View>
      )
    },
    {
      id: 'share',
      title: 'Share App',
      icon: <Share2 size={18} color={Colors.primary} />,
      expandable: false,
    },
    {
      id: 'help',
      title: 'Help',
      icon: <HelpCircle size={18} color={Colors.primary} />,
      expandable: true,
      expandedContent: (
        <View style={styles.expandedContent}>
          <Text style={styles.helpTitle}>How can we help you?</Text>
          
          <View style={styles.helpSection}>
            <Text style={styles.helpSectionTitle}>Frequently Asked Questions</Text>
            
            <TouchableOpacity style={styles.helpItem}>
              <FileText size={16} color={Colors.primary} />
              <Text style={styles.helpItemText}>How do I earn rewards?</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.helpItem}>
              <Users size={16} color={Colors.primary} />
              <Text style={styles.helpItemText}>How to collaborate with creators?</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.helpItem}>
              <Shield size={16} color={Colors.primary} />
              <Text style={styles.helpItemText}>Privacy and content guidelines</Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.helpSection}>
            <Text style={styles.helpSectionTitle}>Contact Support</Text>
            
            <TouchableOpacity 
              style={styles.helpItem}
              onPress={() => Linking.openURL('mailto:support@prosea.app')}
            >
              <Mail size={16} color={Colors.primary} />
              <Text style={styles.helpItemText}>Email: support@prosea.app</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.helpItem}>
              <MessageSquare size={16} color={Colors.primary} />
              <Text style={styles.helpItemText}>In-app chat support</Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.helpSection}>
            <Text style={styles.helpSectionTitle}>Resources</Text>
            
            <TouchableOpacity 
              style={styles.helpItem}
              onPress={() => handleOpenLink('https://prosea.app/help')}
            >
              <ExternalLink size={16} color={Colors.primary} />
              <Text style={styles.helpItemText}>Help Center</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.helpItem}
              onPress={() => handleOpenLink('https://prosea.app/tutorials')}
            >
              <Video size={16} color={Colors.primary} />
              <Text style={styles.helpItemText}>Video Tutorials</Text>
            </TouchableOpacity>
          </View>
          
          <TouchableOpacity 
            style={styles.helpButton}
            onPress={() => console.log("Navigate to full help center")}
          >
            <Text style={styles.helpButtonText}>Visit Help Center</Text>
          </TouchableOpacity>
        </View>
      )
    },
    {
      id: 'timeWatched',
      title: 'Time Watched',
      icon: <Timer size={18} color={Colors.primary} />,
      expandable: true,
      expandedContent: (
        <View style={styles.expandedContent}>
          <Text style={styles.timeWatchedTitle}>Your Viewing Stats</Text>
          <View style={styles.timeWatchedItem}>
            <Text style={styles.timeWatchedLabel}>Today:</Text>
            <Text style={styles.timeWatchedValue}>1h 23m</Text>
          </View>
          <View style={styles.timeWatchedItem}>
            <Text style={styles.timeWatchedLabel}>This Week:</Text>
            <Text style={styles.timeWatchedValue}>8h 45m</Text>
          </View>
          <View style={styles.timeWatchedItem}>
            <Text style={styles.timeWatchedLabel}>This Month:</Text>
            <Text style={styles.timeWatchedValue}>32h 10m</Text>
          </View>
          <TouchableOpacity style={styles.seeMoreButton}>
            <Text style={styles.seeMoreText}>View Detailed Stats</Text>
          </TouchableOpacity>
        </View>
      )
    },
    {
      id: 'studio',
      title: 'Studio',
      icon: <Briefcase size={18} color={Colors.background} />,
      expandable: false,
      buttonStyle: true,
    },
    {
      id: 'premium',
      title: 'Premium',
      icon: <Crown size={18} color={Colors.background} />,
      expandable: false,
      buttonStyle: true,
      premiumButton: true,
    },
  ];

  const handleItemPress = (item: ExploreItem) => {
    if (item.id === 'share') {
      handleShare();
    } else if (item.id === 'studio') {
      handleStudioPress();
    } else if (item.id === 'premium') {
      handlePremiumPress();
    } else if (item.id === 'help') {
      handleHelpPress();
    } else if (item.id === 'timeWatched') {
      handleTimeWatchedPress();
    } else if (item.expandable) {
      toggleItemExpansion(item.id);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBackPress} style={styles.backButton}>
          <ArrowLeft size={22} color={Colors.text} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Explore</Text>
      </View>

      <ScrollView 
        style={styles.scrollView} 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollViewContent}
      >
        {exploreItems.map((item) => (
          <View key={item.id}>
            <TouchableOpacity
              style={[
                styles.itemContainer,
                item.buttonStyle && styles.buttonItem,
                item.premiumButton && styles.premiumButton,
              ]}
              onPress={() => handleItemPress(item)}
            >
              <View style={styles.itemContent}>
                <View style={[
                  styles.iconContainer,
                  item.buttonStyle && styles.buttonIconContainer,
                  item.premiumButton && styles.premiumIconContainer,
                ]}>
                  {item.icon}
                </View>
                <Text style={[
                  styles.itemTitle,
                  item.buttonStyle && styles.buttonText,
                  item.premiumButton && styles.buttonText,
                ]}>
                  {item.title}
                </Text>
              </View>
              {item.expandable && (
                <Text style={styles.expandIcon}>
                  {expandedItems.includes(item.id) ? '−' : '+'}
                </Text>
              )}
            </TouchableOpacity>
            
            {item.expandable && expandedItems.includes(item.id) && item.expandedContent}
          </View>
        ))}
        
        {/* Add extra padding at the bottom to ensure all content is visible */}
        <View style={styles.bottomPadding} />
      </ScrollView>

      <PremiumPlansSheet 
        visible={showPremiumPlans} 
        onClose={() => setShowPremiumPlans(false)}
        onSubscribe={handleSubscribe}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  backButton: {
    marginRight: 10,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
  },
  scrollView: {
    flex: 1,
  },
  scrollViewContent: {
    paddingBottom: 100, // Add extra padding to ensure all content is visible
  },
  itemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  buttonItem: {
    backgroundColor: Colors.primary,
    marginHorizontal: 16,
    marginVertical: 8,
    borderRadius: 20,
    paddingVertical: 10,
    borderBottomWidth: 0,
  },
  premiumButton: {
    backgroundColor: '#F59E0B', // Gold/amber color for premium
    marginHorizontal: 16,
    marginVertical: 8,
    borderRadius: 20,
    paddingVertical: 10,
    borderBottomWidth: 0,
  },
  itemContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconContainer: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(59, 130, 246, 0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  buttonIconContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
  },
  premiumIconContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
  },
  itemTitle: {
    fontSize: 15,
    color: Colors.text,
    fontWeight: '500',
  },
  buttonText: {
    color: Colors.background,
    fontWeight: '600',
  },
  expandIcon: {
    fontSize: 18,
    color: Colors.textLight,
    fontWeight: 'bold',
  },
  expandedContent: {
    padding: 16,
    backgroundColor: Colors.card,
    marginHorizontal: 16,
    marginBottom: 8,
    borderRadius: 12,
  },
  tipItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    gap: 8,
  },
  tipText: {
    fontSize: 14,
    color: Colors.text,
  },
  rewardTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 8,
  },
  progressBarContainer: {
    marginVertical: 8,
  },
  progressBar: {
    height: 8,
    backgroundColor: Colors.inactive,
    borderRadius: 4,
    marginBottom: 4,
  },
  progressFill: {
    height: '100%',
    backgroundColor: Colors.primary,
    borderRadius: 4,
  },
  progressText: {
    fontSize: 12,
    color: Colors.textLight,
  },
  seeMoreButton: {
    alignSelf: 'flex-end',
    marginTop: 8,
  },
  seeMoreText: {
    fontSize: 14,
    color: Colors.primary,
    fontWeight: '500',
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    gap: 8,
  },
  featureText: {
    fontSize: 14,
    color: Colors.text,
  },
  feedbackTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 12,
  },
  feedbackButton: {
    backgroundColor: Colors.primary,
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 18,
    alignSelf: 'center',
  },
  feedbackButtonText: {
    color: Colors.background,
    fontWeight: '500',
    fontSize: 14,
  },
  timeWatchedTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 12,
  },
  timeWatchedItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 6,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.05)',
  },
  timeWatchedLabel: {
    fontSize: 14,
    color: Colors.text,
  },
  timeWatchedValue: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.primary,
  },
  // Help section styles
  helpTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 16,
  },
  helpSection: {
    marginBottom: 16,
  },
  helpSectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 8,
    paddingBottom: 4,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.05)',
  },
  helpItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    gap: 10,
  },
  helpItemText: {
    fontSize: 14,
    color: Colors.text,
    flex: 1,
  },
  helpButton: {
    backgroundColor: Colors.primary,
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 18,
    alignSelf: 'center',
    marginTop: 8,
  },
  helpButtonText: {
    color: Colors.background,
    fontWeight: '500',
    fontSize: 14,
  },
  bottomPadding: {
    height: 80, // Extra padding at the bottom
  },
});

export default ExploreSection;