import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Modal, ScrollView, Dimensions, Platform } from 'react-native';
import { X, Check, Crown } from 'lucide-react-native';
import Colors from '@/constants/colors';

interface PremiumPlansSheetProps {
  visible: boolean;
  onClose: () => void;
  onSubscribe: (plan: string) => void;
}

const { height } = Dimensions.get('window');

const PremiumPlansSheet: React.FC<PremiumPlansSheetProps> = ({ visible, onClose, onSubscribe }) => {
  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <View style={styles.overlay}>
        <View style={styles.container}>
          <View style={styles.header}>
            <Text style={styles.title}>Premium Plans</Text>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <X size={24} color={Colors.text} />
            </TouchableOpacity>
          </View>
          
          <ScrollView 
            style={styles.scrollView}
            contentContainerStyle={styles.scrollContent}
            showsVerticalScrollIndicator={false}
          >
            <View style={styles.iconContainer}>
              <Crown size={40} color="#F59E0B" />
            </View>
            
            <Text style={styles.subtitle}>Unlock Premium Features</Text>
            <Text style={styles.description}>
              Get access to exclusive features, remove ads, and support creators you love.
            </Text>
            
            <View style={styles.planCard}>
              <View style={styles.planHeader}>
                <Text style={styles.planTitle}>Monthly</Text>
                <View style={styles.priceBadge}>
                  <Text style={styles.priceText}>$4.99</Text>
                  <Text style={styles.periodText}>/month</Text>
                </View>
              </View>
              
              <View style={styles.benefitsList}>
                <View style={styles.benefitItem}>
                  <Check size={18} color={Colors.primary} />
                  <Text style={styles.benefitText}>Ad-free experience</Text>
                </View>
                <View style={styles.benefitItem}>
                  <Check size={18} color={Colors.primary} />
                  <Text style={styles.benefitText}>Unlimited downloads</Text>
                </View>
                <View style={styles.benefitItem}>
                  <Check size={18} color={Colors.primary} />
                  <Text style={styles.benefitText}>Background play</Text>
                </View>
                <View style={styles.benefitItem}>
                  <Check size={18} color={Colors.primary} />
                  <Text style={styles.benefitText}>Premium badge</Text>
                </View>
              </View>
              
              <TouchableOpacity 
                style={styles.subscribeButton}
                onPress={() => onSubscribe('monthly')}
              >
                <Text style={styles.subscribeText}>Subscribe</Text>
              </TouchableOpacity>
            </View>
            
            <View style={[styles.planCard, styles.bestValueCard]}>
              <View style={styles.bestValueBadge}>
                <Text style={styles.bestValueText}>BEST VALUE</Text>
              </View>
              
              <View style={styles.planHeader}>
                <Text style={styles.planTitle}>Annual</Text>
                <View style={styles.priceBadge}>
                  <Text style={styles.priceText}>$39.99</Text>
                  <Text style={styles.periodText}>/year</Text>
                </View>
                <Text style={styles.savingsText}>Save 33%</Text>
              </View>
              
              <View style={styles.benefitsList}>
                <View style={styles.benefitItem}>
                  <Check size={18} color={Colors.primary} />
                  <Text style={styles.benefitText}>Ad-free experience</Text>
                </View>
                <View style={styles.benefitItem}>
                  <Check size={18} color={Colors.primary} />
                  <Text style={styles.benefitText}>Unlimited downloads</Text>
                </View>
                <View style={styles.benefitItem}>
                  <Check size={18} color={Colors.primary} />
                  <Text style={styles.benefitText}>Background play</Text>
                </View>
                <View style={styles.benefitItem}>
                  <Check size={18} color={Colors.primary} />
                  <Text style={styles.benefitText}>Premium badge</Text>
                </View>
                <View style={styles.benefitItem}>
                  <Check size={18} color={Colors.primary} />
                  <Text style={styles.benefitText}>Priority support</Text>
                </View>
                <View style={styles.benefitItem}>
                  <Check size={18} color={Colors.primary} />
                  <Text style={styles.benefitText}>Early access to new features</Text>
                </View>
              </View>
              
              <TouchableOpacity 
                style={[styles.subscribeButton, styles.bestValueButton]}
                onPress={() => onSubscribe('annual')}
              >
                <Text style={styles.subscribeText}>Subscribe</Text>
              </TouchableOpacity>
            </View>
            
            <View style={styles.planCard}>
              <View style={styles.planHeader}>
                <Text style={styles.planTitle}>Lifetime</Text>
                <View style={styles.priceBadge}>
                  <Text style={styles.priceText}>$99.99</Text>
                  <Text style={styles.periodText}>one-time</Text>
                </View>
              </View>
              
              <View style={styles.benefitsList}>
                <View style={styles.benefitItem}>
                  <Check size={18} color={Colors.primary} />
                  <Text style={styles.benefitText}>All Premium features</Text>
                </View>
                <View style={styles.benefitItem}>
                  <Check size={18} color={Colors.primary} />
                  <Text style={styles.benefitText}>Pay once, use forever</Text>
                </View>
                <View style={styles.benefitItem}>
                  <Check size={18} color={Colors.primary} />
                  <Text style={styles.benefitText}>Exclusive lifetime badge</Text>
                </View>
                <View style={styles.benefitItem}>
                  <Check size={18} color={Colors.primary} />
                  <Text style={styles.benefitText}>VIP support</Text>
                </View>
              </View>
              
              <TouchableOpacity 
                style={styles.subscribeButton}
                onPress={() => onSubscribe('lifetime')}
              >
                <Text style={styles.subscribeText}>Get Lifetime</Text>
              </TouchableOpacity>
            </View>
            
            <Text style={styles.termsText}>
              By subscribing, you agree to our Terms of Service and Privacy Policy.
              Subscriptions automatically renew unless auto-renew is turned off at least 24 hours before the end of the current period.
            </Text>
            
            <View style={styles.bottomPadding} />
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  container: {
    backgroundColor: Colors.background,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: height * 0.9, // Limit height to 90% of screen
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 8,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
  },
  closeButton: {
    padding: 4,
  },
  scrollView: {
    // Remove fixed height to allow content to determine size
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: Platform.OS === 'ios' ? 40 : 24, // Extra padding for iOS
  },
  iconContainer: {
    alignItems: 'center',
    marginTop: 24,
    marginBottom: 16,
  },
  subtitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: Colors.text,
    textAlign: 'center',
    marginBottom: 8,
  },
  description: {
    fontSize: 16,
    color: Colors.textLight,
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 22,
  },
  planCard: {
    backgroundColor: Colors.card,
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  bestValueCard: {
    borderColor: '#F59E0B',
    borderWidth: 2,
    position: 'relative',
    paddingTop: 24,
  },
  bestValueBadge: {
    position: 'absolute',
    top: -12,
    left: '50%',
    transform: [{ translateX: -50 }],
    backgroundColor: '#F59E0B',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  bestValueText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 12,
  },
  planHeader: {
    marginBottom: 16,
  },
  planTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 8,
  },
  priceBadge: {
    flexDirection: 'row',
    alignItems: 'baseline',
  },
  priceText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.text,
  },
  periodText: {
    fontSize: 14,
    color: Colors.textLight,
    marginLeft: 4,
  },
  savingsText: {
    color: '#10B981',
    fontWeight: '600',
    marginTop: 4,
  },
  benefitsList: {
    marginBottom: 16,
  },
  benefitItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  benefitText: {
    fontSize: 14,
    color: Colors.text,
    marginLeft: 10,
  },
  subscribeButton: {
    backgroundColor: Colors.primary,
    borderRadius: 24,
    paddingVertical: 12,
    alignItems: 'center',
  },
  bestValueButton: {
    backgroundColor: '#F59E0B',
  },
  subscribeText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },
  termsText: {
    fontSize: 12,
    color: Colors.textLight,
    textAlign: 'center',
    marginTop: 8,
    marginBottom: 16,
    lineHeight: 18,
  },
  bottomPadding: {
    height: 20, // Extra padding at the bottom to ensure content is fully visible
  },
});

export default PremiumPlansSheet;