import { Category } from '@/types';

// Regular video categories
export const regularCategories: Category[] = [
  {
    id: '1',
    name: 'Travel',
    icon: 'map',
  },
  {
    id: '2',
    name: 'Education',
    icon: 'book-open',
  },
  {
    id: '3',
    name: 'Science',
    icon: 'flask-conical',
  },
  {
    id: '4',
    name: 'Sports',
    icon: 'trophy',
  },
  {
    id: '5',
    name: 'Food',
    icon: 'utensils',
  },
  {
    id: '6',
    name: 'Music',
    icon: 'music',
  },
  {
    id: '7',
    name: 'Gaming',
    icon: 'gamepad-2',
  },
  {
    id: '8',
    name: 'Technology',
    icon: 'cpu',
  },
  {
    id: '9',
    name: 'Comedy',
    icon: 'laugh',
  },
  {
    id: '10',
    name: 'Short Films',
    icon: 'clapperboard',
  },
  {
    id: '11',
    name: 'Theatre',
    icon: 'theater',
  },
  {
    id: '12',
    name: 'Vlogs',
    icon: 'video',
  },
];

// Stage video categories
export const stageCategories: Category[] = [
  {
    id: 's1',
    name: 'Drama',
    icon: 'theater',
  },
  {
    id: 's2',
    name: 'Theatre',
    icon: 'drama',
  },
  {
    id: 's3',
    name: 'Short Films',
    icon: 'clapperboard',
  },
  {
    id: 's4',
    name: 'Comedy',
    icon: 'laugh',
  },
  {
    id: 's5',
    name: 'Documentary',
    icon: 'film',
  },
];

// Export all categories
export const categories = regularCategories;