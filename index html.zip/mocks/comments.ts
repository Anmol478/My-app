import { Comment } from '@/types';
import { users } from './users';

export const comments: Comment[] = [
  {
    id: '1',
    text: "This video was incredibly helpful! I've been struggling with this concept for weeks, and your explanation finally made it click for me. Thank you!",
    createdAt: '2023-05-15T14:30:00Z',
    userId: '2',
    user: users[1],
    likes: 245,
    videoId: '1',
    replies: [
      {
        id: '1-1',
        text: "I'm so glad it helped you! Let me know if you have any other questions.",
        createdAt: '2023-05-15T15:10:00Z',
        userId: '1',
        user: users[0],
        likes: 32,
        videoId: '1',
      }
    ]
  },
  {
    id: '2',
    text: "Great content as always! Your production quality keeps getting better with each video. What camera are you using these days?",
    createdAt: '2023-05-16T09:45:00Z',
    userId: '3',
    user: users[2],
    likes: 178,
    videoId: '1',
  },
  {
    id: '3',
    text: "I tried this technique and it worked perfectly! Saved me hours of frustration. Would love to see a follow-up video on advanced techniques.",
    createdAt: '2023-05-17T11:20:00Z',
    userId: '4',
    user: users[3],
    likes: 156,
    videoId: '1',
  },
  {
    id: '4',
    text: "This is exactly what I needed for my project. Your explanations are always so clear and concise. Subscribed!",
    createdAt: '2023-05-18T16:05:00Z',
    userId: '5',
    user: users[4],
    likes: 92,
    videoId: '2',
  },
  {
    id: '5',
    text: "I've been following your channel for years and you never disappoint. The way you break down complex topics is unmatched!",
    createdAt: '2023-05-19T13:15:00Z',
    userId: '6',
    user: users[5],
    likes: 210,
    videoId: '2',
    replies: [
      {
        id: '5-1',
        text: "Thank you for your long-time support! It means a lot to me.",
        createdAt: '2023-05-19T14:00:00Z',
        userId: '1',
        user: users[0],
        likes: 45,
        videoId: '2',
      }
    ]
  },
  {
    id: '6',
    text: "I disagree with some points in this video. While your overall approach is good, there are more efficient methods that you didn't mention.",
    createdAt: '2023-05-20T10:30:00Z',
    userId: '7',
    user: users[6],
    likes: 28,
    videoId: '3',
  },
  {
    id: '7',
    text: "Can you please do a tutorial on how to integrate this with other systems? That would be super helpful for my current project.",
    createdAt: '2023-05-21T17:40:00Z',
    userId: '8',
    user: users[7],
    likes: 67,
    videoId: '3',
    replies: [
      {
        id: '7-1',
        text: "Great suggestion! I'll add it to my content calendar for next month.",
        createdAt: '2023-05-21T18:15:00Z',
        userId: '1',
        user: users[0],
        likes: 23,
        videoId: '3',
      }
    ]
  },
  {
    id: '8',
    text: "The audio quality in this video is not as good as your previous ones. Was this recorded with a different microphone?",
    createdAt: '2023-05-22T08:55:00Z',
    userId: '9',
    user: users[8],
    likes: 14,
    videoId: '4',
  },
  {
    id: '9',
    text: "I've implemented everything you suggested and my performance improved by 40%! You're a lifesaver!",
    createdAt: '2023-05-23T12:10:00Z',
    userId: '10',
    user: users[9],
    likes: 132,
    videoId: '4',
  },
  {
    id: '10',
    text: "This is by far the best explanation of this topic I've found online. You have a real talent for teaching complex subjects.",
    createdAt: '2023-05-24T15:25:00Z',
    userId: '2',
    user: users[1],
    likes: 189,
    videoId: '5',
  },
];