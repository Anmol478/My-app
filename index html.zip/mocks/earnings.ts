import { Earnings } from '@/types';

export const earnings: Earnings = {
  weekly: {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    values: [12.45, 18.32, 15.67, 22.89, 19.54, 28.76, 24.21],
    previousTotal: 125.84,
    viewsRevenue: 85.32,
    tipsRevenue: 42.50,
    collabRevenue: 14.02,
    nextPayout: 141.84,
  },
  monthly: {
    labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
    values: [98.76, 124.53, 142.87, 156.32],
    previousTotal: 452.48,
    viewsRevenue: 342.65,
    tipsRevenue: 128.75,
    collabRevenue: 51.08,
    nextPayout: 522.48,
  },
  yearly: {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    values: [425.32, 512.87, 487.65, 563.21, 598.76, 642.32, 687.54, 712.98, 745.32, 798.65, 832.43, 876.21],
    previousTotal: 6532.45,
    viewsRevenue: 5124.87,
    tipsRevenue: 1532.65,
    collabRevenue: 725.74,
    nextPayout: 876.21,
  },
};