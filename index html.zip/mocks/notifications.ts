import { Notification } from '@/types';

export const notifications: Notification[] = [
  {
    id: '1',
    type: 'like',
    message: 'Chris Hemsworth liked your video',
    read: false,
    createdAt: '2023-10-15T14:30:00Z',
    userId: '2',
    videoId: '1',
  },
  {
    id: '2',
    type: 'comment',
    message: 'Zendaya commented on your video',
    read: false,
    createdAt: '2023-10-14T09:15:00Z',
    userId: '3',
    videoId: '1',
    commentId: '1',
  },
  {
    id: '3',
    type: 'follow',
    message: 'Tom Holland started following you',
    read: true,
    createdAt: '2023-10-12T18:45:00Z',
    userId: '4',
  },
  {
    id: '4',
    type: 'collab',
    message: 'Margot Robbie sent you a collab request',
    read: true,
    createdAt: '2023-10-10T12:00:00Z',
    userId: '5',
  },
  {
    id: '5',
    type: 'like',
    message: 'John Doe liked your comment',
    read: true,
    createdAt: '2023-10-08T15:20:00Z',
    userId: '6',
    commentId: '2',
  },
];