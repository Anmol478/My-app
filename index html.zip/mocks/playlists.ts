import { Playlist } from '@/types';
import { videos } from './videos';

export const playlists: Playlist[] = [
  {
    id: 'pl1',
    title: 'Best Underwater Photography Tips',
    description: 'A collection of my best tutorials for underwater photography beginners and enthusiasts.',
    thumbnail: 'https://images.unsplash.com/photo-1682687982501-1e58ab814714?q=80&w=1000',
    userId: '1',
    videoIds: ['2', '12', 'r6', 's8'],
    createdAt: '2023-08-15T14:30:00Z',
    updatedAt: '2024-02-10T09:15:00Z',
    isPublic: true,
    viewCount: 24567
  },
  {
    id: 'pl2',
    title: 'Ocean Conservation Series',
    description: 'Learn about ocean conservation efforts and how you can help protect our marine ecosystems.',
    thumbnail: 'https://images.unsplash.com/photo-1621451537084-482c73073a0f?q=80&w=1000',
    userId: '1',
    videoIds: ['7', '17', 's5', 's15', 's18'],
    createdAt: '2023-09-22T10:45:00Z',
    updatedAt: '2024-03-05T16:30:00Z',
    isPublic: true,
    viewCount: 18932
  },
  {
    id: 'pl3',
    title: 'Travel Vlogs: Hidden Beaches',
    description: 'Discover the most beautiful hidden beaches around the world that most tourists never find.',
    thumbnail: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=1000',
    userId: '1',
    videoIds: ['1', '11', 'r1', 's7'],
    createdAt: '2023-10-10T08:20:00Z',
    updatedAt: '2024-01-15T11:45:00Z',
    isPublic: true,
    viewCount: 32145
  },
  {
    id: 'pl4',
    title: 'Diving Safety Essentials',
    description: 'Important safety tips and procedures every diver should know before going underwater.',
    thumbnail: 'https://images.unsplash.com/photo-1544551763-92ab472cad5d?q=80&w=1000',
    userId: '1',
    videoIds: ['8', '18', 'r9', 's19'],
    createdAt: '2023-11-05T15:10:00Z',
    updatedAt: '2024-02-28T09:30:00Z',
    isPublic: true,
    viewCount: 15678
  },
  {
    id: 'pl5',
    title: 'Marine Life Documentary Series',
    description: 'Fascinating documentaries about the incredible diversity of marine life in our oceans.',
    thumbnail: 'https://images.unsplash.com/photo-1551244072-5d12893278ab?q=80&w=1000',
    userId: '1',
    videoIds: ['3', '13', 'r7', 's11'],
    createdAt: '2023-12-18T13:25:00Z',
    updatedAt: '2024-03-10T14:50:00Z',
    isPublic: true,
    viewCount: 28943
  },
  {
    id: 'pl6',
    title: 'Behind the Scenes',
    description: 'Get a glimpse of what happens behind the camera during my underwater shoots and expeditions.',
    thumbnail: 'https://images.unsplash.com/photo-1559128010-7c1ad6e1b6a5?q=80&w=1000',
    userId: '1',
    videoIds: ['r2', 'r12', 's7', 's15'],
    createdAt: '2024-01-30T11:15:00Z',
    updatedAt: '2024-03-15T10:20:00Z',
    isPublic: true,
    viewCount: 12567
  },
  // Playlists for other users
  {
    id: 'pl7',
    title: 'Advanced Photography Techniques',
    description: 'Take your underwater photography to the next level with these advanced techniques.',
    thumbnail: 'https://images.unsplash.com/photo-1682687982501-1e58ab814714?q=80&w=1000',
    userId: '2',
    videoIds: ['2', '12', 'r6', 's8'],
    createdAt: '2023-10-05T09:30:00Z',
    updatedAt: '2024-02-15T14:20:00Z',
    isPublic: true,
    viewCount: 19876
  },
  {
    id: 'pl8',
    title: 'Ocean Science Explained',
    description: 'Fascinating scientific explanations about ocean phenomena and marine biology.',
    thumbnail: 'https://images.unsplash.com/photo-1551244072-5d12893278ab?q=80&w=1000',
    userId: '3',
    videoIds: ['3', '13', 'r7', 's11'],
    createdAt: '2023-11-12T16:45:00Z',
    updatedAt: '2024-01-20T10:15:00Z',
    isPublic: true,
    viewCount: 23456
  },
  {
    id: 'pl9',
    title: 'Pro Surfing Techniques',
    description: 'Learn from the pros with these surfing technique tutorials and demonstrations.',
    thumbnail: 'https://images.unsplash.com/photo-1502680390469-be75c86b636f?q=80&w=1000',
    userId: '4',
    videoIds: ['4', '14', 'r4', 's6'],
    createdAt: '2023-09-08T11:20:00Z',
    updatedAt: '2024-02-05T15:30:00Z',
    isPublic: true,
    viewCount: 31245
  },
  {
    id: 'pl10',
    title: 'Japanese Cuisine Masterclass',
    description: 'Master the art of Japanese cooking with these detailed tutorials and recipes.',
    thumbnail: 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?q=80&w=1000',
    userId: '5',
    videoIds: ['5', '15', 'r3', 'r13'],
    createdAt: '2023-10-25T14:15:00Z',
    updatedAt: '2024-03-01T09:45:00Z',
    isPublic: true,
    viewCount: 27654
  }
];

export const getPlaylistsByUser = (userId: string): Playlist[] => {
  return playlists.filter(playlist => playlist.userId === userId);
};

export const getPlaylistById = (id: string): Playlist | undefined => {
  return playlists.find(playlist => playlist.id === id);
};

export const getPlaylistVideos = (playlistId: string) => {
  const playlist = getPlaylistById(playlistId);
  if (!playlist) return [];
  
  return playlist.videoIds
    .map(videoId => videos.find(video => video.id === videoId))
    .filter(video => video !== undefined);
};