import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface AppState {
  hasSeenOnboarding: boolean;
  isDarkMode: boolean;
  isNotificationsEnabled: boolean;
  isAutoplayEnabled: boolean;
  selectedCategory: string | null;
  selectedVideoType: 'regular' | 'reel' | 'stage' | null;
  searchHistory: string[];
  isTvLinked: boolean;
  tvLinkCode: string | null;
  isPremium: boolean;
  premiumPlan: 'monthly' | 'quarterly' | 'yearly' | null;
  premiumExpiryDate: string | null;
  selectedReel: string | null;
  
  setHasSeenOnboarding: (value: boolean) => void;
  toggleDarkMode: () => void;
  toggleNotifications: () => void;
  toggleAutoplay: () => void;
  setSelectedCategory: (category: string | null) => void;
  setSelectedVideoType: (type: 'regular' | 'reel' | 'stage' | null) => void;
  addToSearchHistory: (query: string) => void;
  clearSearchHistory: () => void;
  linkTv: (code: string) => void;
  unlinkTv: () => void;
  subscribeToPremium: (plan: 'monthly' | 'quarterly' | 'yearly') => void;
  cancelPremium: () => void;
  setSelectedReel: (reelId: string | null) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      hasSeenOnboarding: false,
      isDarkMode: false,
      isNotificationsEnabled: true,
      isAutoplayEnabled: true,
      selectedCategory: null,
      selectedVideoType: null,
      searchHistory: [],
      isTvLinked: false,
      tvLinkCode: null,
      isPremium: false,
      premiumPlan: null,
      premiumExpiryDate: null,
      selectedReel: null,
      
      setHasSeenOnboarding: (value: boolean) => {
        set({ hasSeenOnboarding: value });
      },
      
      toggleDarkMode: () => {
        set({ isDarkMode: !get().isDarkMode });
      },
      
      toggleNotifications: () => {
        set({ isNotificationsEnabled: !get().isNotificationsEnabled });
      },
      
      toggleAutoplay: () => {
        set({ isAutoplayEnabled: !get().isAutoplayEnabled });
      },
      
      setSelectedCategory: (category: string | null) => {
        set({ selectedCategory: category });
      },
      
      setSelectedVideoType: (type: 'regular' | 'reel' | 'stage' | null) => {
        set({ selectedVideoType: type });
      },
      
      addToSearchHistory: (query: string) => {
        const { searchHistory } = get();
        // Don't add duplicates
        if (!searchHistory.includes(query)) {
          // Limit to 10 items
          const newHistory = [query, ...searchHistory].slice(0, 10);
          set({ searchHistory: newHistory });
        }
      },
      
      clearSearchHistory: () => {
        set({ searchHistory: [] });
      },
      
      linkTv: (code: string) => {
        set({ isTvLinked: true, tvLinkCode: code });
      },
      
      unlinkTv: () => {
        set({ isTvLinked: false, tvLinkCode: null });
      },
      
      subscribeToPremium: (plan: 'monthly' | 'quarterly' | 'yearly') => {
        // Calculate expiry date based on plan
        const now = new Date();
        let expiryDate = new Date();
        
        switch (plan) {
          case 'monthly':
            expiryDate.setMonth(now.getMonth() + 1);
            break;
          case 'quarterly':
            expiryDate.setMonth(now.getMonth() + 3);
            break;
          case 'yearly':
            expiryDate.setFullYear(now.getFullYear() + 1);
            break;
        }
        
        set({ 
          isPremium: true, 
          premiumPlan: plan,
          premiumExpiryDate: expiryDate.toISOString()
        });
      },
      
      cancelPremium: () => {
        set({ 
          isPremium: false, 
          premiumPlan: null,
          premiumExpiryDate: null
        });
      },
      
      setSelectedReel: (reelId: string | null) => {
        set({ selectedReel: reelId });
      },
    }),
    {
      name: 'prosea-app-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);