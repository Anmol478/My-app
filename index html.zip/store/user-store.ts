import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getCurrentUser } from '@/mocks/users';
import { Photo } from '@/types';

interface UserState {
  currentUser: ReturnType<typeof getCurrentUser> | null;
  likedVideos: string[];
  savedVideos: string[];
  downloadedVideos: string[];
  watchHistory: string[];
  followingUsers: string[];
  photos: Photo[];
  
  isVideoLiked: (videoId: string) => boolean;
  toggleLikeVideo: (videoId: string) => void;
  
  isVideoSaved: (videoId: string) => boolean;
  toggleSaveVideo: (videoId: string) => void;
  
  isVideoDownloaded: (videoId: string) => boolean;
  toggleDownloadVideo: (videoId: string) => void;
  removeFromDownloaded: (videoId: string) => void;
  
  addToWatchHistory: (videoId: string) => void;
  removeFromWatchHistory: (videoId: string) => void;
  clearWatchHistory: () => void;
  
  isUserFollowed: (userId: string) => boolean;
  toggleFollowUser: (userId: string) => void;
  
  // Add login and logout functions
  login: (user?: any) => void;
  logout: () => void;
}

// Sample photos for the user profile
const samplePhotos: Photo[] = [
  {
    id: 'p1',
    url: 'https://images.unsplash.com/photo-1546026423-cc4642628d2b?q=80&w=1000',
    caption: 'Beautiful coral reef in the Great Barrier Reef',
    createdAt: '2023-08-15T14:30:00Z',
    userId: '1',
    likes: 245,
  },
  {
    id: 'p2',
    url: 'https://images.unsplash.com/photo-1682687982501-1e58ab814714?q=80&w=1000',
    caption: 'Underwater photography session',
    createdAt: '2023-09-22T09:15:00Z',
    userId: '1',
    likes: 189,
  },
  {
    id: 'p3',
    url: 'https://images.unsplash.com/photo-1551244072-5d12893278ab?q=80&w=1000',
    caption: 'Deep sea exploration',
    createdAt: '2023-10-03T18:45:00Z',
    userId: '1',
    likes: 312,
  },
  {
    id: 'p4',
    url: 'https://images.unsplash.com/photo-1502680390469-be75c86b636f?q=80&w=1000',
    caption: 'Surfing in Hawaii',
    createdAt: '2023-11-10T12:00:00Z',
    userId: '1',
    likes: 278,
  },
  {
    id: 'p5',
    url: 'https://images.unsplash.com/photo-1559128010-7c1ad6e1b6a5?q=80&w=1000',
    caption: 'Sunset in Maldives',
    createdAt: '2023-12-05T15:20:00Z',
    userId: '1',
    likes: 423,
  },
  // Removed the 6th photo (p6 - Sailing adventure)
  {
    id: 'p7',
    url: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?q=80&w=1000',
    caption: 'Marine conservation efforts',
    createdAt: '2024-02-12T14:00:00Z',
    userId: '1',
    likes: 201,
  },
  {
    id: 'p8',
    url: 'https://images.unsplash.com/photo-1544551763-92ab472cad5d?q=80&w=1000',
    caption: 'Scuba diving expedition',
    createdAt: '2024-03-25T09:45:00Z',
    userId: '1',
    likes: 289,
  },
  {
    id: 'p9',
    url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=1000',
    caption: 'Hidden beach discovery',
    createdAt: '2024-04-05T11:20:00Z',
    userId: '1',
    likes: 345,
  },
];

export const useUserStore = create<UserState>()(
  persist(
    (set, get) => ({
      currentUser: getCurrentUser(),
      likedVideos: ['1', '3', '5', '7', '9', 'r2', 'r5', 's3'],
      savedVideos: ['2', '4', '6', '8', '10', 'r1', 'r3', 's1', 's5'],
      downloadedVideos: ['1', '3', '5', '7', 'r2', 'r4', 's2', 's4'],
      watchHistory: ['1', '2', '3', '4', '5', 'r1', 'r2', 's1', 's2'],
      followingUsers: ['2', '3', '5', '7'],
      photos: samplePhotos,
      
      isVideoLiked: (videoId: string) => {
        return get().likedVideos.includes(videoId);
      },
      
      toggleLikeVideo: (videoId: string) => {
        const { likedVideos } = get();
        if (likedVideos.includes(videoId)) {
          set({ likedVideos: likedVideos.filter(id => id !== videoId) });
        } else {
          set({ likedVideos: [...likedVideos, videoId] });
        }
      },
      
      isVideoSaved: (videoId: string) => {
        return get().savedVideos.includes(videoId);
      },
      
      toggleSaveVideo: (videoId: string) => {
        const { savedVideos } = get();
        if (savedVideos.includes(videoId)) {
          set({ savedVideos: savedVideos.filter(id => id !== videoId) });
        } else {
          set({ savedVideos: [...savedVideos, videoId] });
        }
      },
      
      isVideoDownloaded: (videoId: string) => {
        return get().downloadedVideos.includes(videoId);
      },
      
      toggleDownloadVideo: (videoId: string) => {
        const { downloadedVideos } = get();
        if (downloadedVideos.includes(videoId)) {
          set({ downloadedVideos: downloadedVideos.filter(id => id !== videoId) });
        } else {
          set({ downloadedVideos: [...downloadedVideos, videoId] });
        }
      },
      
      removeFromDownloaded: (videoId: string) => {
        const { downloadedVideos } = get();
        set({ downloadedVideos: downloadedVideos.filter(id => id !== videoId) });
      },
      
      addToWatchHistory: (videoId: string) => {
        const { watchHistory } = get();
        // Remove if already exists to move to the top
        const filteredHistory = watchHistory.filter(id => id !== videoId);
        set({ watchHistory: [videoId, ...filteredHistory] });
      },
      
      removeFromWatchHistory: (videoId: string) => {
        const { watchHistory } = get();
        set({ watchHistory: watchHistory.filter(id => id !== videoId) });
      },
      
      clearWatchHistory: () => {
        set({ watchHistory: [] });
      },
      
      isUserFollowed: (userId: string) => {
        return get().followingUsers.includes(userId);
      },
      
      toggleFollowUser: (userId: string) => {
        const { followingUsers } = get();
        if (followingUsers.includes(userId)) {
          set({ followingUsers: followingUsers.filter(id => id !== userId) });
        } else {
          set({ followingUsers: [...followingUsers, userId] });
        }
      },
      
      // Implement login and logout functions
      login: (user = null) => {
        // If a user is provided, use it, otherwise use the default user from getCurrentUser()
        set({ currentUser: user || getCurrentUser() });
      },
      
      logout: () => {
        set({ 
          currentUser: null,
          likedVideos: [],
          savedVideos: [],
          downloadedVideos: [],
          watchHistory: [],
          followingUsers: [],
          photos: [],
        });
      },
    }),
    {
      name: 'prosea-user-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);