import React from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useRouter } from 'expo-router';
import { Heart, MessageCircle, UserPlus, Users } from 'lucide-react-native';
import { notifications } from '@/mocks/notifications';
import { users } from '@/mocks/users';
import { formatTimeAgo } from '@/utils/format';
import Colors from '@/constants/colors';
import Header from '@/components/Header';

export default function NotificationsScreen() {
  const router = useRouter();
  
  const getIconForType = (type: string) => {
    switch (type) {
      case 'like':
        return <Heart size={20} color={Colors.error} />;
      case 'comment':
        return <MessageCircle size={20} color={Colors.primary} />;
      case 'follow':
        return <UserPlus size={20} color={Colors.success} />;
      case 'collab':
        return <Users size={20} color={Colors.warning} />;
      default:
        return null;
    }
  };
  
  const getUserById = (userId: string) => {
    return users.find(user => user.id === userId);
  };
  
  const renderNotificationItem = ({ item }) => {
    const user = getUserById(item.userId);
    
    return (
      <TouchableOpacity 
        style={[
          styles.notificationItem,
          !item.read && styles.unreadNotification,
        ]}
      >
        <View style={styles.iconContainer}>
          {getIconForType(item.type)}
        </View>
        
        <View style={styles.notificationContent}>
          <View style={styles.notificationHeader}>
            <Image source={{ uri: user?.avatar }} style={styles.userAvatar} />
            <Text style={styles.notificationText}>{item.message}</Text>
          </View>
          <Text style={styles.notificationTime}>{formatTimeAgo(item.createdAt)}</Text>
        </View>
      </TouchableOpacity>
    );
  };
  
  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar style="dark" />
      
      <Header showBackButton onBackPress={() => router.back()} />
      
      <FlatList
        data={notifications}
        keyExtractor={(item) => item.id}
        renderItem={renderNotificationItem}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={
          <View style={styles.listHeader}>
            <TouchableOpacity>
              <Text style={styles.markAllReadText}>Mark all as read</Text>
            </TouchableOpacity>
          </View>
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>No notifications yet</Text>
          </View>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  listHeader: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  markAllReadText: {
    fontSize: 14,
    color: Colors.primary,
  },
  notificationItem: {
    flexDirection: 'row',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  unreadNotification: {
    backgroundColor: 'rgba(0, 119, 182, 0.05)',
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.card,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  notificationContent: {
    flex: 1,
  },
  notificationHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  userAvatar: {
    width: 24,
    height: 24,
    borderRadius: 12,
    marginRight: 8,
  },
  notificationText: {
    flex: 1,
    fontSize: 14,
    color: Colors.text,
  },
  notificationTime: {
    fontSize: 12,
    color: Colors.textLight,
    marginLeft: 32,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 32,
  },
  emptyText: {
    fontSize: 16,
    color: Colors.textLight,
  },
});