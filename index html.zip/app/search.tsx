import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, FlatList, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useRouter } from 'expo-router';
import { Search as SearchIcon, X, Mic, History, TrendingUp } from 'lucide-react-native';
import VideoCard from '@/components/VideoCard';
import { videos } from '@/mocks/videos';
import { useAppStore } from '@/store/app-store';
import Colors from '@/constants/colors';
import Header from '@/components/Header';

export default function SearchScreen() {
  const router = useRouter();
  const { searchHistory, addToSearchHistory, clearSearchHistory } = useAppStore();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  
  const filteredVideos = searchQuery
    ? videos.filter(
        video =>
          video.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          video.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          video.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    : [];
  
  const handleSearch = () => {
    if (searchQuery.trim()) {
      setIsSearching(true);
      addToSearchHistory(searchQuery.trim());
    }
  };
  
  const handleClearSearch = () => {
    setSearchQuery('');
    setIsSearching(false);
  };
  
  const handleHistoryItemPress = (query: string) => {
    setSearchQuery(query);
    setIsSearching(true);
  };
  
  const trendingSearches = [
    'underwater photography',
    'marine life',
    'scuba diving',
    'great barrier reef',
    'ocean conservation',
  ];
  
  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar style="dark" />
      
      <Header showBackButton onBackPress={() => router.back()} />
      
      <View style={styles.searchContainer}>
        <View style={styles.searchInputContainer}>
          <SearchIcon size={20} color={Colors.textLight} style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search videos, channels..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            onSubmitEditing={handleSearch}
            autoFocus
            returnKeyType="search"
          />
          {searchQuery ? (
            <TouchableOpacity onPress={handleClearSearch}>
              <X size={20} color={Colors.textLight} />
            </TouchableOpacity>
          ) : (
            <TouchableOpacity>
              <Mic size={20} color={Colors.textLight} />
            </TouchableOpacity>
          )}
        </View>
      </View>
      
      {isSearching && filteredVideos.length > 0 ? (
        <FlatList
          data={filteredVideos}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => <VideoCard video={item} />}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.listContent}
        />
      ) : isSearching && filteredVideos.length === 0 ? (
        <View style={styles.noResultsContainer}>
          <Text style={styles.noResultsText}>No results found for "{searchQuery}"</Text>
          <Text style={styles.noResultsSubtext}>Try different keywords or check for typos</Text>
        </View>
      ) : (
        <View style={styles.suggestionsContainer}>
          {searchHistory.length > 0 && (
            <>
              <View style={styles.sectionHeader}>
                <View style={styles.sectionTitleContainer}>
                  <History size={16} color={Colors.textLight} />
                  <Text style={styles.sectionTitle}>Recent searches</Text>
                </View>
                <TouchableOpacity onPress={clearSearchHistory}>
                  <Text style={styles.clearText}>Clear</Text>
                </TouchableOpacity>
              </View>
              
              {searchHistory.map((query, index) => (
                <TouchableOpacity
                  key={`history-${index}`}
                  style={styles.suggestionItem}
                  onPress={() => handleHistoryItemPress(query)}
                >
                  <History size={16} color={Colors.textLight} />
                  <Text style={styles.suggestionText}>{query}</Text>
                </TouchableOpacity>
              ))}
              
              <View style={styles.divider} />
            </>
          )}
          
          <View style={styles.sectionHeader}>
            <View style={styles.sectionTitleContainer}>
              <TrendingUp size={16} color={Colors.textLight} />
              <Text style={styles.sectionTitle}>Trending searches</Text>
            </View>
          </View>
          
          {trendingSearches.map((query, index) => (
            <TouchableOpacity
              key={`trending-${index}`}
              style={styles.suggestionItem}
              onPress={() => handleHistoryItemPress(query)}
            >
              <TrendingUp size={16} color={Colors.textLight} />
              <Text style={styles.suggestionText}>{query}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  searchContainer: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  searchInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.card,
    borderRadius: 24,
    paddingHorizontal: 16,
    height: 48,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: Colors.text,
  },
  listContent: {
    padding: 16,
  },
  noResultsContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  noResultsText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 8,
    textAlign: 'center',
  },
  noResultsSubtext: {
    fontSize: 14,
    color: Colors.textLight,
    textAlign: 'center',
  },
  suggestionsContainer: {
    flex: 1,
    padding: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  sectionTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.text,
    marginLeft: 8,
  },
  clearText: {
    fontSize: 14,
    color: Colors.primary,
  },
  suggestionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
  },
  suggestionText: {
    fontSize: 16,
    color: Colors.text,
    marginLeft: 16,
  },
  divider: {
    height: 1,
    backgroundColor: Colors.border,
    marginVertical: 16,
  },
});