import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useRouter } from 'expo-router';
import { ArrowLeft, DollarSign, BarChart3, Users, Upload } from 'lucide-react-native';
import Colors from '@/constants/colors';
import EarningsChart from '@/components/studio/EarningsChart';
import VideoAnalytics from '@/components/studio/VideoAnalytics';
import CollabRequests from '@/components/studio/CollabRequests';
import { videos } from '@/mocks/videos';
import { useUserStore } from '@/store/user-store';

export default function CreatorStudioScreen() {
  const router = useRouter();
  const { currentUser } = useUserStore();
  const [activeTab, setActiveTab] = useState('earnings');
  
  const handleBack = () => {
    router.back();
  };
  
  const handleUpload = () => {
    router.push('/upload');
  };
  
  const renderTabContent = () => {
    switch (activeTab) {
      case 'earnings':
        return (
          <View style={styles.tabContent}>
            <EarningsChart />
          </View>
        );
      case 'analytics':
        return (
          <View style={styles.tabContent}>
            <VideoAnalytics videos={videos.filter(video => video.userId === currentUser?.id)} />
          </View>
        );
      case 'collabs':
        return (
          <View style={styles.tabContent}>
            <CollabRequests />
          </View>
        );
      default:
        return null;
    }
  };
  
  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar style="dark" />
      
      <View style={styles.header}>
        <TouchableOpacity onPress={handleBack}>
          <ArrowLeft size={24} color={Colors.text} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Creator Studio</Text>
        <TouchableOpacity onPress={handleUpload}>
          <Upload size={24} color={Colors.primary} />
        </TouchableOpacity>
      </View>
      
      <View style={styles.tabsContainer}>
        <TouchableOpacity
          style={[
            styles.tabItem,
            activeTab === 'earnings' && styles.activeTabItem,
          ]}
          onPress={() => setActiveTab('earnings')}
        >
          <DollarSign 
            size={20} 
            color={activeTab === 'earnings' ? Colors.primary : Colors.textLight} 
          />
          <Text
            style={[
              styles.tabText,
              activeTab === 'earnings' && styles.activeTabText,
            ]}
          >
            Earnings
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.tabItem,
            activeTab === 'analytics' && styles.activeTabItem,
          ]}
          onPress={() => setActiveTab('analytics')}
        >
          <BarChart3 
            size={20} 
            color={activeTab === 'analytics' ? Colors.primary : Colors.textLight} 
          />
          <Text
            style={[
              styles.tabText,
              activeTab === 'analytics' && styles.activeTabText,
            ]}
          >
            Analytics
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.tabItem,
            activeTab === 'collabs' && styles.activeTabItem,
          ]}
          onPress={() => setActiveTab('collabs')}
        >
          <Users 
            size={20} 
            color={activeTab === 'collabs' ? Colors.primary : Colors.textLight} 
          />
          <Text
            style={[
              styles.tabText,
              activeTab === 'collabs' && styles.activeTabText,
            ]}
          >
            Collabs
          </Text>
        </TouchableOpacity>
      </View>
      
      <ScrollView showsVerticalScrollIndicator={false}>
        {renderTabContent()}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
  },
  tabsContainer: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  tabItem: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    gap: 8,
  },
  activeTabItem: {
    borderBottomWidth: 2,
    borderBottomColor: Colors.primary,
  },
  tabText: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.textLight,
  },
  activeTabText: {
    color: Colors.primary,
  },
  tabContent: {
    padding: 16,
  },
});