import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, TextInput, Modal } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { ArrowLeft, Heart, Bookmark, Share2, Download, Flag, MessageCircle, ThumbsUp, ThumbsDown, Bell, BellOff, X, ChevronDown, ChevronUp, MoreHorizontal, Gift } from 'lucide-react-native';
import { videos } from '@/mocks/videos';
import { comments } from '@/mocks/comments';
import { useUserStore } from '@/store/user-store';
import VideoPlayer from '@/components/VideoPlayer';
import CommentItem from '@/components/CommentItem';
import VideoCard from '@/components/VideoCard';
import { formatNumber, formatTimeAgo } from '@/utils/format';
import Colors from '@/constants/colors';

export default function VideoScreen() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const { 
    isVideoLiked, 
    isVideoSaved, 
    isUserFollowed,
    toggleLikeVideo, 
    toggleSaveVideo, 
    toggleFollowUser,
    addToWatchHistory,
    toggleDownloadVideo
  } = useUserStore();
  
  const [collabModalVisible, setCollabModalVisible] = useState(false);
  const [collabMessage, setCollabMessage] = useState('');
  const [commentText, setCommentText] = useState('');
  const [showAllComments, setShowAllComments] = useState(false);
  const [showDescription, setShowDescription] = useState(false);
  
  // Gift modal state
  const [giftModalVisible, setGiftModalVisible] = useState(false);
  const [selectedAmount, setSelectedAmount] = useState(5);
  const giftAmounts = [1, 2, 5, 10, 20, 50, 100];
  
  // Find the video by ID
  const video = videos.find(v => v.id === id);
  
  // Get related videos (excluding current video)
  const relatedVideos = videos
    .filter(v => v.id !== id)
    .slice(0, 5);
  
  // Get video comments
  const videoComments = comments.filter(c => c.videoId === id);
  
  useEffect(() => {
    if (video) {
      // Add to watch history when video is viewed
      addToWatchHistory(video.id);
    }
  }, [video, addToWatchHistory]);
  
  if (!video) {
    return (
      <View style={styles.loadingContainer}>
        <Text>Video not found</Text>
      </View>
    );
  }
  
  const isLiked = isVideoLiked(video.id);
  const isSaved = isVideoSaved(video.id);
  const isUserFollowing = video.userId ? isUserFollowed(video.userId) : false;
  
  const handleBack = () => {
    router.back();
  };
  
  const handleLike = () => {
    toggleLikeVideo(video.id);
  };
  
  const handleSave = () => {
    toggleSaveVideo(video.id);
  };
  
  const handleDownload = () => {
    // This would normally download the video
    // For now we'll just add it to downloaded videos in the store
    toggleDownloadVideo(video.id);
  };
  
  const handleShare = () => {
    // Share functionality would go here
    console.log('Share video:', video.id);
  };
  
  const handleReport = () => {
    // Report functionality would go here
    console.log('Report video:', video.id);
  };
  
  const handleFollow = () => {
    if (video.userId) {
      toggleFollowUser(video.userId);
    }
  };
  
  const handleCollab = () => {
    setCollabModalVisible(true);
  };
  
  const handleGift = () => {
    setGiftModalVisible(true);
  };
  
  const handleSendGift = () => {
    // Here you would process the gift payment
    console.log(`Sending gift of $${selectedAmount} to ${video.user?.name}`);
    
    // Close the modal
    setGiftModalVisible(false);
    
    // Show a success message or notification
  };
  
  const handleSendCollabRequest = () => {
    // Here you would send the collab request
    console.log('Sending collab request:', collabMessage);
    
    // Close the modal and reset the message
    setCollabModalVisible(false);
    setCollabMessage('');
    
    // Show a success message or notification
  };
  
  const handleCloseModal = () => {
    setCollabModalVisible(false);
    setCollabMessage('');
  };
  
  const handleCloseGiftModal = () => {
    setGiftModalVisible(false);
  };
  
  const handleSubmitComment = () => {
    if (commentText.trim()) {
      // Here you would submit the comment
      console.log('Submitting comment:', commentText);
      
      // Reset the comment text
      setCommentText('');
    }
  };
  
  const handleCreatorProfile = () => {
    if (video.userId) {
      router.push(`/profile/${video.userId}`);
    }
  };

  const toggleCommentsVisibility = () => {
    setShowAllComments(!showAllComments);
  };

  const toggleDescription = () => {
    setShowDescription(!showDescription);
  };
  
  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar style="dark" />
      
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={handleBack}>
          <ArrowLeft size={24} color={Colors.text} />
        </TouchableOpacity>
        <View style={{ width: 24 }} />
      </View>
      
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Video Player */}
        <VideoPlayer 
          thumbnailUri={video.thumbnail}
          duration={video.duration}
        />
        
        {/* Video Info */}
        <View style={styles.videoInfo}>
          <Text style={styles.videoTitle}>{video.title}</Text>
          
          <View style={styles.videoStatsRow}>
            <Text style={styles.videoStats}>
              {formatNumber(video.views)} views • {formatTimeAgo(video.createdAt)}
            </Text>
            <TouchableOpacity onPress={toggleDescription}>
              <Text style={styles.moreButton}>More</Text>
            </TouchableOpacity>
          </View>
          
          {/* Description (collapsible) */}
          {showDescription && video.description && (
            <View style={styles.descriptionContainer}>
              <Text style={styles.description}>{video.description}</Text>
            </View>
          )}
          
          {/* Action Buttons */}
          <View style={styles.actionButtons}>
            <TouchableOpacity 
              style={styles.actionButton}
              onPress={handleLike}
            >
              <Heart 
                size={24} 
                color={isLiked ? Colors.secondary : Colors.text} 
                fill={isLiked ? Colors.secondary : 'transparent'} 
              />
              <Text 
                style={[
                  styles.actionButtonText,
                  isLiked && styles.actionButtonTextActive
                ]}
              >
                {formatNumber(video.likes)}
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.actionButton}
              onPress={handleSave}
            >
              <Bookmark 
                size={24} 
                color={isSaved ? Colors.primary : Colors.text} 
                fill={isSaved ? Colors.primary : 'transparent'} 
              />
              <Text 
                style={[
                  styles.actionButtonText,
                  isSaved && styles.actionButtonTextActive
                ]}
              >
                Save
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.actionButton}
              onPress={handleShare}
            >
              <Share2 size={24} color={Colors.text} />
              <Text style={styles.actionButtonText}>Share</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.actionButton}
              onPress={handleDownload}
            >
              <Download size={24} color={Colors.text} />
              <Text style={styles.actionButtonText}>Download</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.actionButton}
              onPress={handleGift}
            >
              <Gift size={24} color={Colors.text} />
              <Text style={styles.actionButtonText}>Gift</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.actionButton}
              onPress={handleReport}
            >
              <Flag size={24} color={Colors.text} />
              <Text style={styles.actionButtonText}>Report</Text>
            </TouchableOpacity>
          </View>
        </View>
        
        {/* Creator Info */}
        {video.user && (
          <View style={styles.creatorContainer}>
            <TouchableOpacity 
              style={styles.creatorInfo}
              onPress={handleCreatorProfile}
            >
              <Image 
                source={{ uri: video.user.avatar }} 
                style={styles.creatorAvatar} 
              />
              <View style={styles.creatorTextContainer}>
                <Text style={styles.creatorName}>{video.user.name}</Text>
                <Text style={styles.creatorFollowers}>
                  {formatNumber(video.user.followers)} followers
                </Text>
              </View>
            </TouchableOpacity>
            
            <View style={styles.creatorActions}>
              <TouchableOpacity 
                style={[
                  styles.followButton,
                  isUserFollowing && styles.followingButton
                ]}
                onPress={handleFollow}
              >
                <Text 
                  style={[
                    styles.followButtonText,
                    isUserFollowing && styles.followingButtonText
                  ]}
                >
                  {isUserFollowing ? 'Following' : 'Follow'}
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.collabButton}
                onPress={handleCollab}
              >
                <Text style={styles.collabButtonText}>Collab</Text>
              </TouchableOpacity>
              
              {isUserFollowing && (
                <TouchableOpacity style={styles.bellButton}>
                  <Bell size={20} color={Colors.text} />
                </TouchableOpacity>
              )}
            </View>
          </View>
        )}
        
        {/* Comments Section */}
        <View style={styles.commentsContainer}>
          <TouchableOpacity 
            style={styles.commentsHeader}
            onPress={toggleCommentsVisibility}
          >
            <Text style={styles.commentsTitle}>
              Comments ({videoComments.length})
            </Text>
            {videoComments.length > 1 && (
              <View style={styles.commentsToggle}>
                {showAllComments ? (
                  <ChevronUp size={20} color={Colors.text} />
                ) : (
                  <ChevronDown size={20} color={Colors.text} />
                )}
              </View>
            )}
          </TouchableOpacity>
          
          {/* Comment Input */}
          <View style={styles.commentInputContainer}>
            <TextInput
              style={styles.commentInput}
              placeholder="Add a comment..."
              placeholderTextColor={Colors.textLight}
              value={commentText}
              onChangeText={setCommentText}
            />
            <TouchableOpacity 
              style={[
                styles.commentSubmitButton,
                !commentText.trim() && styles.commentSubmitButtonDisabled
              ]}
              onPress={handleSubmitComment}
              disabled={!commentText.trim()}
            >
              <Text style={styles.commentSubmitButtonText}>Post</Text>
            </TouchableOpacity>
          </View>
          
          {/* Comments List */}
          {videoComments.length > 0 ? (
            <View style={styles.commentsList}>
              {/* Show only first comment if not expanded */}
              {(showAllComments ? videoComments : videoComments.slice(0, 1)).map((comment) => (
                <CommentItem 
                  key={comment.id} 
                  comment={comment} 
                />
              ))}
              
              {/* View more comments button */}
              {!showAllComments && videoComments.length > 1 && (
                <TouchableOpacity 
                  style={styles.viewMoreCommentsButton}
                  onPress={toggleCommentsVisibility}
                >
                  <Text style={styles.viewMoreCommentsText}>
                    View all {videoComments.length} comments
                  </Text>
                </TouchableOpacity>
              )}
            </View>
          ) : (
            <View style={styles.noCommentsContainer}>
              <MessageCircle size={32} color={Colors.textLight} />
              <Text style={styles.noCommentsText}>No comments yet</Text>
              <Text style={styles.noCommentsSubtext}>Be the first to comment</Text>
            </View>
          )}
        </View>
        
        {/* Related Videos */}
        <View style={styles.relatedVideosContainer}>
          <Text style={styles.relatedVideosTitle}>Related Videos</Text>
          
          <View style={styles.relatedVideosList}>
            {relatedVideos.map((relatedVideo) => (
              <VideoCard 
                key={relatedVideo.id} 
                video={relatedVideo} 
                horizontal 
                showChannel
              />
            ))}
          </View>
        </View>
      </ScrollView>
      
      {/* Collab Request Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={collabModalVisible}
        onRequestClose={handleCloseModal}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Collaboration Request</Text>
              <TouchableOpacity onPress={handleCloseModal}>
                <X size={24} color={Colors.text} />
              </TouchableOpacity>
            </View>
            
            <Text style={styles.modalSubtitle}>
              Send a collaboration request to {video.user?.name}
            </Text>
            
            <TextInput
              style={styles.messageInput}
              placeholder="Write your collaboration request..."
              placeholderTextColor={Colors.textLight}
              multiline
              numberOfLines={4}
              value={collabMessage}
              onChangeText={setCollabMessage}
            />
            
            <TouchableOpacity 
              style={[
                styles.sendButton,
                !collabMessage.trim() && styles.sendButtonDisabled
              ]}
              onPress={handleSendCollabRequest}
              disabled={!collabMessage.trim()}
            >
              <Text style={styles.sendButtonText}>Send Request</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
      
      {/* Gift Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={giftModalVisible}
        onRequestClose={handleCloseGiftModal}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Send a Gift</Text>
              <TouchableOpacity onPress={handleCloseGiftModal}>
                <X size={24} color={Colors.text} />
              </TouchableOpacity>
            </View>
            
            <Text style={styles.modalSubtitle}>
              Support {video.user?.name} by sending a gift
            </Text>
            
            <View style={styles.giftAmountsContainer}>
              {giftAmounts.map((amount) => (
                <TouchableOpacity 
                  key={amount}
                  style={[
                    styles.giftAmountButton,
                    selectedAmount === amount && styles.giftAmountButtonSelected
                  ]}
                  onPress={() => setSelectedAmount(amount)}
                >
                  <Text 
                    style={[
                      styles.giftAmountText,
                      selectedAmount === amount && styles.giftAmountTextSelected
                    ]}
                  >
                    ${amount}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
            
            <View style={styles.giftInfoContainer}>
              <Gift size={24} color={Colors.primary} />
              <Text style={styles.giftInfoText}>
                Your gift helps support this creator and encourages them to make more content you love.
              </Text>
            </View>
            
            <TouchableOpacity 
              style={styles.sendGiftButton}
              onPress={handleSendGift}
            >
              <Text style={styles.sendGiftButtonText}>Send ${selectedAmount} Gift</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  videoInfo: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  videoTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 8,
  },
  videoStatsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  videoStats: {
    fontSize: 14,
    color: Colors.textLight,
    marginRight: 8,
  },
  moreButton: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.textLight,
  },
  descriptionContainer: {
    marginBottom: 16,
    paddingVertical: 8,
    paddingHorizontal: 2,
    borderRadius: 8,
    backgroundColor: Colors.card,
  },
  description: {
    fontSize: 14,
    color: Colors.text,
    lineHeight: 20,
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  actionButton: {
    alignItems: 'center',
  },
  actionButtonText: {
    fontSize: 12,
    color: Colors.textLight,
    marginTop: 4,
  },
  actionButtonTextActive: {
    color: Colors.primary,
  },
  creatorContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  creatorInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  creatorAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 12,
  },
  creatorTextContainer: {
    flex: 1,
  },
  creatorName: {
    fontSize: 16,
    fontWeight: '500',
    color: Colors.text,
    marginBottom: 2,
  },
  creatorFollowers: {
    fontSize: 14,
    color: Colors.textLight,
  },
  creatorActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  followButton: {
    backgroundColor: Colors.primary,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 4,
    marginRight: 8,
  },
  followingButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: Colors.border,
  },
  followButtonText: {
    color: Colors.background,
    fontSize: 14,
    fontWeight: '500',
  },
  followingButtonText: {
    color: Colors.text,
  },
  bellButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.card,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  collabButton: {
    backgroundColor: Colors.secondary,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 4,
  },
  collabButtonText: {
    color: Colors.background,
    fontSize: 14,
    fontWeight: '500',
  },
  commentsContainer: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  commentsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  commentsTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.text,
  },
  commentsToggle: {
    padding: 4,
  },
  commentInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  commentInput: {
    flex: 1,
    height: 40,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 20,
    paddingHorizontal: 16,
    marginRight: 8,
    color: Colors.text,
  },
  commentSubmitButton: {
    backgroundColor: Colors.primary,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  commentSubmitButtonDisabled: {
    backgroundColor: Colors.border,
  },
  commentSubmitButtonText: {
    color: Colors.background,
    fontWeight: '500',
  },
  commentsList: {
    marginTop: 8,
  },
  viewMoreCommentsButton: {
    paddingVertical: 12,
    alignItems: 'center',
  },
  viewMoreCommentsText: {
    color: Colors.textLight,
    fontSize: 14,
    fontWeight: '500',
  },
  noCommentsContainer: {
    alignItems: 'center',
    paddingVertical: 24,
  },
  noCommentsText: {
    fontSize: 16,
    fontWeight: '500',
    color: Colors.text,
    marginTop: 12,
  },
  noCommentsSubtext: {
    fontSize: 14,
    color: Colors.textLight,
    marginTop: 4,
  },
  relatedVideosContainer: {
    padding: 16,
  },
  relatedVideosTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 16,
  },
  relatedVideosList: {
    gap: 16,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: '90%',
    backgroundColor: Colors.background,
    borderRadius: 12,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
  },
  modalSubtitle: {
    fontSize: 14,
    color: Colors.textLight,
    marginBottom: 16,
  },
  messageInput: {
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    padding: 12,
    height: 120,
    textAlignVertical: 'top',
    marginBottom: 16,
    color: Colors.text,
  },
  sendButton: {
    backgroundColor: Colors.primary,
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  sendButtonDisabled: {
    backgroundColor: Colors.border,
  },
  sendButtonText: {
    color: Colors.background,
    fontWeight: '600',
    fontSize: 16,
  },
  // Gift modal styles
  giftAmountsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  giftAmountButton: {
    width: '30%',
    paddingVertical: 12,
    marginBottom: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  giftAmountButtonSelected: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  giftAmountText: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.text,
  },
  giftAmountTextSelected: {
    color: Colors.background,
  },
  giftInfoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.card,
    padding: 12,
    borderRadius: 8,
    marginBottom: 20,
  },
  giftInfoText: {
    flex: 1,
    marginLeft: 12,
    fontSize: 14,
    color: Colors.text,
    lineHeight: 20,
  },
  sendGiftButton: {
    backgroundColor: Colors.primary,
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  sendGiftButtonText: {
    color: Colors.background,
    fontWeight: '600',
    fontSize: 16,
  },
});