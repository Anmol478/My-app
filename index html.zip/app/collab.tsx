import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useRouter } from 'expo-router';
import { Check, X, Users } from 'lucide-react-native';
import { users } from '@/mocks/users';
import { formatTimeAgo } from '@/utils/format';
import Colors from '@/constants/colors';
import Header from '@/components/Header';

// Mock collab requests data
const collabRequests = [
  {
    id: '1',
    userId: '2',
    message: "I'd love to collaborate on an underwater photography tutorial. Let me know if you're interested!",
    timestamp: '2023-10-15T14:30:00Z',
    status: 'pending',
  },
  {
    id: '2',
    userId: '3',
    message: "Would you like to join me for a live stream about marine conservation next week?",
    timestamp: '2023-10-14T09:15:00Z',
    status: 'pending',
  },
  {
    id: '3',
    userId: '4',
    message: "Let's create a series about the Great Barrier Reef together. I have some amazing footage to share.",
    timestamp: '2023-10-12T18:45:00Z',
    status: 'accepted',
  },
  {
    id: '4',
    userId: '5',
    message: "I saw your surfing videos and would love to feature you in my upcoming documentary about ocean sports.",
    timestamp: '2023-10-10T12:00:00Z',
    status: 'declined',
  },
];

export default function CollabScreen() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState('pending');
  const [requests, setRequests] = useState(collabRequests);
  
  const filteredRequests = requests.filter(request => {
    if (activeTab === 'pending') return request.status === 'pending';
    if (activeTab === 'accepted') return request.status === 'accepted';
    if (activeTab === 'declined') return request.status === 'declined';
    return true;
  });
  
  const handleAccept = (id: string) => {
    setRequests(requests.map(request => 
      request.id === id ? { ...request, status: 'accepted' } : request
    ));
  };
  
  const handleDecline = (id: string) => {
    setRequests(requests.map(request => 
      request.id === id ? { ...request, status: 'declined' } : request
    ));
  };
  
  const renderRequestItem = ({ item }) => {
    const user = users.find(u => u.id === item.userId);
    
    if (!user) return null;
    
    return (
      <View style={styles.requestItem}>
        <View style={styles.requestHeader}>
          <View style={styles.userInfo}>
            <Image source={{ uri: user.avatar }} style={styles.avatar} />
            <View>
              <Text style={styles.username}>{user.name}</Text>
              <Text style={styles.timestamp}>{formatTimeAgo(item.timestamp)}</Text>
            </View>
          </View>
          
          {item.status === 'pending' && (
            <View style={styles.actionButtons}>
              <TouchableOpacity 
                style={[styles.actionButton, styles.acceptButton]}
                onPress={() => handleAccept(item.id)}
              >
                <Check size={16} color={Colors.background} />
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[styles.actionButton, styles.declineButton]}
                onPress={() => handleDecline(item.id)}
              >
                <X size={16} color={Colors.background} />
              </TouchableOpacity>
            </View>
          )}
          
          {item.status === 'accepted' && (
            <View style={styles.statusBadge}>
              <Text style={styles.statusText}>Accepted</Text>
            </View>
          )}
          
          {item.status === 'declined' && (
            <View style={[styles.statusBadge, styles.declinedBadge]}>
              <Text style={[styles.statusText, styles.declinedText]}>Declined</Text>
            </View>
          )}
        </View>
        
        <Text style={styles.message}>{item.message}</Text>
        
        {item.status === 'accepted' && (
          <TouchableOpacity style={styles.messageButton}>
            <Text style={styles.messageButtonText}>Message</Text>
          </TouchableOpacity>
        )}
      </View>
    );
  };
  
  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar style="dark" />
      
      <Header showBackButton onBackPress={() => router.back()} />
      
      <View style={styles.actionHeader}>
        <TouchableOpacity style={styles.newCollabButton}>
          <Users size={20} color={Colors.background} />
          <Text style={styles.newCollabButtonText}>New Collab</Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.tabsContainer}>
        <TouchableOpacity
          style={[
            styles.tabItem,
            activeTab === 'pending' && styles.activeTabItem,
          ]}
          onPress={() => setActiveTab('pending')}
        >
          <Text
            style={[
              styles.tabText,
              activeTab === 'pending' && styles.activeTabText,
            ]}
          >
            Pending
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.tabItem,
            activeTab === 'accepted' && styles.activeTabItem,
          ]}
          onPress={() => setActiveTab('accepted')}
        >
          <Text
            style={[
              styles.tabText,
              activeTab === 'accepted' && styles.activeTabText,
            ]}
          >
            Accepted
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.tabItem,
            activeTab === 'declined' && styles.activeTabItem,
          ]}
          onPress={() => setActiveTab('declined')}
        >
          <Text
            style={[
              styles.tabText,
              activeTab === 'declined' && styles.activeTabText,
            ]}
          >
            Declined
          </Text>
        </TouchableOpacity>
      </View>
      
      <FlatList
        data={filteredRequests}
        keyExtractor={(item) => item.id}
        renderItem={renderRequestItem}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>
              {activeTab === 'pending' 
                ? 'No pending collaboration requests' 
                : activeTab === 'accepted'
                ? 'No accepted collaborations yet'
                : 'No declined collaborations'
              }
            </Text>
          </View>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  actionHeader: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  newCollabButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: Colors.primary,
    borderRadius: 16,
  },
  newCollabButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.background,
    marginLeft: 4,
  },
  tabsContainer: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  tabItem: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
  },
  activeTabItem: {
    borderBottomWidth: 2,
    borderBottomColor: Colors.primary,
  },
  tabText: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.textLight,
  },
  activeTabText: {
    color: Colors.primary,
  },
  listContent: {
    padding: 16,
  },
  requestItem: {
    backgroundColor: Colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  requestHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 12,
  },
  username: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 2,
  },
  timestamp: {
    fontSize: 12,
    color: Colors.textLight,
  },
  actionButtons: {
    flexDirection: 'row',
  },
  actionButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 8,
  },
  acceptButton: {
    backgroundColor: Colors.success,
  },
  declineButton: {
    backgroundColor: Colors.error,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    backgroundColor: Colors.success,
    borderRadius: 12,
  },
  declinedBadge: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: Colors.error,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '500',
    color: Colors.background,
  },
  declinedText: {
    color: Colors.error,
  },
  message: {
    fontSize: 14,
    color: Colors.text,
    marginBottom: 16,
    lineHeight: 20,
  },
  messageButton: {
    alignSelf: 'flex-start',
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: Colors.primary,
    borderRadius: 16,
  },
  messageButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.background,
  },
  emptyContainer: {
    padding: 32,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: Colors.textLight,
    textAlign: 'center',
  },
});