import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useRouter } from 'expo-router';
import { 
  ArrowLeft, 
  Moon, 
  Bell, 
  Play, 
  Download, 
  Shield, 
  HelpCircle, 
  LogOut, 
  ChevronRight,
  BarChart3
} from 'lucide-react-native';
import { useAppStore } from '@/store/app-store';
import { useUserStore } from '@/store/user-store';
import Colors from '@/constants/colors';

export default function SettingsScreen() {
  const router = useRouter();
  const { isDarkMode, isNotificationsEnabled, isAutoplayEnabled, toggleDarkMode, toggleNotifications, toggleAutoplay } = useAppStore();
  const { logout } = useUserStore();
  
  const handleBack = () => {
    router.back();
  };
  
  const handleLogout = () => {
    logout();
    router.replace('/');
  };
  
  const navigateToStudio = () => {
    router.push('/settings/studio');
  };
  
  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar style="dark" />
      
      <View style={styles.header}>
        <TouchableOpacity onPress={handleBack}>
          <ArrowLeft size={24} color={Colors.text} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Settings</Text>
        <View style={{ width: 24 }} />
      </View>
      
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account</Text>
          
          <TouchableOpacity 
            style={styles.settingItem}
            onPress={() => router.push('/settings/edit-profile')}
          >
            <Text style={styles.settingText}>Edit Profile</Text>
            <ChevronRight size={20} color={Colors.textLight} />
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.settingItem}
            onPress={navigateToStudio}
          >
            <View style={styles.settingWithIcon}>
              <BarChart3 size={20} color={Colors.primary} style={styles.settingIcon} />
              <Text style={styles.settingText}>Creator Studio</Text>
            </View>
            <ChevronRight size={20} color={Colors.textLight} />
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.settingItem}>
            <Text style={styles.settingText}>Privacy</Text>
            <ChevronRight size={20} color={Colors.textLight} />
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.settingItem}>
            <Text style={styles.settingText}>Security</Text>
            <ChevronRight size={20} color={Colors.textLight} />
          </TouchableOpacity>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Preferences</Text>
          
          <View style={styles.settingItem}>
            <Text style={styles.settingText}>Dark Mode</Text>
            <TouchableOpacity 
              style={[
                styles.toggle,
                isDarkMode && styles.toggleActive
              ]}
              onPress={toggleDarkMode}
            >
              <View style={[
                styles.toggleCircle,
                isDarkMode && styles.toggleCircleActive
              ]} />
            </TouchableOpacity>
          </View>
          
          <View style={styles.settingItem}>
            <Text style={styles.settingText}>Notifications</Text>
            <TouchableOpacity 
              style={[
                styles.toggle,
                isNotificationsEnabled && styles.toggleActive
              ]}
              onPress={toggleNotifications}
            >
              <View style={[
                styles.toggleCircle,
                isNotificationsEnabled && styles.toggleCircleActive
              ]} />
            </TouchableOpacity>
          </View>
          
          <View style={styles.settingItem}>
            <Text style={styles.settingText}>Autoplay Videos</Text>
            <TouchableOpacity 
              style={[
                styles.toggle,
                isAutoplayEnabled && styles.toggleActive
              ]}
              onPress={toggleAutoplay}
            >
              <View style={[
                styles.toggleCircle,
                isAutoplayEnabled && styles.toggleCircleActive
              ]} />
            </TouchableOpacity>
          </View>
          
          <TouchableOpacity style={styles.settingItem}>
            <Text style={styles.settingText}>Language</Text>
            <View style={styles.settingValue}>
              <Text style={styles.settingValueText}>English</Text>
              <ChevronRight size={20} color={Colors.textLight} />
            </View>
          </TouchableOpacity>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Content</Text>
          
          <TouchableOpacity style={styles.settingItem}>
            <View style={styles.settingWithIcon}>
              <Download size={20} color={Colors.text} style={styles.settingIcon} />
              <Text style={styles.settingText}>Downloads</Text>
            </View>
            <ChevronRight size={20} color={Colors.textLight} />
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.settingItem}>
            <View style={styles.settingWithIcon}>
              <Play size={20} color={Colors.text} style={styles.settingIcon} />
              <Text style={styles.settingText}>Watch History</Text>
            </View>
            <ChevronRight size={20} color={Colors.textLight} />
          </TouchableOpacity>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Support</Text>
          
          <TouchableOpacity style={styles.settingItem}>
            <View style={styles.settingWithIcon}>
              <HelpCircle size={20} color={Colors.text} style={styles.settingIcon} />
              <Text style={styles.settingText}>Help & Support</Text>
            </View>
            <ChevronRight size={20} color={Colors.textLight} />
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.settingItem}>
            <View style={styles.settingWithIcon}>
              <Shield size={20} color={Colors.text} style={styles.settingIcon} />
              <Text style={styles.settingText}>Terms & Privacy Policy</Text>
            </View>
            <ChevronRight size={20} color={Colors.textLight} />
          </TouchableOpacity>
        </View>
        
        <TouchableOpacity 
          style={styles.logoutButton}
          onPress={handleLogout}
        >
          <LogOut size={20} color={Colors.error} style={styles.logoutIcon} />
          <Text style={styles.logoutText}>Log Out</Text>
        </TouchableOpacity>
        
        <Text style={styles.versionText}>Version 1.0.0</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
  },
  section: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 16,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
  },
  settingWithIcon: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  settingIcon: {
    marginRight: 12,
  },
  settingText: {
    fontSize: 16,
    color: Colors.text,
  },
  settingValue: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  settingValueText: {
    fontSize: 16,
    color: Colors.textLight,
    marginRight: 8,
  },
  toggle: {
    width: 50,
    height: 30,
    borderRadius: 15,
    backgroundColor: Colors.border,
    padding: 2,
  },
  toggleActive: {
    backgroundColor: Colors.primary,
  },
  toggleCircle: {
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: Colors.background,
  },
  toggleCircleActive: {
    transform: [{ translateX: 20 }],
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 24,
    paddingVertical: 12,
  },
  logoutIcon: {
    marginRight: 8,
  },
  logoutText: {
    fontSize: 16,
    fontWeight: '500',
    color: Colors.error,
  },
  versionText: {
    textAlign: 'center',
    fontSize: 14,
    color: Colors.textLight,
    marginBottom: 24,
  },
});