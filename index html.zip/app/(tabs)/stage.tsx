import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Play, Clock, Lock, Crown } from 'lucide-react-native';
import Header from '@/components/Header';
import { getVideosByType, getVideosByCategory, getNonPremiumVideosByType } from '@/mocks/videos';
import { stageCategories } from '@/mocks/categories';
import { formatDuration } from '@/utils/format';
import Colors from '@/constants/colors';
import { useRouter } from 'expo-router';
import { useAppStore } from '@/store/app-store';
import { LinearGradient } from 'expo-linear-gradient';

const languages = [
  { id: 'all', name: 'All' },
  { id: '1', name: 'English' },
  { id: '2', name: 'Hindi' },
  { id: '3', name: 'Tamil' },
  { id: '4', name: 'Telugu' },
  { id: '5', name: 'Marathi' },
  { id: '6', name: 'Bengali' },
];

export default function StageScreen() {
  const [selectedCategory, setSelectedCategory] = React.useState('all');
  const [selectedLanguage, setSelectedLanguage] = React.useState('all');
  const router = useRouter();
  const { isPremium } = useAppStore();
  
  // Get only stage videos
  const stageVideos = getVideosByType('stage');
  
  // Featured video is the first stage video
  const featuredVideo = stageVideos[0];
  
  // Filter videos by selected category
  const filteredVideos = selectedCategory === 'all' 
    ? stageVideos 
    : stageVideos.filter(
        video => stageCategories.find(cat => cat.id === selectedCategory)?.name === video.category
      );

  // Get premium videos for premium section
  const premiumVideos = stageVideos.filter(video => video.isPremium);
  
  // Get short films
  const shortFilms = getVideosByCategory('Short Films');
  
  // Get free short films
  const freeShortFilms = shortFilms.filter(video => !video.isPremium);
  
  // Get dreams
  const dreams = getVideosByCategory('Dreams');
  
  // Get drama videos
  const dramaVideos = getVideosByCategory('Drama');
  
  // Get free drama videos
  const freeDramaVideos = dramaVideos.filter(video => !video.isPremium);
  
  const handleVideoPress = (videoId: string) => {
    router.push(`/video/${videoId}`);
  };

  const handlePremiumPress = () => {
    // Open premium subscription modal
    router.push('/premium');
  };
  
  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar style="dark" />
      <Header />
      
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.featuredContainer}>
          <TouchableOpacity 
            style={styles.featuredImageContainer}
            onPress={() => handleVideoPress(featuredVideo.id)}
          >
            <Image source={{ uri: featuredVideo.thumbnail }} style={styles.featuredImage} />
            <View style={styles.featuredOverlay}>
              <View style={styles.playButton}>
                <Play size={22} color={Colors.background} fill={Colors.background} />
              </View>
              <View style={styles.durationBadge}>
                <Clock size={12} color={Colors.background} />
                <Text style={styles.durationText}>{formatDuration(featuredVideo.duration)}</Text>
              </View>
            </View>
          </TouchableOpacity>
          <View style={styles.featuredInfo}>
            <Text style={styles.featuredTitle}>{featuredVideo.title}</Text>
            <Text style={styles.featuredDescription} numberOfLines={2}>
              {featuredVideo.description}
            </Text>
            <View style={styles.featuredMeta}>
              <Text style={styles.featuredMetaText}>Featured • {featuredVideo.category}</Text>
            </View>
          </View>
        </View>
        
        {!isPremium && (
          <TouchableOpacity 
            style={styles.premiumBanner}
            onPress={handlePremiumPress}
          >
            <LinearGradient
              colors={['#8B5CF6', '#6366F1']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.premiumGradient}
            >
              <View style={styles.premiumContent}>
                <Crown size={22} color="white" />
                <View style={styles.premiumTextContainer}>
                  <Text style={styles.premiumTitle}>Upgrade to Premium</Text>
                  <Text style={styles.premiumSubtitle}>
                    Unlock exclusive dramas, short films, and more
                  </Text>
                </View>
              </View>
            </LinearGradient>
          </TouchableOpacity>
        )}
        
        <View style={styles.categoriesContainer}>
          <Text style={styles.sectionTitle}>Categories</Text>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.categoriesScrollContent}
          >
            <TouchableOpacity
              key="all-category"
              style={[
                styles.categoryItem,
                selectedCategory === 'all' && styles.selectedCategoryItem,
              ]}
              onPress={() => setSelectedCategory('all')}
            >
              <Text
                style={[
                  styles.categoryText,
                  selectedCategory === 'all' && styles.selectedCategoryText,
                ]}
              >
                All
              </Text>
            </TouchableOpacity>
            {stageCategories.map((category) => (
              <TouchableOpacity
                key={category.id}
                style={[
                  styles.categoryItem,
                  selectedCategory === category.id && styles.selectedCategoryItem,
                ]}
                onPress={() => setSelectedCategory(category.id)}
              >
                <Text
                  style={[
                    styles.categoryText,
                    selectedCategory === category.id && styles.selectedCategoryText,
                  ]}
                >
                  {category.name}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
        
        <View style={styles.languagesContainer}>
          <Text style={styles.sectionTitle}>Languages</Text>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.languagesScrollContent}
          >
            {languages.map((language) => (
              <TouchableOpacity
                key={language.id}
                style={[
                  styles.languageItem,
                  selectedLanguage === language.id && styles.selectedLanguageItem,
                ]}
                onPress={() => setSelectedLanguage(language.id)}
              >
                <Text
                  style={[
                    styles.languageText,
                    selectedLanguage === language.id && styles.selectedLanguageText,
                  ]}
                >
                  {language.name}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
        
        {/* Free Drama Section */}
        <View style={styles.showsContainer}>
          <View style={styles.showsHeader}>
            <Text style={styles.sectionTitle}>Drama</Text>
            <TouchableOpacity>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.showsScrollContent}
          >
            {freeDramaVideos.map((video) => (
              <TouchableOpacity 
                key={video.id} 
                style={styles.showItem}
                onPress={() => handleVideoPress(video.id)}
              >
                <View style={styles.showImageContainer}>
                  <Image source={{ uri: video.thumbnail }} style={styles.showImage} />
                  <View style={styles.showDurationBadge}>
                    <Text style={styles.showDurationText}>{formatDuration(video.duration)}</Text>
                  </View>
                  <View style={styles.freeBadge}>
                    <Text style={styles.freeBadgeText}>FREE</Text>
                  </View>
                </View>
                <Text style={styles.showTitle} numberOfLines={1}>{video.title}</Text>
                <Text style={styles.showCreator} numberOfLines={1}>{video.user?.name}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
        
        {/* Premium Content Section */}
        <View style={styles.showsContainer}>
          <View style={styles.showsHeader}>
            <View style={styles.sectionTitleContainer}>
              <Crown size={16} color={Colors.primary} />
              <Text style={styles.sectionTitle}>Premium Content</Text>
            </View>
            <TouchableOpacity onPress={() => router.push('/premium')}>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.showsScrollContent}
          >
            {premiumVideos.slice(0, 5).map((video) => (
              <TouchableOpacity 
                key={video.id} 
                style={styles.showItem}
                onPress={() => handleVideoPress(video.id)}
              >
                <View style={styles.showImageContainer}>
                  <Image source={{ uri: video.thumbnail }} style={styles.showImage} />
                  <View style={styles.showDurationBadge}>
                    <Text style={styles.showDurationText}>{formatDuration(video.duration)}</Text>
                  </View>
                  <View style={styles.premiumBadge}>
                    <Lock size={10} color="white" />
                    <Text style={styles.premiumBadgeText}>PREMIUM</Text>
                  </View>
                </View>
                <Text style={styles.showTitle} numberOfLines={1}>{video.title}</Text>
                <Text style={styles.showCreator} numberOfLines={1}>{video.user?.name}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
        
        {/* Free Short Films Section */}
        <View style={styles.showsContainer}>
          <View style={styles.showsHeader}>
            <Text style={styles.sectionTitle}>Free Short Films</Text>
            <TouchableOpacity>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.showsScrollContent}
          >
            {freeShortFilms.map((video) => (
              <TouchableOpacity 
                key={video.id} 
                style={styles.showItem}
                onPress={() => handleVideoPress(video.id)}
              >
                <View style={styles.showImageContainer}>
                  <Image source={{ uri: video.thumbnail }} style={styles.showImage} />
                  <View style={styles.showDurationBadge}>
                    <Text style={styles.showDurationText}>{formatDuration(video.duration)}</Text>
                  </View>
                  <View style={styles.freeBadge}>
                    <Text style={styles.freeBadgeText}>FREE</Text>
                  </View>
                </View>
                <Text style={styles.showTitle} numberOfLines={1}>{video.title}</Text>
                <Text style={styles.showCreator} numberOfLines={1}>{video.user?.name}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
        
        {/* Premium Short Films Section */}
        <View style={styles.showsContainer}>
          <View style={styles.showsHeader}>
            <Text style={styles.sectionTitle}>Premium Short Films</Text>
            <TouchableOpacity>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.showsScrollContent}
          >
            {shortFilms.filter(video => video.isPremium).map((video) => (
              <TouchableOpacity 
                key={video.id} 
                style={styles.showItem}
                onPress={() => handleVideoPress(video.id)}
              >
                <View style={styles.showImageContainer}>
                  <Image source={{ uri: video.thumbnail }} style={styles.showImage} />
                  <View style={styles.showDurationBadge}>
                    <Text style={styles.showDurationText}>{formatDuration(video.duration)}</Text>
                  </View>
                  <View style={styles.premiumBadge}>
                    <Lock size={10} color="white" />
                    <Text style={styles.premiumBadgeText}>PREMIUM</Text>
                  </View>
                </View>
                <Text style={styles.showTitle} numberOfLines={1}>{video.title}</Text>
                <Text style={styles.showCreator} numberOfLines={1}>{video.user?.name}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
        
        {/* Dreams Section */}
        <View style={styles.showsContainer}>
          <View style={styles.showsHeader}>
            <Text style={styles.sectionTitle}>Dreams</Text>
            <TouchableOpacity>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.showsScrollContent}
          >
            {dreams.map((video) => (
              <TouchableOpacity 
                key={video.id} 
                style={styles.showItem}
                onPress={() => handleVideoPress(video.id)}
              >
                <View style={styles.showImageContainer}>
                  <Image source={{ uri: video.thumbnail }} style={styles.showImage} />
                  <View style={styles.showDurationBadge}>
                    <Text style={styles.showDurationText}>{formatDuration(video.duration)}</Text>
                  </View>
                  {video.isPremium && (
                    <View style={styles.premiumBadge}>
                      <Lock size={10} color="white" />
                      <Text style={styles.premiumBadgeText}>PREMIUM</Text>
                    </View>
                  )}
                </View>
                <Text style={styles.showTitle} numberOfLines={1}>{video.title}</Text>
                <Text style={styles.showCreator} numberOfLines={1}>{video.user?.name}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
        
        <View style={styles.showsContainer}>
          <View style={styles.showsHeader}>
            <Text style={styles.sectionTitle}>Popular Shows</Text>
            <TouchableOpacity>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.showsScrollContent}
          >
            {filteredVideos.slice(0, 3).map((video) => (
              <TouchableOpacity 
                key={video.id} 
                style={styles.showItem}
                onPress={() => handleVideoPress(video.id)}
              >
                <View style={styles.showImageContainer}>
                  <Image source={{ uri: video.thumbnail }} style={styles.showImage} />
                  <View style={styles.showDurationBadge}>
                    <Text style={styles.showDurationText}>{formatDuration(video.duration)}</Text>
                  </View>
                  {video.isPremium && (
                    <View style={styles.premiumBadge}>
                      <Lock size={10} color="white" />
                      <Text style={styles.premiumBadgeText}>PREMIUM</Text>
                    </View>
                  )}
                </View>
                <Text style={styles.showTitle} numberOfLines={1}>{video.title}</Text>
                <Text style={styles.showCreator} numberOfLines={1}>{video.user?.name}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
        
        <View style={styles.showsContainer}>
          <View style={styles.showsHeader}>
            <Text style={styles.sectionTitle}>New Releases</Text>
            <TouchableOpacity>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.showsScrollContent}
          >
            {stageVideos.slice(3).map((video) => (
              <TouchableOpacity 
                key={video.id} 
                style={styles.showItem}
                onPress={() => handleVideoPress(video.id)}
              >
                <View style={styles.showImageContainer}>
                  <Image source={{ uri: video.thumbnail }} style={styles.showImage} />
                  <View style={styles.showDurationBadge}>
                    <Text style={styles.showDurationText}>{formatDuration(video.duration)}</Text>
                  </View>
                  {video.isPremium && (
                    <View style={styles.premiumBadge}>
                      <Lock size={10} color="white" />
                      <Text style={styles.premiumBadgeText}>PREMIUM</Text>
                    </View>
                  )}
                </View>
                <Text style={styles.showTitle} numberOfLines={1}>{video.title}</Text>
                <Text style={styles.showCreator} numberOfLines={1}>{video.user?.name}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
        
        {/* Add bottom padding for better scrolling */}
        <View style={styles.bottomPadding} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  featuredContainer: {
    marginBottom: 20,
  },
  featuredImageContainer: {
    width: '100%',
    height: 200,
    position: 'relative',
  },
  featuredImage: {
    width: '100%',
    height: '100%',
  },
  featuredOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  playButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  durationBadge: {
    position: 'absolute',
    bottom: 12,
    right: 12,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 4,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  durationText: {
    color: Colors.background,
    fontSize: 11,
    fontWeight: '500',
  },
  featuredInfo: {
    padding: 12,
  },
  featuredTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 6,
  },
  featuredDescription: {
    fontSize: 13,
    color: Colors.textLight,
    marginBottom: 6,
    lineHeight: 18,
  },
  featuredMeta: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  featuredMetaText: {
    fontSize: 12,
    color: Colors.primary,
    fontWeight: '500',
  },
  premiumBanner: {
    marginHorizontal: 12,
    marginBottom: 20,
    borderRadius: 10,
    overflow: 'hidden',
  },
  premiumGradient: {
    padding: 12,
  },
  premiumContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  premiumTextContainer: {
    marginLeft: 10,
    flex: 1,
  },
  premiumTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 2,
  },
  premiumSubtitle: {
    fontSize: 12,
    color: 'rgba(255, 255, 255, 0.9)',
  },
  categoriesContainer: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 10,
    paddingHorizontal: 12,
  },
  sectionTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
  },
  categoriesScrollContent: {
    paddingHorizontal: 12,
    paddingBottom: 6,
    gap: 8,
  },
  categoryItem: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: Colors.card,
    marginRight: 8,
  },
  selectedCategoryItem: {
    backgroundColor: Colors.primary,
  },
  categoryText: {
    fontSize: 13,
    fontWeight: '500',
    color: Colors.text,
  },
  selectedCategoryText: {
    color: Colors.background,
  },
  languagesContainer: {
    marginBottom: 20,
  },
  languagesScrollContent: {
    paddingHorizontal: 12,
    paddingBottom: 6,
    gap: 8,
  },
  languageItem: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: Colors.card,
    marginRight: 8,
  },
  selectedLanguageItem: {
    backgroundColor: Colors.primary,
  },
  languageText: {
    fontSize: 13,
    fontWeight: '500',
    color: Colors.text,
  },
  selectedLanguageText: {
    color: Colors.background,
  },
  showsContainer: {
    marginBottom: 20,
  },
  showsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingRight: 12,
    marginBottom: 10,
  },
  seeAllText: {
    fontSize: 13,
    color: Colors.primary,
    fontWeight: '500',
  },
  showsScrollContent: {
    paddingHorizontal: 12,
    paddingBottom: 6,
    gap: 10,
  },
  showItem: {
    width: 130,
    marginRight: 10,
  },
  showImageContainer: {
    position: 'relative',
    width: 130,
    height: 180,
    borderRadius: 6,
    overflow: 'hidden',
    marginBottom: 6,
  },
  showImage: {
    width: '100%',
    height: '100%',
  },
  showDurationBadge: {
    position: 'absolute',
    bottom: 6,
    right: 6,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    paddingHorizontal: 4,
    paddingVertical: 2,
    borderRadius: 2,
  },
  showDurationText: {
    color: 'white',
    fontSize: 10,
    fontWeight: '500',
  },
  showTitle: {
    fontSize: 13,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 2,
  },
  showCreator: {
    fontSize: 11,
    color: Colors.textLight,
  },
  premiumBadge: {
    position: 'absolute',
    top: 6,
    left: 6,
    backgroundColor: Colors.primary,
    paddingHorizontal: 4,
    paddingVertical: 2,
    borderRadius: 2,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
  },
  premiumBadgeText: {
    color: 'white',
    fontSize: 8,
    fontWeight: 'bold',
  },
  freeBadge: {
    position: 'absolute',
    top: 6,
    left: 6,
    backgroundColor: '#4CAF50',
    paddingHorizontal: 4,
    paddingVertical: 2,
    borderRadius: 2,
  },
  freeBadgeText: {
    color: 'white',
    fontSize: 8,
    fontWeight: 'bold',
  },
  bottomPadding: {
    height: 80, // Add extra padding at the bottom for better scrolling
  },
});