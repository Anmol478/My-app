import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, Dimensions, Share, Platform, Modal, GestureResponderEvent } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Settings, Download, Bookmark, History, Award, Pencil, Trash2, Play, X, ExternalLink, Image as ImageIcon, Share2, MoreVertical } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import { useUserStore } from '@/store/user-store';
import { videos } from '@/mocks/videos';
import Colors from '@/constants/colors';
import VideoCard from '@/components/VideoCard';
import { formatNumber, formatDuration, formatTimeAgo } from '@/utils/format';

// Define types
interface Video {
  id: string;
  title: string;
  thumbnail: string;
  duration: number;
  views: number;
  createdAt: string;
  user?: {
    id: string;
    name: string;
    username: string;
    avatar: string;
  };
}

interface MenuPosition {
  top: number;
  right: number;
}

const { width } = Dimensions.get('window');
const cardWidth = (width - 32) / 2; // 2 columns with 16px padding on sides and 16px gap
const photoWidth = (width - 48) / 3; // 3 columns with 16px padding on sides and 8px gap

export default function ProfileScreen() {
  const router = useRouter();
  const { 
    currentUser, 
    savedVideos, 
    downloadedVideos,
    watchHistory,
    photos,
    toggleSaveVideo,
    toggleLikeVideo,
    isVideoLiked,
    removeFromDownloaded,
    clearWatchHistory,
    removeFromWatchHistory
  } = useUserStore();
  
  const [activeTab, setActiveTab] = useState('downloaded');
  const [menuVisible, setMenuVisible] = useState(false);
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [menuPosition, setMenuPosition] = useState<MenuPosition>({ top: 0, right: 0 });
  
  const savedVideosList = videos.filter(video => savedVideos.includes(video.id));
  const downloadedVideosList = videos.filter(video => downloadedVideos.includes(video.id));
  const watchHistoryList = videos.filter(video => watchHistory.includes(video.id));
  
  const handleEditProfile = () => {
    router.push('/settings/edit-profile');
  };
  
  const handleSettingsPress = () => {
    router.push('/settings');
  };

  const handleVideoPress = (videoId: string) => {
    router.push(`/video/${videoId}`);
  };

  const handleRemoveFromSaved = (videoId: string) => {
    toggleSaveVideo(videoId);
    setMenuVisible(false);
  };

  const handleRemoveFromDownloaded = (videoId: string) => {
    removeFromDownloaded(videoId);
    setMenuVisible(false);
  };

  const handleRemoveFromHistory = (videoId: string) => {
    removeFromWatchHistory(videoId);
    setMenuVisible(false);
  };

  const handleClearHistory = () => {
    clearWatchHistory();
  };

  const handleShareProfile = async () => {
    try {
      const result = await Share.share({
        message: `Check out ${currentUser?.name}'s profile on ProSea: https://prosea.app/profile/${currentUser?.id}`,
        title: `${currentUser?.name}'s ProSea Profile`,
        url: Platform.OS === 'ios' ? `https://prosea.app/profile/${currentUser?.id}` : undefined,
      });
    } catch (error) {
      console.error('Error sharing profile:', error);
    }
  };

  const openMenu = (video: Video, event: GestureResponderEvent) => {
    // Get the position of the touch event
    const { pageX, pageY } = event.nativeEvent;
    
    setSelectedVideo(video);
    setMenuPosition({ 
      top: pageY - 100, // Adjust as needed
      right: 20
    });
    setMenuVisible(true);
  };
  
  if (!currentUser) {
    return (
      <View style={styles.loadingContainer}>
        <Text>Loading...</Text>
      </View>
    );
  }
  
  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar style="dark" />
      
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Profile</Text>
        <TouchableOpacity onPress={handleSettingsPress}>
          <Settings size={22} color={Colors.text} />
        </TouchableOpacity>
      </View>
      
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Profile Header */}
        <View style={styles.profileHeader}>
          <View style={styles.profilePictureContainer}>
            <Image 
              source={{ uri: currentUser.avatar }} 
              style={styles.profilePicture} 
            />
            <TouchableOpacity 
              style={styles.editProfilePicButton}
              onPress={handleEditProfile}
            >
              <Pencil size={14} color={Colors.background} />
            </TouchableOpacity>
          </View>
          
          <Text style={styles.username}>{currentUser.name}</Text>
          <Text style={styles.handle}>@{currentUser.username}</Text>
          
          {currentUser.bio && (
            <Text style={styles.bio} numberOfLines={2}>
              {currentUser.bio}
            </Text>
          )}
          
          <View style={styles.profileButtonsContainer}>
            <TouchableOpacity 
              style={styles.editProfileButton}
              onPress={handleEditProfile}
            >
              <Text style={styles.editProfileText}>Edit Profile</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.shareProfileButton}
              onPress={handleShareProfile}
            >
              <Share2 size={14} color={Colors.text} style={styles.shareIcon} />
              <Text style={styles.shareProfileText}>Share Profile</Text>
            </TouchableOpacity>
          </View>
        </View>
        
        {/* Reward Points */}
        <View style={styles.rewardsContainer}>
          <View style={styles.rewardsHeader}>
            <Award size={18} color={Colors.primary} />
            <Text style={styles.rewardsTitle}>Reward Points</Text>
          </View>
          <Text style={styles.rewardsPoints}>1,250</Text>
          <TouchableOpacity style={styles.redeemButton}>
            <Text style={styles.redeemButtonText}>Redeem Points</Text>
          </TouchableOpacity>
        </View>
        
        {/* Tabs Navigation */}
        <View style={styles.tabsContainer}>
          <TouchableOpacity
            style={[
              styles.tabItem,
              activeTab === 'downloaded' && styles.activeTabItem,
            ]}
            onPress={() => setActiveTab('downloaded')}
          >
            <Download 
              size={18} 
              color={activeTab === 'downloaded' ? Colors.primary : Colors.textLight} 
            />
            <Text
              style={[
                styles.tabText,
                activeTab === 'downloaded' && styles.activeTabText,
              ]}
            >
              Download
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.tabItem,
              activeTab === 'saved' && styles.activeTabItem,
            ]}
            onPress={() => setActiveTab('saved')}
          >
            <Bookmark 
              size={18} 
              color={activeTab === 'saved' ? Colors.primary : Colors.textLight} 
            />
            <Text
              style={[
                styles.tabText,
                activeTab === 'saved' && styles.activeTabText,
              ]}
            >
              Save
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.tabItem,
              activeTab === 'history' && styles.activeTabItem,
            ]}
            onPress={() => setActiveTab('history')}
          >
            <History 
              size={18} 
              color={activeTab === 'history' ? Colors.primary : Colors.textLight} 
            />
            <Text
              style={[
                styles.tabText,
                activeTab === 'history' && styles.activeTabText,
              ]}
            >
              History
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.tabItem,
              activeTab === 'photos' && styles.activeTabItem,
            ]}
            onPress={() => setActiveTab('photos')}
          >
            <ImageIcon 
              size={18} 
              color={activeTab === 'photos' ? Colors.primary : Colors.textLight} 
            />
            <Text
              style={[
                styles.tabText,
                activeTab === 'photos' && styles.activeTabText,
              ]}
            >
              Photos
            </Text>
          </TouchableOpacity>
        </View>
        
        {/* Tab Content */}
        <View style={styles.tabContent}>
          {activeTab === 'downloaded' && (
            <>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionTitle}>Downloaded Videos</Text>
                <Text style={styles.sectionCount}>{downloadedVideosList.length} videos</Text>
              </View>
              
              {downloadedVideosList.length > 0 ? (
                <View style={styles.videoGrid}>
                  {downloadedVideosList.map((video) => (
                    <View key={video.id} style={styles.videoCard}>
                      <TouchableOpacity 
                        onPress={() => handleVideoPress(video.id)}
                        activeOpacity={0.8}
                      >
                        <View style={styles.thumbnailContainer}>
                          <Image 
                            source={{ uri: video.thumbnail }} 
                            style={styles.videoThumbnail} 
                          />
                          <View style={styles.durationBadge}>
                            <Text style={styles.durationText}>
                              {formatDuration(video.duration)}
                            </Text>
                          </View>
                        </View>
                        <View style={styles.videoInfo}>
                          <Text 
                            style={styles.videoTitle} 
                            numberOfLines={2}
                          >
                            {video.title}
                          </Text>
                          {video.user && (
                            <Text style={styles.videoCreator} numberOfLines={1}>
                              @{video.user.username}
                            </Text>
                          )}
                          <Text style={styles.videoStats}>
                            {formatNumber(video.views)} views
                          </Text>
                        </View>
                      </TouchableOpacity>
                      
                      <TouchableOpacity 
                        style={styles.menuButton}
                        onPress={(event) => openMenu(video, event)}
                      >
                        <MoreVertical size={18} color={Colors.text} />
                      </TouchableOpacity>
                    </View>
                  ))}
                </View>
              ) : (
                <View style={styles.emptyContainer}>
                  <Download size={36} color={Colors.textLight} />
                  <Text style={styles.emptyText}>No downloaded videos</Text>
                  <TouchableOpacity 
                    style={styles.browseButton}
                    onPress={() => router.push('/')}
                  >
                    <Text style={styles.browseButtonText}>Browse Videos</Text>
                  </TouchableOpacity>
                </View>
              )}
            </>
          )}
          
          {activeTab === 'saved' && (
            <>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionTitle}>Saved Videos</Text>
                <Text style={styles.sectionCount}>{savedVideosList.length} videos</Text>
              </View>
              
              {savedVideosList.length > 0 ? (
                <View style={styles.videoGrid}>
                  {savedVideosList.map((video) => (
                    <View key={video.id} style={styles.videoCard}>
                      <TouchableOpacity 
                        onPress={() => handleVideoPress(video.id)}
                        activeOpacity={0.8}
                      >
                        <View style={styles.thumbnailContainer}>
                          <Image 
                            source={{ uri: video.thumbnail }} 
                            style={styles.videoThumbnail} 
                          />
                          <View style={styles.durationBadge}>
                            <Text style={styles.durationText}>
                              {formatDuration(video.duration)}
                            </Text>
                          </View>
                        </View>
                        <View style={styles.videoInfo}>
                          <Text 
                            style={styles.videoTitle} 
                            numberOfLines={2}
                          >
                            {video.title}
                          </Text>
                          {video.user && (
                            <Text style={styles.videoCreator} numberOfLines={1}>
                              @{video.user.username}
                            </Text>
                          )}
                          <Text style={styles.videoStats}>
                            {formatNumber(video.views)} views
                          </Text>
                        </View>
                      </TouchableOpacity>
                      
                      <TouchableOpacity 
                        style={styles.menuButton}
                        onPress={(event) => openMenu(video, event)}
                      >
                        <MoreVertical size={18} color={Colors.text} />
                      </TouchableOpacity>
                    </View>
                  ))}
                </View>
              ) : (
                <View style={styles.emptyContainer}>
                  <Bookmark size={36} color={Colors.textLight} />
                  <Text style={styles.emptyText}>No saved videos</Text>
                  <TouchableOpacity 
                    style={styles.browseButton}
                    onPress={() => router.push('/')}
                  >
                    <Text style={styles.browseButtonText}>Browse Videos</Text>
                  </TouchableOpacity>
                </View>
              )}
            </>
          )}
          
          {activeTab === 'history' && (
            <>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionTitle}>Watch History</Text>
                {watchHistoryList.length > 0 && (
                  <TouchableOpacity onPress={handleClearHistory}>
                    <Text style={styles.clearHistoryText}>Clear All</Text>
                  </TouchableOpacity>
                )}
              </View>
              
              {watchHistoryList.length > 0 ? (
                <View style={styles.historyList}>
                  {watchHistoryList.map((video) => (
                    <View key={video.id} style={styles.historyItem}>
                      <TouchableOpacity 
                        style={styles.historyItemContent}
                        onPress={() => handleVideoPress(video.id)}
                        activeOpacity={0.8}
                      >
                        <View style={styles.historyThumbnailContainer}>
                          <Image 
                            source={{ uri: video.thumbnail }} 
                            style={styles.historyThumbnail} 
                          />
                          <View style={styles.durationBadge}>
                            <Text style={styles.durationText}>
                              {formatDuration(video.duration)}
                            </Text>
                          </View>
                        </View>
                        
                        <View style={styles.historyInfo}>
                          <Text 
                            style={styles.historyTitle} 
                            numberOfLines={2}
                          >
                            {video.title}
                          </Text>
                          {video.user && (
                            <Text style={styles.historyCreator} numberOfLines={1}>
                              @{video.user.username}
                            </Text>
                          )}
                          <Text style={styles.historyStats}>
                            {formatNumber(video.views)} views • {formatTimeAgo(video.createdAt)}
                          </Text>
                        </View>
                      </TouchableOpacity>
                      
                      <TouchableOpacity 
                        style={styles.historyMenuButton}
                        onPress={(event) => openMenu(video, event)}
                      >
                        <MoreVertical size={18} color={Colors.text} />
                      </TouchableOpacity>
                    </View>
                  ))}
                </View>
              ) : (
                <View style={styles.emptyContainer}>
                  <History size={36} color={Colors.textLight} />
                  <Text style={styles.emptyText}>No watch history</Text>
                  <TouchableOpacity 
                    style={styles.browseButton}
                    onPress={() => router.push('/')}
                  >
                    <Text style={styles.browseButtonText}>Browse Videos</Text>
                  </TouchableOpacity>
                </View>
              )}
            </>
          )}
          
          {activeTab === 'photos' && (
            <>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionTitle}>Photos</Text>
                <Text style={styles.sectionCount}>{photos.length} photos</Text>
              </View>
              
              {photos.length > 0 ? (
                <View style={styles.photoGrid}>
                  {photos.map((photo, index) => (
                    <TouchableOpacity 
                      key={index} 
                      style={styles.photoItem}
                      activeOpacity={0.9}
                    >
                      <Image 
                        source={{ uri: photo.url }} 
                        style={styles.photo} 
                      />
                    </TouchableOpacity>
                  ))}
                </View>
              ) : (
                <View style={styles.emptyContainer}>
                  <ImageIcon size={36} color={Colors.textLight} />
                  <Text style={styles.emptyText}>No photos uploaded</Text>
                  <TouchableOpacity 
                    style={styles.browseButton}
                    onPress={() => router.push('/upload')}
                  >
                    <Text style={styles.browseButtonText}>Upload Photos</Text>
                  </TouchableOpacity>
                </View>
              )}
            </>
          )}
        </View>
      </ScrollView>

      {/* Options Menu Modal */}
      <Modal
        visible={menuVisible}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setMenuVisible(false)}
      >
        <TouchableOpacity 
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={() => setMenuVisible(false)}
        >
          <View 
            style={[
              styles.menuContainer,
              { top: menuPosition.top, right: menuPosition.right }
            ]}
          >
            <TouchableOpacity 
              style={styles.menuItem}
              onPress={() => selectedVideo && handleVideoPress(selectedVideo.id)}
            >
              <Play size={16} color={Colors.text} />
              <Text style={styles.menuItemText}>Play</Text>
            </TouchableOpacity>
            
            {activeTab === 'downloaded' && selectedVideo && (
              <TouchableOpacity 
                style={styles.menuItem}
                onPress={() => selectedVideo && handleRemoveFromDownloaded(selectedVideo.id)}
              >
                <Trash2 size={16} color={Colors.error} />
                <Text style={[styles.menuItemText, { color: Colors.error }]}>Delete</Text>
              </TouchableOpacity>
            )}
            
            {activeTab === 'saved' && selectedVideo && (
              <TouchableOpacity 
                style={styles.menuItem}
                onPress={() => selectedVideo && handleRemoveFromSaved(selectedVideo.id)}
              >
                <X size={16} color={Colors.text} />
                <Text style={styles.menuItemText}>Remove</Text>
              </TouchableOpacity>
            )}
            
            {activeTab === 'history' && selectedVideo && (
              <TouchableOpacity 
                style={styles.menuItem}
                onPress={() => selectedVideo && handleRemoveFromHistory(selectedVideo.id)}
              >
                <X size={16} color={Colors.text} />
                <Text style={styles.menuItemText}>Clear</Text>
              </TouchableOpacity>
            )}
          </View>
        </TouchableOpacity>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
  },
  profileHeader: {
    alignItems: 'center',
    paddingVertical: 20,
    paddingHorizontal: 16,
  },
  profilePictureContainer: {
    position: 'relative',
    marginBottom: 12,
  },
  profilePicture: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 3,
    borderColor: Colors.background,
  },
  editProfilePicButton: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: Colors.primary,
    borderRadius: 12,
    width: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: Colors.background,
  },
  username: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 2,
  },
  handle: {
    fontSize: 14,
    color: Colors.textLight,
    marginBottom: 6,
  },
  bio: {
    fontSize: 14,
    color: Colors.text,
    textAlign: 'center',
    marginBottom: 12,
    paddingHorizontal: 32,
  },
  profileButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  },
  editProfileButton: {
    paddingVertical: 6,
    paddingHorizontal: 14,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  editProfileText: {
    fontSize: 13,
    fontWeight: '500',
    color: Colors.text,
  },
  shareProfileButton: {
    paddingVertical: 6,
    paddingHorizontal: 14,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: Colors.border,
    flexDirection: 'row',
    alignItems: 'center',
  },
  shareIcon: {
    marginRight: 4,
  },
  shareProfileText: {
    fontSize: 13,
    fontWeight: '500',
    color: Colors.text,
  },
  rewardsContainer: {
    margin: 16,
    padding: 14,
    backgroundColor: Colors.card,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  rewardsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  rewardsTitle: {
    fontSize: 15,
    fontWeight: '600',
    color: Colors.text,
    marginLeft: 6,
  },
  rewardsPoints: {
    fontSize: 28,
    fontWeight: 'bold',
    color: Colors.primary,
    marginBottom: 12,
  },
  redeemButton: {
    paddingHorizontal: 14,
    paddingVertical: 6,
    backgroundColor: Colors.primary,
    borderRadius: 18,
  },
  redeemButtonText: {
    fontSize: 13,
    fontWeight: '500',
    color: Colors.background,
  },
  tabsContainer: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
    marginBottom: 12,
  },
  tabItem: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
  },
  activeTabItem: {
    borderBottomWidth: 2,
    borderBottomColor: Colors.primary,
  },
  tabText: {
    fontSize: 13,
    fontWeight: '500',
    color: Colors.textLight,
    marginLeft: 4,
  },
  activeTabText: {
    color: Colors.primary,
  },
  tabContent: {
    paddingHorizontal: 16,
    paddingBottom: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.text,
  },
  sectionCount: {
    fontSize: 13,
    color: Colors.textLight,
  },
  clearHistoryText: {
    fontSize: 13,
    color: Colors.primary,
    fontWeight: '500',
  },
  
  // Video Grid (Saved & Downloaded)
  videoGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  videoCard: {
    width: cardWidth,
    marginBottom: 16,
    backgroundColor: Colors.card,
    borderRadius: 8,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
    position: 'relative',
  },
  thumbnailContainer: {
    width: '100%',
    aspectRatio: 16 / 9,
    position: 'relative',
  },
  videoThumbnail: {
    width: '100%',
    height: '100%',
  },
  durationBadge: {
    position: 'absolute',
    bottom: 6,
    right: 6,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    paddingHorizontal: 4,
    paddingVertical: 1,
    borderRadius: 2,
  },
  durationText: {
    color: '#fff',
    fontSize: 11,
    fontWeight: '500',
  },
  videoInfo: {
    padding: 8,
    paddingRight: 28, // Make room for menu button
  },
  videoTitle: {
    fontSize: 13,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 2,
    lineHeight: 16,
  },
  videoCreator: {
    fontSize: 12,
    color: Colors.textLight,
    marginBottom: 2,
  },
  videoStats: {
    fontSize: 11,
    color: Colors.textLight,
  },
  menuButton: {
    position: 'absolute',
    top: 6,
    right: 6,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(0, 0, 0, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 10,
  },
  
  // History List
  historyList: {
    marginBottom: 16,
  },
  historyItem: {
    marginBottom: 12,
    backgroundColor: Colors.card,
    borderRadius: 8,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
    position: 'relative',
  },
  historyItemContent: {
    padding: 10,
    paddingRight: 36, // Make room for menu button
  },
  historyThumbnailContainer: {
    width: '100%',
    aspectRatio: 16 / 9,
    borderRadius: 6,
    overflow: 'hidden',
    marginBottom: 8,
    position: 'relative',
  },
  historyThumbnail: {
    width: '100%',
    height: '100%',
  },
  historyInfo: {
    paddingHorizontal: 2,
  },
  historyTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 2,
    lineHeight: 18,
  },
  historyCreator: {
    fontSize: 13,
    color: Colors.textLight,
    marginBottom: 2,
  },
  historyStats: {
    fontSize: 12,
    color: Colors.textLight,
  },
  historyMenuButton: {
    position: 'absolute',
    top: 10,
    right: 10,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(0, 0, 0, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 10,
  },
  
  // Photos Grid
  photoGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'flex-start',
    gap: 8,
  },
  photoItem: {
    width: photoWidth,
    aspectRatio: 1,
    marginBottom: 8,
    borderRadius: 6,
    overflow: 'hidden',
  },
  photo: {
    width: '100%',
    height: '100%',
  },
  
  // Empty States
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 28,
  },
  emptyText: {
    fontSize: 15,
    color: Colors.textLight,
    marginTop: 12,
    marginBottom: 12,
  },
  browseButton: {
    paddingHorizontal: 14,
    paddingVertical: 6,
    backgroundColor: Colors.primary,
    borderRadius: 18,
  },
  browseButtonText: {
    fontSize: 13,
    fontWeight: '500',
    color: Colors.background,
  },
  
  // Menu Modal
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  menuContainer: {
    position: 'absolute',
    width: 140,
    backgroundColor: Colors.card,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    overflow: 'hidden',
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  menuItemText: {
    fontSize: 13,
    color: Colors.text,
    marginLeft: 10,
  },
});