import React from "react";
import { Tabs } from "expo-router";
import { View } from "react-native";
import BottomTabBar from "@/components/BottomTabBar";

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
      }}
      tabBar={(props) => <BottomTabBar {...props} />}
    >
      <Tabs.Screen 
        name="index" 
        options={{
          headerShown: false,
        }}
      />
      <Tabs.Screen name="reels" />
      <Tabs.Screen name="stage" />
      <Tabs.Screen name="profile" />
    </Tabs>
  );
}