import React, { useState } from 'react';
import { View, StyleSheet, FlatList, RefreshControl, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import Header from '@/components/Header';
import CategoryList from '@/components/CategoryList';
import VideoCard from '@/components/VideoCard';
import ExploreSection from '@/components/ExploreSection';
import { getNonPremiumVideosByType } from '@/mocks/videos';
import { useAppStore } from '@/store/app-store';
import Colors from '@/constants/colors';

export default function HomeScreen() {
  const [refreshing, setRefreshing] = useState(false);
  const [isExploreActive, setIsExploreActive] = useState(false);
  const { selectedCategory } = useAppStore();
  
  // Get only regular videos for the home feed, excluding premium content
  // Changed from 'regular' to 'video' to match the updated type in mocks/videos.ts
  const regularVideos = getNonPremiumVideosByType('video');
  
  const filteredVideos = selectedCategory
    ? regularVideos.filter(video => video.category === selectedCategory)
    : regularVideos;
  
  const onRefresh = React.useCallback(() => {
    setRefreshing(true);
    // Simulate a network request
    setTimeout(() => {
      setRefreshing(false);
    }, 1000);
  }, []);

  const handleExplorePress = () => {
    setIsExploreActive(true);
  };

  const handleExploreBack = () => {
    setIsExploreActive(false);
  };
  
  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar style={Platform.OS === 'ios' ? 'dark' : 'auto'} />
      
      {isExploreActive ? (
        <ExploreSection onBackPress={handleExploreBack} />
      ) : (
        <>
          <Header />
          <FlatList
            data={filteredVideos}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => <VideoCard video={item} />}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.listContent}
            ListHeaderComponent={
              <CategoryList 
                onExplorePress={handleExplorePress} 
                isExploreActive={isExploreActive} 
              />
            }
            refreshControl={
              <RefreshControl
                refreshing={refreshing}
                onRefresh={onRefresh}
                colors={[Colors.primary]}
                tintColor={Colors.primary}
              />
            }
          />
        </>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  listContent: {
    paddingBottom: 16,
    paddingHorizontal: 0, // Removed horizontal padding to make videos full-width
  },
});