import React, { useState, useRef, useCallback, useEffect } from 'react';
import { View, StyleSheet, FlatList, Dimensions, Text, TouchableOpacity, Image, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Heart, MessageCircle, Share2, Users, MoreVertical, Music, Bookmark, Repeat, Play, Settings, Flag, Info, Send, UserPlus } from 'lucide-react-native';
import { getNonPremiumVideosByType } from '@/mocks/videos';
import { useUserStore } from '@/store/user-store';
import { formatNumber } from '@/utils/format';
import Colors from '@/constants/colors';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { Video } from '@/types';
import { useAppStore } from '@/store/app-store';

interface ViewToken {
  item: any;
  key: string;
  index: number | null;
  isViewable: boolean;
  section?: any;
}

interface ViewableItemsChanged {
  viewableItems: ViewToken[];
  changed: ViewToken[];
}

const { width, height } = Dimensions.get('window');

export default function ReelsScreen() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [showOptions, setShowOptions] = useState(false);
  const [showDescription, setShowDescription] = useState(false);
  const flatListRef = useRef<FlatList>(null);
  const router = useRouter();
  const { 
    isVideoLiked, 
    toggleLikeVideo, 
    isVideoSaved, 
    toggleSaveVideo,
    isUserFollowed,
    toggleFollowUser
  } = useUserStore();
  
  const { selectedReel, setSelectedReel } = useAppStore();
  
  // Get only reel videos for the reels feed, excluding premium content
  const reelVideos = getNonPremiumVideosByType('reel');
  
  // Find the index of the selected reel if any
  const selectedReelIndex = selectedReel ? reelVideos.findIndex(video => video.id === selectedReel) : -1;
  
  // Scroll to the selected reel when the component mounts
  useEffect(() => {
    if (selectedReel && selectedReelIndex !== -1 && flatListRef.current) {
      // Set a small delay to ensure the FlatList is rendered
      const timer = setTimeout(() => {
        flatListRef.current?.scrollToIndex({
          index: selectedReelIndex,
          animated: false,
        });
        setActiveIndex(selectedReelIndex);
        // Clear the selected reel after scrolling to it
        setSelectedReel(null);
      }, 100);
      
      return () => clearTimeout(timer);
    }
  }, [selectedReel, selectedReelIndex, setSelectedReel]);
  
  const handleViewableItemsChanged = useCallback(({ viewableItems }: ViewableItemsChanged) => {
    if (viewableItems.length > 0) {
      setActiveIndex(viewableItems[0].index || 0);
      setShowOptions(false); // Hide options when scrolling to new video
      setShowDescription(false); // Hide description when scrolling to new video
    }
  }, []);
  
  const viewabilityConfig = {
    itemVisiblePercentThreshold: 50,
  };
  
  const toggleOptions = () => {
    setShowOptions(!showOptions);
    setShowDescription(false); // Hide description when showing options
  };

  const toggleDescription = () => {
    setShowDescription(!showDescription);
    setShowOptions(false); // Hide options when showing description
  };

  const navigateToProfile = (userId: string) => {
    router.push(`/profile/${userId}`);
  };
  
  const renderItem = ({ item, index }: { item: Video; index: number }) => {
    const isLiked = isVideoLiked(item.id);
    const isSaved = isVideoSaved(item.id);
    const isFollowed = isUserFollowed(item.userId);
    const isActive = index === activeIndex;
    
    return (
      <View style={styles.reelContainer}>
        <Image source={{ uri: item.thumbnail }} style={styles.reelVideo} />
        
        {/* Top gradient overlay for better text visibility */}
        <LinearGradient
          colors={['rgba(0,0,0,0.5)', 'transparent']}
          style={styles.topGradient}
        />
        
        {/* Bottom gradient overlay for better text visibility */}
        <LinearGradient
          colors={['transparent', 'rgba(0,0,0,0.7)']}
          style={styles.bottomGradient}
        />
        
        <View style={styles.overlay}>
          {/* Top section with options button only */}
          <View style={styles.topSection}>
            <TouchableOpacity 
              onPress={() => {
                if (isActive) {
                  toggleOptions();
                }
              }} 
              style={styles.optionsButton}
              activeOpacity={0.7}
            >
              <MoreVertical size={22} color={Colors.background} />
            </TouchableOpacity>
          </View>
          
          {/* Options menu - YouTube Shorts style */}
          {showOptions && isActive && (
            <TouchableOpacity 
              activeOpacity={1}
              style={styles.optionsMenuOverlay}
              onPress={() => setShowOptions(false)}
            >
              <View style={styles.optionsMenu}>
                <TouchableOpacity 
                  style={styles.optionItem}
                  onPress={() => {
                    toggleSaveVideo(item.id);
                    setShowOptions(false);
                  }}
                >
                  <Bookmark 
                    size={18} 
                    color={Colors.background}
                    fill={isSaved ? Colors.background : 'transparent'}
                    style={styles.optionIcon}
                  />
                  <Text style={styles.optionText}>Save</Text>
                </TouchableOpacity>
                
                <TouchableOpacity style={styles.optionItem}>
                  <Flag size={18} color={Colors.background} style={styles.optionIcon} />
                  <Text style={styles.optionText}>Report</Text>
                </TouchableOpacity>
                
                <TouchableOpacity style={styles.optionItem}>
                  <Users size={18} color={Colors.background} style={styles.optionIcon} />
                  <Text style={styles.optionText}>Collab</Text>
                </TouchableOpacity>
                
                <TouchableOpacity style={styles.optionItem}>
                  <Info size={18} color={Colors.background} style={styles.optionIcon} />
                  <Text style={styles.optionText}>Not interested</Text>
                </TouchableOpacity>
                
                <TouchableOpacity style={styles.optionItem}>
                  <Repeat size={18} color={Colors.background} style={styles.optionIcon} />
                  <Text style={styles.optionText}>Remix this video</Text>
                </TouchableOpacity>
                
                <TouchableOpacity 
                  style={styles.optionItem}
                  onPress={toggleDescription}
                >
                  <Info size={18} color={Colors.background} style={styles.optionIcon} />
                  <Text style={styles.optionText}>Description</Text>
                </TouchableOpacity>
                
                <TouchableOpacity style={styles.optionItem}>
                  <Settings size={18} color={Colors.background} style={styles.optionIcon} />
                  <Text style={styles.optionText}>Quality</Text>
                </TouchableOpacity>
                
                <TouchableOpacity style={styles.optionItem}>
                  <Send size={18} color={Colors.background} style={styles.optionIcon} />
                  <Text style={styles.optionText}>Send Feedback</Text>
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          )}
          
          {/* Full description overlay */}
          {showDescription && isActive && (
            <TouchableOpacity 
              style={styles.descriptionOverlay}
              activeOpacity={1}
              onPress={() => setShowDescription(false)}
            >
              <View style={styles.descriptionContent}>
                <Text style={styles.descriptionTitle}>{item.title}</Text>
                <Text style={styles.descriptionText}>{item.description}</Text>
                <View style={styles.descriptionTags}>
                  {item.tags && item.tags.map((tag: string, idx: number) => (
                    <Text key={idx} style={styles.tagText}>#{tag}</Text>
                  ))}
                </View>
              </View>
            </TouchableOpacity>
          )}
          
          {/* Right side actions - Instagram style */}
          <View style={styles.actionsContainer}>
            <TouchableOpacity 
              style={styles.actionButton}
              onPress={() => toggleLikeVideo(item.id)}
            >
              <Heart 
                size={26} 
                color={isLiked ? Colors.error : Colors.background}
                fill={isLiked ? Colors.error : 'transparent'}
              />
              <Text style={styles.actionText}>{formatNumber(item.likes + (isLiked ? 1 : 0))}</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.actionButton}>
              <MessageCircle size={26} color={Colors.background} />
              <Text style={styles.actionText}>{formatNumber(item.comments)}</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.actionButton}>
              <Share2 size={26} color={Colors.background} />
              <Text style={styles.actionText}>Share</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.actionButton}>
              <Repeat size={26} color={Colors.background} />
              <Text style={styles.actionText}>Remix</Text>
            </TouchableOpacity>
          </View>
          
          {/* Bottom info section */}
          <View style={styles.infoContainer}>
            <View style={styles.userInfoContainer}>
              {/* User profile section - Moved from top to bottom */}
              <View style={styles.userInfoRow}>
                <TouchableOpacity 
                  style={styles.userInfo}
                  onPress={() => navigateToProfile(item.userId)}
                >
                  <Image source={{ uri: item.user?.avatar }} style={styles.smallAvatar} />
                  <Text style={styles.username}>{item.user?.name}</Text>
                </TouchableOpacity>
                
                <TouchableOpacity 
                  style={[
                    styles.followButton, 
                    isFollowed && styles.followingButton
                  ]}
                  onPress={() => toggleFollowUser(item.userId)}
                >
                  <Text style={[
                    styles.followButtonText,
                    isFollowed && styles.followingButtonText
                  ]}>
                    {isFollowed ? 'Following' : 'Follow'}
                  </Text>
                </TouchableOpacity>
              </View>
              
              {/* Caption */}
              <View style={styles.captionContainer}>
                <TouchableOpacity 
                  onPress={() => navigateToProfile(item.userId)}
                  style={styles.captionUsernameContainer}
                >
                  <Text style={styles.captionUsername}>@{item.user?.username}</Text>
                </TouchableOpacity>
                <Text style={styles.captionText}>{item.title}</Text>
              </View>
            </View>
            
            {/* Music info */}
            <View style={styles.musicContainer}>
              <Music size={14} color={Colors.background} />
              <Text style={styles.musicText}>
                Original Audio • {item.user?.name}
              </Text>
              <View style={styles.musicIconContainer}>
                <Play size={10} color={Colors.background} fill={Colors.background} />
              </View>
            </View>
          </View>
        </View>
      </View>
    );
  };

  // Handle errors when scrolling to index
  const handleScrollToIndexFailed = (info: {
    index: number;
    highestMeasuredFrameIndex: number;
    averageItemLength: number;
  }) => {
    const wait = new Promise(resolve => setTimeout(resolve, 500));
    wait.then(() => {
      flatListRef.current?.scrollToIndex({ index: info.index, animated: false });
    });
  };
  
  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      
      <FlatList
        ref={flatListRef}
        data={reelVideos}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        pagingEnabled
        showsVerticalScrollIndicator={false}
        onViewableItemsChanged={handleViewableItemsChanged}
        viewabilityConfig={viewabilityConfig}
        snapToInterval={height}
        decelerationRate="fast"
        onScrollToIndexFailed={handleScrollToIndexFailed}
        initialNumToRender={3}
        maxToRenderPerBatch={3}
        windowSize={5}
      />
      
      <SafeAreaView style={styles.header} edges={['top']}>
        <Text style={styles.headerTitle}>Reels</Text>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.background,
  },
  reelContainer: {
    width,
    height,
    backgroundColor: '#000',
  },
  reelVideo: {
    width: '100%',
    height: '100%',
    position: 'absolute',
    resizeMode: 'cover',
  },
  topGradient: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 80,
  },
  bottomGradient: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 180,
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'space-between',
    padding: 16,
  },
  topSection: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginTop: Platform.OS === 'ios' ? 40 : 20,
  },
  optionsButton: {
    padding: 8,
    zIndex: 20,
  },
  optionsMenuOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    zIndex: 30,
    justifyContent: 'flex-start',
    alignItems: 'flex-end',
  },
  optionsMenu: {
    marginTop: Platform.OS === 'ios' ? 80 : 60,
    marginRight: 16,
    backgroundColor: 'rgba(0, 0, 0, 0.85)',
    borderRadius: 12,
    padding: 8,
    width: 200,
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  optionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 14,
  },
  optionIcon: {
    marginRight: 10,
  },
  optionText: {
    color: Colors.background,
    fontSize: 14,
  },
  descriptionOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.85)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 30,
  },
  descriptionContent: {
    width: '80%',
    padding: 20,
    borderRadius: 12,
    backgroundColor: 'rgba(30, 30, 30, 0.9)',
  },
  descriptionTitle: {
    color: Colors.background,
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  descriptionText: {
    color: Colors.background,
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 14,
  },
  descriptionTags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 6,
  },
  tagText: {
    color: Colors.primary,
    fontSize: 13,
    marginRight: 8,
    marginBottom: 4,
  },
  actionsContainer: {
    position: 'absolute',
    right: 16,
    bottom: 120,
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionButton: {
    alignItems: 'center',
    marginBottom: 14,
  },
  actionText: {
    color: Colors.background,
    fontSize: 12,
    marginTop: 4,
  },
  infoContainer: {
    position: 'absolute',
    left: 16,
    right: 80,
    bottom: 16,
    justifyContent: 'flex-end',
  },
  userInfoContainer: {
    marginBottom: 8,
  },
  userInfoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  smallAvatar: {
    width: 30,
    height: 30,
    borderRadius: 15,
    marginRight: 8,
    borderWidth: 1,
    borderColor: Colors.background,
  },
  username: {
    color: Colors.background,
    fontSize: 15,
    fontWeight: 'bold',
  },
  captionContainer: {
    marginBottom: 8,
  },
  captionUsernameContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 2,
  },
  captionUsername: {
    color: Colors.background,
    fontWeight: 'bold',
    fontSize: 13,
  },
  captionText: {
    color: Colors.background,
    fontSize: 13,
    lineHeight: 18,
  },
  followButton: {
    backgroundColor: Colors.primary,
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 4,
  },
  followingButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: Colors.background,
  },
  followButtonText: {
    color: Colors.background,
    fontSize: 12,
    fontWeight: 'bold',
  },
  followingButtonText: {
    color: Colors.background,
  },
  musicContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 6,
  },
  musicText: {
    color: Colors.background,
    fontSize: 13,
    marginLeft: 6,
    flex: 1,
  },
  musicIconContainer: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
});