import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, Image, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useRouter } from 'expo-router';
import { Upload, Image as ImageIcon, X, ChevronDown, Tag, Globe, Lock, Users, ArrowLeft } from 'lucide-react-native';
import * as ImagePicker from 'expo-image-picker';
import { categories } from '@/mocks/categories';
import Colors from '@/constants/colors';

export default function UploadScreen() {
  const router = useRouter();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [showCategoryPicker, setShowCategoryPicker] = useState(false);
  const [tags, setTags] = useState<string[]>([]);
  const [currentTag, setCurrentTag] = useState('');
  const [visibility, setVisibility] = useState('public');
  const [thumbnailUri, setThumbnailUri] = useState<string | null>(null);
  const [videoUri, setVideoUri] = useState<string | null>(null);
  
  const pickVideo = async () => {
    // No permissions request is necessary for launching the image library
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Videos,
      allowsEditing: true,
      quality: 1,
    });
    
    if (!result.canceled) {
      setVideoUri(result.assets[0].uri);
    }
  };
  
  const pickThumbnail = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [16, 9],
      quality: 1,
    });
    
    if (!result.canceled) {
      setThumbnailUri(result.assets[0].uri);
    }
  };
  
  const addTag = () => {
    if (currentTag.trim() && !tags.includes(currentTag.trim())) {
      setTags([...tags, currentTag.trim()]);
      setCurrentTag('');
    }
  };
  
  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };
  
  const handleUpload = () => {
    // In a real app, we would upload the video to the server
    // For now, just navigate back
    router.back();
  };

  const handleBack = () => {
    router.back();
  };
  
  const isFormValid = title.trim() && description.trim() && selectedCategory && videoUri;
  
  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar style="dark" />
      
      <View style={styles.header}>
        <TouchableOpacity onPress={handleBack} style={styles.backButton}>
          <ArrowLeft size={24} color={Colors.text} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Upload Video</Text>
        <TouchableOpacity 
          style={[
            styles.uploadButton,
            !isFormValid && styles.uploadButtonDisabled
          ]}
          onPress={handleUpload}
          disabled={!isFormValid}
        >
          <Text 
            style={[
              styles.uploadButtonText,
              !isFormValid && styles.uploadButtonTextDisabled
            ]}
          >
            Upload
          </Text>
        </TouchableOpacity>
      </View>
      
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.formContainer}>
          {!videoUri ? (
            <TouchableOpacity 
              style={styles.videoPickerContainer}
              onPress={pickVideo}
            >
              <Upload size={48} color={Colors.primary} />
              <Text style={styles.videoPickerText}>Tap to select a video</Text>
              <Text style={styles.videoPickerSubtext}>MP4, MOV, or AVI format</Text>
            </TouchableOpacity>
          ) : (
            <View style={styles.videoPreviewContainer}>
              <View style={styles.videoPreview}>
                <Text style={styles.videoPreviewText}>Video selected</Text>
                <TouchableOpacity 
                  style={styles.videoPreviewChangeButton}
                  onPress={pickVideo}
                >
                  <Text style={styles.videoPreviewChangeText}>Change</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
          
          <View style={styles.formGroup}>
            <Text style={styles.label}>Title</Text>
            <TextInput
              style={styles.input}
              placeholder="Add a title that describes your video"
              value={title}
              onChangeText={setTitle}
              maxLength={100}
            />
            <Text style={styles.charCount}>{title.length}/100</Text>
          </View>
          
          <View style={styles.formGroup}>
            <Text style={styles.label}>Description</Text>
            <TextInput
              style={styles.textArea}
              placeholder="Tell viewers about your video"
              value={description}
              onChangeText={setDescription}
              multiline
              numberOfLines={4}
              maxLength={5000}
            />
            <Text style={styles.charCount}>{description.length}/5000</Text>
          </View>
          
          <View style={styles.formGroup}>
            <Text style={styles.label}>Thumbnail</Text>
            <TouchableOpacity 
              style={styles.thumbnailPickerContainer}
              onPress={pickThumbnail}
            >
              {thumbnailUri ? (
                <Image source={{ uri: thumbnailUri }} style={styles.thumbnailPreview} />
              ) : (
                <View style={styles.thumbnailPlaceholder}>
                  <ImageIcon size={24} color={Colors.textLight} />
                  <Text style={styles.thumbnailPlaceholderText}>Add thumbnail</Text>
                </View>
              )}
            </TouchableOpacity>
          </View>
          
          <View style={styles.formGroup}>
            <Text style={styles.label}>Category</Text>
            <TouchableOpacity 
              style={styles.categoryPickerButton}
              onPress={() => setShowCategoryPicker(!showCategoryPicker)}
            >
              <Text 
                style={[
                  styles.categoryPickerText,
                  !selectedCategory && styles.categoryPickerPlaceholder
                ]}
              >
                {selectedCategory || 'Select a category'}
              </Text>
              <ChevronDown size={20} color={Colors.textLight} />
            </TouchableOpacity>
            
            {showCategoryPicker && (
              <View style={styles.categoryPickerContainer}>
                {categories.map((category) => (
                  <TouchableOpacity
                    key={category.id}
                    style={[
                      styles.categoryItem,
                      selectedCategory === category.name && styles.selectedCategoryItem
                    ]}
                    onPress={() => {
                      setSelectedCategory(category.name);
                      setShowCategoryPicker(false);
                    }}
                  >
                    <Text 
                      style={[
                        styles.categoryItemText,
                        selectedCategory === category.name && styles.selectedCategoryItemText
                      ]}
                    >
                      {category.name}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </View>
          
          <View style={styles.formGroup}>
            <Text style={styles.label}>Tags</Text>
            <View style={styles.tagInputContainer}>
              <View style={styles.tagInput}>
                <Tag size={20} color={Colors.textLight} style={styles.tagIcon} />
                <TextInput
                  style={styles.tagInputField}
                  placeholder="Add tags"
                  value={currentTag}
                  onChangeText={setCurrentTag}
                  onSubmitEditing={addTag}
                  returnKeyType="done"
                />
              </View>
              <TouchableOpacity 
                style={[
                  styles.addTagButton,
                  !currentTag.trim() && styles.addTagButtonDisabled
                ]}
                onPress={addTag}
                disabled={!currentTag.trim()}
              >
                <Text 
                  style={[
                    styles.addTagButtonText,
                    !currentTag.trim() && styles.addTagButtonTextDisabled
                  ]}
                >
                  Add
                </Text>
              </TouchableOpacity>
            </View>
            
            {tags.length > 0 && (
              <View style={styles.tagsContainer}>
                {tags.map((tag, index) => (
                  <View key={index} style={styles.tagItem}>
                    <Text style={styles.tagItemText}>{tag}</Text>
                    <TouchableOpacity 
                      style={styles.removeTagButton}
                      onPress={() => removeTag(tag)}
                    >
                      <X size={16} color={Colors.textLight} />
                    </TouchableOpacity>
                  </View>
                ))}
              </View>
            )}
          </View>
          
          <View style={styles.formGroup}>
            <Text style={styles.label}>Visibility</Text>
            <View style={styles.visibilityOptions}>
              <TouchableOpacity 
                style={[
                  styles.visibilityOption,
                  visibility === 'public' && styles.selectedVisibilityOption
                ]}
                onPress={() => setVisibility('public')}
              >
                <Globe size={20} color={visibility === 'public' ? Colors.primary : Colors.textLight} />
                <Text 
                  style={[
                    styles.visibilityOptionText,
                    visibility === 'public' && styles.selectedVisibilityOptionText
                  ]}
                >
                  Public
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[
                  styles.visibilityOption,
                  visibility === 'private' && styles.selectedVisibilityOption
                ]}
                onPress={() => setVisibility('private')}
              >
                <Lock size={20} color={visibility === 'private' ? Colors.primary : Colors.textLight} />
                <Text 
                  style={[
                    styles.visibilityOptionText,
                    visibility === 'private' && styles.selectedVisibilityOptionText
                  ]}
                >
                  Private
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[
                  styles.visibilityOption,
                  visibility === 'unlisted' && styles.selectedVisibilityOption
                ]}
                onPress={() => setVisibility('unlisted')}
              >
                <Users size={20} color={visibility === 'unlisted' ? Colors.primary : Colors.textLight} />
                <Text 
                  style={[
                    styles.visibilityOptionText,
                    visibility === 'unlisted' && styles.selectedVisibilityOptionText
                  ]}
                >
                  Unlisted
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  backButton: {
    padding: 4,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
    flex: 1,
    textAlign: 'center',
  },
  uploadButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: Colors.primary,
    borderRadius: 20,
  },
  uploadButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.background,
  },
  uploadButtonDisabled: {
    backgroundColor: Colors.inactive,
  },
  uploadButtonTextDisabled: {
    color: Colors.background,
  },
  formContainer: {
    padding: 16,
  },
  videoPickerContainer: {
    width: '100%',
    height: 200,
    borderWidth: 2,
    borderColor: Colors.border,
    borderStyle: 'dashed',
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 24,
  },
  videoPickerText: {
    fontSize: 16,
    fontWeight: '500',
    color: Colors.text,
    marginTop: 12,
  },
  videoPickerSubtext: {
    fontSize: 14,
    color: Colors.textLight,
    marginTop: 4,
  },
  videoPreviewContainer: {
    width: '100%',
    height: 200,
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 24,
    backgroundColor: Colors.card,
  },
  videoPreview: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  videoPreviewText: {
    fontSize: 16,
    fontWeight: '500',
    color: Colors.text,
    marginBottom: 12,
  },
  videoPreviewChangeButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: Colors.primary,
    borderRadius: 20,
  },
  videoPreviewChangeText: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.background,
  },
  formGroup: {
    marginBottom: 24,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 8,
  },
  input: {
    width: '100%',
    height: 48,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    paddingHorizontal: 16,
    fontSize: 16,
    color: Colors.text,
  },
  textArea: {
    width: '100%',
    height: 120,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    color: Colors.text,
    textAlignVertical: 'top',
  },
  charCount: {
    fontSize: 12,
    color: Colors.textLight,
    alignSelf: 'flex-end',
    marginTop: 4,
  },
  thumbnailPickerContainer: {
    width: '100%',
    height: 160,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    overflow: 'hidden',
  },
  thumbnailPlaceholder: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.card,
  },
  thumbnailPlaceholderText: {
    fontSize: 14,
    color: Colors.textLight,
    marginTop: 8,
  },
  thumbnailPreview: {
    width: '100%',
    height: '100%',
  },
  categoryPickerButton: {
    width: '100%',
    height: 48,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  categoryPickerText: {
    fontSize: 16,
    color: Colors.text,
  },
  categoryPickerPlaceholder: {
    color: Colors.textLight,
  },
  categoryPickerContainer: {
    marginTop: 8,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    overflow: 'hidden',
  },
  categoryItem: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  selectedCategoryItem: {
    backgroundColor: Colors.primary,
  },
  categoryItemText: {
    fontSize: 16,
    color: Colors.text,
  },
  selectedCategoryItemText: {
    color: Colors.background,
    fontWeight: '500',
  },
  tagInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  tagInput: {
    flex: 1,
    height: 48,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 8,
  },
  tagIcon: {
    marginRight: 8,
  },
  tagInputField: {
    flex: 1,
    fontSize: 16,
    color: Colors.text,
  },
  addTagButton: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: Colors.primary,
    borderRadius: 8,
  },
  addTagButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.background,
  },
  addTagButtonDisabled: {
    backgroundColor: Colors.inactive,
  },
  addTagButtonTextDisabled: {
    color: Colors.background,
  },
  tagsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 12,
  },
  tagItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.card,
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 6,
    marginRight: 8,
    marginBottom: 8,
  },
  tagItemText: {
    fontSize: 14,
    color: Colors.text,
    marginRight: 4,
  },
  removeTagButton: {
    padding: 2,
  },
  visibilityOptions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  visibilityOption: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    marginHorizontal: 4,
  },
  selectedVisibilityOption: {
    borderColor: Colors.primary,
    backgroundColor: 'rgba(0, 119, 182, 0.05)',
  },
  visibilityOptionText: {
    fontSize: 14,
    color: Colors.text,
    marginTop: 4,
  },
  selectedVisibilityOptionText: {
    color: Colors.primary,
    fontWeight: '500',
  },
});