import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, FlatList } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { ArrowLeft, Share2, Play, ListVideo, Clock, User } from 'lucide-react-native';
import { getPlaylistById, getPlaylistVideos } from '@/mocks/playlists';
import { getUserById } from '@/mocks/users';
import { useUserStore } from '@/store/user-store';
import Colors from '@/constants/colors';
import VideoCard from '@/components/VideoCard';
import { formatNumber, formatDuration, formatTimeAgo } from '@/utils/format';

export default function PlaylistScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { isUserFollowed, toggleFollowUser } = useUserStore();
  
  const playlist = getPlaylistById(id);
  const videos = getPlaylistVideos(id);
  
  if (!playlist) {
    return (
      <SafeAreaView style={styles.container}>
        <Stack.Screen options={{ headerShown: false }} />
        <StatusBar style="light" />
        <View style={styles.notFoundContainer}>
          <Text style={styles.notFoundText}>Playlist not found</Text>
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => router.back()}
          >
            <Text style={styles.backButtonText}>Go Back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }
  
  const user = getUserById(playlist.userId);
  const isFollowing = user ? isUserFollowed(user.id) : false;
  
  const handleBack = () => {
    router.back();
  };
  
  const handleShare = () => {
    // Share functionality would go here
    console.log('Share playlist:', id);
  };
  
  const handlePlayAll = () => {
    if (videos.length > 0) {
      router.push(`/video/${videos[0].id}?playlist=${playlist.id}`);
    }
  };
  
  const handleUserPress = () => {
    if (user) {
      router.push(`/profile/${user.id}`);
    }
  };
  
  const handleFollowToggle = () => {
    if (user) {
      toggleFollowUser(user.id);
    }
  };
  
  const totalDuration = videos.reduce((total, video) => total + video.duration, 0);
  
  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <Stack.Screen options={{ headerShown: false }} />
      <StatusBar style="light" />
      
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={handleBack}
        >
          <ArrowLeft size={24} color={Colors.text} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Playlist</Text>
        <TouchableOpacity 
          style={styles.shareButton}
          onPress={handleShare}
        >
          <Share2 size={24} color={Colors.text} />
        </TouchableOpacity>
      </View>
      
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.playlistHeader}>
          <Image 
            source={{ uri: playlist.thumbnail }} 
            style={styles.thumbnail}
          />
          
          <View style={styles.playlistInfo}>
            <Text style={styles.playlistTitle}>{playlist.title}</Text>
            
            {playlist.description && (
              <Text style={styles.playlistDescription}>{playlist.description}</Text>
            )}
            
            <View style={styles.statsContainer}>
              <View style={styles.statItem}>
                <ListVideo size={16} color={Colors.textLight} />
                <Text style={styles.statText}>{videos.length} videos</Text>
              </View>
              
              <View style={styles.statItem}>
                <Clock size={16} color={Colors.textLight} />
                <Text style={styles.statText}>{formatDuration(totalDuration)}</Text>
              </View>
              
              <View style={styles.statItem}>
                <Text style={styles.statText}>{formatNumber(playlist.viewCount)} views</Text>
              </View>
            </View>
            
            <TouchableOpacity 
              style={styles.playAllButton}
              onPress={handlePlayAll}
              disabled={videos.length === 0}
            >
              <Play size={20} color={Colors.background} />
              <Text style={styles.playAllText}>Play All</Text>
            </TouchableOpacity>
            
            {user && (
              <View style={styles.creatorContainer}>
                <TouchableOpacity 
                  style={styles.creatorInfo}
                  onPress={handleUserPress}
                >
                  <Image 
                    source={{ uri: user.avatar }} 
                    style={styles.creatorAvatar}
                  />
                  <View>
                    <Text style={styles.creatorName}>{user.name}</Text>
                    <Text style={styles.creatorUsername}>@{user.username}</Text>
                  </View>
                </TouchableOpacity>
                
                <TouchableOpacity 
                  style={[
                    styles.followButton,
                    isFollowing && styles.followingButton
                  ]}
                  onPress={handleFollowToggle}
                >
                  <Text 
                    style={[
                      styles.followButtonText,
                      isFollowing && styles.followingButtonText
                    ]}
                  >
                    {isFollowing ? 'Following' : 'Follow'}
                  </Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        </View>
        
        <View style={styles.videosContainer}>
          <Text style={styles.sectionTitle}>Videos</Text>
          
          {videos.length > 0 ? (
            videos.map((video, index) => (
              <View key={video.id} style={styles.videoItem}>
                <Text style={styles.videoIndex}>{index + 1}</Text>
                <View style={styles.videoCardContainer}>
                  <VideoCard video={video} />
                </View>
              </View>
            ))
          ) : (
            <View style={styles.emptyContainer}>
              <ListVideo size={40} color={Colors.textLight} />
              <Text style={styles.emptyText}>This playlist has no videos</Text>
            </View>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  notFoundContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  notFoundText: {
    fontSize: 18,
    color: Colors.text,
    marginBottom: 20,
  },
  backButtonText: {
    color: Colors.primary,
    fontWeight: '500',
    fontSize: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
  },
  shareButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  playlistHeader: {
    padding: 16,
  },
  thumbnail: {
    width: '100%',
    height: 200,
    borderRadius: 12,
    marginBottom: 16,
  },
  playlistInfo: {
    gap: 12,
  },
  playlistTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.text,
  },
  playlistDescription: {
    fontSize: 16,
    color: Colors.text,
    lineHeight: 22,
  },
  statsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  statText: {
    fontSize: 14,
    color: Colors.textLight,
  },
  playAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.primary,
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
    marginTop: 8,
    gap: 8,
  },
  playAllText: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.background,
  },
  creatorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  creatorInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  creatorAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  creatorName: {
    fontSize: 16,
    fontWeight: '500',
    color: Colors.text,
  },
  creatorUsername: {
    fontSize: 14,
    color: Colors.textLight,
  },
  followButton: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    backgroundColor: Colors.primary,
  },
  followingButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: Colors.border,
  },
  followButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.background,
  },
  followingButtonText: {
    color: Colors.text,
  },
  videosContainer: {
    padding: 16,
    paddingBottom: 32,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 16,
  },
  videoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  videoIndex: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.textLight,
    width: 30,
    textAlign: 'center',
  },
  videoCardContainer: {
    flex: 1,
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyText: {
    fontSize: 16,
    color: Colors.textLight,
    marginTop: 16,
  },
});