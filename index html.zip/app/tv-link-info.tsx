import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { ArrowLeft, Tv, Monitor, Smartphone, Laptop } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import Colors from '@/constants/colors';

export default function TvLinkInfoScreen() {
  const router = useRouter();
  
  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar style="dark" />
      
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ArrowLeft size={24} color={Colors.text} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>TV Link</Text>
        <View style={styles.placeholder} />
      </View>
      
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.heroSection}>
          <Tv size={64} color={Colors.primary} />
          <Text style={styles.heroTitle}>Watch Prosea on your TV</Text>
          <Text style={styles.heroSubtitle}>
            Enjoy your favorite ocean content on the big screen
          </Text>
        </View>
        
        <View style={styles.infoSection}>
          <Text style={styles.sectionTitle}>How it works</Text>
          
          <View style={styles.stepContainer}>
            <View style={styles.stepIconContainer}>
              <Smartphone size={24} color={Colors.background} />
            </View>
            <View style={styles.stepContent}>
              <Text style={styles.stepTitle}>Step 1: Open Prosea on your TV</Text>
              <Text style={styles.stepDescription}>
                Launch the Prosea app on your smart TV, streaming device, or game console.
              </Text>
            </View>
          </View>
          
          <View style={styles.stepContainer}>
            <View style={styles.stepIconContainer}>
              <Monitor size={24} color={Colors.background} />
            </View>
            <View style={styles.stepContent}>
              <Text style={styles.stepTitle}>Step 2: Get the link code</Text>
              <Text style={styles.stepDescription}>
                A unique code will appear on your TV screen. Keep this code handy.
              </Text>
            </View>
          </View>
          
          <View style={styles.stepContainer}>
            <View style={styles.stepIconContainer}>
              <Laptop size={24} color={Colors.background} />
            </View>
            <View style={styles.stepContent}>
              <Text style={styles.stepTitle}>Step 3: Link your devices</Text>
              <Text style={styles.stepDescription}>
                On your mobile device, tap the TV icon and enter the code from your TV.
              </Text>
            </View>
          </View>
        </View>
        
        <View style={styles.infoSection}>
          <Text style={styles.sectionTitle}>Supported Devices</Text>
          
          <View style={styles.deviceList}>
            <View style={styles.deviceItem}>
              <Text style={styles.deviceName}>Smart TVs</Text>
              <Text style={styles.deviceDescription}>Samsung, LG, Sony, etc.</Text>
            </View>
            
            <View style={styles.deviceItem}>
              <Text style={styles.deviceName}>Streaming Devices</Text>
              <Text style={styles.deviceDescription}>Apple TV, Roku, Fire TV, etc.</Text>
            </View>
            
            <View style={styles.deviceItem}>
              <Text style={styles.deviceName}>Game Consoles</Text>
              <Text style={styles.deviceDescription}>PlayStation, Xbox, etc.</Text>
            </View>
            
            <View style={styles.deviceItem}>
              <Text style={styles.deviceName}>Chromecast</Text>
              <Text style={styles.deviceDescription}>All generations supported</Text>
            </View>
          </View>
        </View>
        
        <TouchableOpacity style={styles.linkButton}>
          <Text style={styles.linkButtonText}>Link with TV Now</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  backButton: {
    padding: 4,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
  },
  placeholder: {
    width: 32,
  },
  content: {
    flex: 1,
  },
  heroSection: {
    alignItems: 'center',
    padding: 24,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  heroTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.text,
    marginTop: 16,
    marginBottom: 8,
    textAlign: 'center',
  },
  heroSubtitle: {
    fontSize: 16,
    color: Colors.textLight,
    textAlign: 'center',
    lineHeight: 22,
  },
  infoSection: {
    padding: 24,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 16,
  },
  stepContainer: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  stepIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  stepContent: {
    flex: 1,
  },
  stepTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 4,
  },
  stepDescription: {
    fontSize: 14,
    color: Colors.textLight,
    lineHeight: 20,
  },
  deviceList: {
    gap: 16,
  },
  deviceItem: {
    backgroundColor: Colors.card,
    borderRadius: 12,
    padding: 16,
  },
  deviceName: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 4,
  },
  deviceDescription: {
    fontSize: 14,
    color: Colors.textLight,
  },
  linkButton: {
    backgroundColor: Colors.primary,
    marginHorizontal: 24,
    marginVertical: 24,
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  linkButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.background,
  },
});