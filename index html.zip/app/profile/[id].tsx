import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, Dimensions, Modal, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { ArrowLeft, Bell, BellOff, Share2, ExternalLink, Video, Film, Theater, Image as ImageIcon, Lock, ListVideo, X } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { getUserById } from '@/mocks/users';
import { videos, getNonPremiumVideosByType } from '@/mocks/videos';
import { getPlaylistsByUser } from '@/mocks/playlists';
import { useUserStore } from '@/store/user-store';
import { useAppStore } from '@/store/app-store';
import Colors from '@/constants/colors';
import VideoCard from '@/components/VideoCard';
import ReelCard from '@/components/ReelCard';
import StageCard from '@/components/StageCard';
import PlaylistCard from '@/components/PlaylistCard';
import { formatNumber, formatTimeAgo } from '@/utils/format';

const { width } = Dimensions.get('window');

// Mock photos data - in a real app, this would come from an API or store
const mockPhotos = [
  { id: 'p1', imageUrl: 'https://images.unsplash.com/photo-1518791841217-8f162f1e1131?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60' },
  { id: 'p2', imageUrl: 'https://images.unsplash.com/photo-1583512603805-3cc6b41f3edb?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60' },
  { id: 'p3', imageUrl: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60' },
  { id: 'p4', imageUrl: 'https://images.unsplash.com/photo-1583337130417-3346a1be7dee?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60' },
  { id: 'p5', imageUrl: 'https://images.unsplash.com/photo-1588943211346-0908a1fb0b01?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60' },
  { id: 'p6', imageUrl: 'https://images.unsplash.com/photo-1583435328903-d3dbc0dce273?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60' },
  { id: 'p7', imageUrl: 'https://images.unsplash.com/photo-1583425423320-2386622cd2e4?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60' },
  { id: 'p8', imageUrl: 'https://images.unsplash.com/photo-1583468323330-9032ad490fed?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60' },
  { id: 'p9', imageUrl: 'https://images.unsplash.com/photo-1583562835057-a62d1beffbf3?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60' },
];

export default function ProfileScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { isUserFollowed, toggleFollowUser } = useUserStore();
  const { isPremium } = useAppStore();
  const [activeTab, setActiveTab] = useState('videos');
  const [expandedBio, setExpandedBio] = useState(false);
  const [collabModalVisible, setCollabModalVisible] = useState(false);
  const [collabMessage, setCollabMessage] = useState('');
  
  const user = getUserById(id);
  
  // Get user's videos, filtering out premium content if user is not premium
  const userVideos = videos.filter(video => 
    video.userId === id && 
    video.type === 'video' && 
    (isPremium || !video.isPremium)
  );
  
  const userReels = videos.filter(video => 
    video.userId === id && 
    video.type === 'reel' && 
    (isPremium || !video.isPremium)
  );
  
  const userStages = videos.filter(video => 
    video.userId === id && 
    video.type === 'stage' && 
    (isPremium || !video.isPremium)
  );
  
  // Get user's playlists
  const userPlaylists = getPlaylistsByUser(id);
  
  // Get user's photos (in a real app, this would be fetched from an API)
  const userPhotos = mockPhotos;
  
  const handleBack = () => {
    router.back();
  };
  
  const handleFollow = () => {
    if (user) {
      toggleFollowUser(user.id);
    }
  };
  
  const handleCollab = () => {
    // Open the collab modal instead of navigating
    setCollabModalVisible(true);
  };
  
  const handleSendCollabRequest = () => {
    // Here you would send the collab request
    console.log('Sending collab request to:', user?.name);
    console.log('Message:', collabMessage);
    
    // Close the modal and reset the message
    setCollabModalVisible(false);
    setCollabMessage('');
    
    // Show a success message or notification (in a real app)
    // For now, we'll just log it
    console.log('Collab request sent successfully!');
  };
  
  const handleCloseModal = () => {
    setCollabModalVisible(false);
    setCollabMessage('');
  };
  
  const handleShare = () => {
    // Share functionality would go here
    console.log('Share profile:', id);
  };
  
  const handleWebsitePress = () => {
    // Open website functionality would go here
    console.log('Open website:', user?.website);
  };
  
  const handlePhotoPress = (photoId: string) => {
    // Handle photo press - in a real app, this might open a full-screen view
    console.log('Photo pressed:', photoId);
  };
  
  const following = user ? isUserFollowed(user.id) : false;
  
  if (!user) {
    return (
      <View style={styles.notFoundContainer}>
        <Text style={styles.notFoundText}>User not found</Text>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => router.push('/')}
        >
          <Text style={styles.backButtonText}>Go Home</Text>
        </TouchableOpacity>
      </View>
    );
  }
  
  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar style="light" />
      
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.bannerContainer}>
          <LinearGradient
            colors={['#3B82F6', '#93C5FD']}
            style={styles.banner}
          />
          <View style={styles.headerActions}>
            <TouchableOpacity 
              style={styles.backButton}
              onPress={handleBack}
            >
              <ArrowLeft size={24} color={Colors.background} />
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.shareButton}
              onPress={handleShare}
            >
              <Share2 size={24} color={Colors.background} />
            </TouchableOpacity>
          </View>
        </View>
        
        <View style={styles.profileHeader}>
          <View style={styles.avatarContainer}>
            <Image 
              source={{ uri: user.avatar }} 
              style={styles.avatar} 
            />
          </View>
          
          <Text style={styles.userName}>
            {user.name}
            {user.isVerified && (
              <Text style={styles.verifiedBadge}> ✓</Text>
            )}
          </Text>
          
          <Text style={styles.userHandle}>@{user.username}</Text>
          
          <View style={styles.statsContainer}>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{formatNumber(user.followers)}</Text>
              <Text style={styles.statLabel}>Followers</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{user.videos || userVideos.length + userReels.length + userStages.length}</Text>
              <Text style={styles.statLabel}>Videos</Text>
            </View>
          </View>
          
          {user.bio && (
            <TouchableOpacity 
              style={styles.bioContainer}
              onPress={() => setExpandedBio(!expandedBio)}
              activeOpacity={0.8}
            >
              <Text 
                style={styles.bioText}
                numberOfLines={expandedBio ? undefined : 2}
              >
                {user.bio}
              </Text>
              {!expandedBio && user.bio.length > 80 && (
                <Text style={styles.readMoreText}>...more</Text>
              )}
            </TouchableOpacity>
          )}
          
          {user.website && (
            <TouchableOpacity 
              style={styles.websiteContainer}
              onPress={handleWebsitePress}
            >
              <ExternalLink size={16} color={Colors.primary} />
              <Text style={styles.websiteText}>{user.website}</Text>
            </TouchableOpacity>
          )}
          
          <View style={styles.actionButtonsContainer}>
            <TouchableOpacity 
              style={[
                styles.followButton,
                following && styles.followingButton
              ]}
              onPress={handleFollow}
            >
              <Text 
                style={[
                  styles.followButtonText,
                  following && styles.followingButtonText
                ]}
              >
                {following ? 'Following' : 'Follow'}
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.collabButton}
              onPress={handleCollab}
            >
              <Text style={styles.collabButtonText}>Collab</Text>
            </TouchableOpacity>
            
            {following && (
              <TouchableOpacity style={styles.bellButton}>
                <Bell size={20} color={Colors.text} />
              </TouchableOpacity>
            )}
          </View>
        </View>
        
        {/* Updated tab container with improved spacing and alignment */}
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.tabsScrollContainer}
        >
          <View style={styles.tabsContainer}>
            <TouchableOpacity
              style={[
                styles.tabItem,
                activeTab === 'videos' && styles.activeTabItem,
              ]}
              onPress={() => setActiveTab('videos')}
            >
              <Video 
                size={18} 
                color={activeTab === 'videos' ? Colors.primary : Colors.textLight} 
              />
              <Text
                style={[
                  styles.tabText,
                  activeTab === 'videos' && styles.activeTabText,
                ]}
              >
                Videos
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.tabItem,
                activeTab === 'reels' && styles.activeTabItem,
              ]}
              onPress={() => setActiveTab('reels')}
            >
              <Film 
                size={18} 
                color={activeTab === 'reels' ? Colors.primary : Colors.textLight} 
              />
              <Text
                style={[
                  styles.tabText,
                  activeTab === 'reels' && styles.activeTabText,
                ]}
              >
                Reels
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.tabItem,
                activeTab === 'stage' && styles.activeTabItem,
              ]}
              onPress={() => setActiveTab('stage')}
            >
              <Theater 
                size={18} 
                color={activeTab === 'stage' ? Colors.primary : Colors.textLight} 
              />
              <Text
                style={[
                  styles.tabText,
                  activeTab === 'stage' && styles.activeTabText,
                ]}
              >
                Stage
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.tabItem,
                activeTab === 'playlists' && styles.activeTabItem,
              ]}
              onPress={() => setActiveTab('playlists')}
            >
              <ListVideo 
                size={18} 
                color={activeTab === 'playlists' ? Colors.primary : Colors.textLight} 
              />
              <Text
                style={[
                  styles.tabText,
                  activeTab === 'playlists' && styles.activeTabText,
                ]}
              >
                Playlists
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.tabItem,
                activeTab === 'photos' && styles.activeTabItem,
              ]}
              onPress={() => setActiveTab('photos')}
            >
              <ImageIcon 
                size={18} 
                color={activeTab === 'photos' ? Colors.primary : Colors.textLight} 
              />
              <Text
                style={[
                  styles.tabText,
                  activeTab === 'photos' && styles.activeTabText,
                ]}
              >
                Photos
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
        
        <View style={styles.tabContent}>
          {activeTab === 'videos' && (
            <>
              {userVideos.length > 0 ? (
                <View>
                  <Text style={styles.sectionTitle}>Videos • {userVideos.length}</Text>
                  {userVideos.map((video) => (
                    <VideoCard key={video.id} video={video} />
                  ))}
                </View>
              ) : (
                <View style={styles.emptyContainer}>
                  <Video size={40} color={Colors.textLight} />
                  <Text style={styles.emptyText}>No videos yet</Text>
                </View>
              )}
            </>
          )}
          
          {activeTab === 'reels' && (
            <>
              {userReels.length > 0 ? (
                <View>
                  <Text style={styles.sectionTitle}>Reels • {userReels.length}</Text>
                  <View style={styles.reelsGrid}>
                    {userReels.map((video) => (
                      <ReelCard key={video.id} video={video} fromProfile={true} />
                    ))}
                  </View>
                </View>
              ) : (
                <View style={styles.emptyContainer}>
                  <Film size={40} color={Colors.textLight} />
                  <Text style={styles.emptyText}>No reels yet</Text>
                </View>
              )}
            </>
          )}
          
          {activeTab === 'stage' && (
            <>
              {userStages.length > 0 ? (
                <View>
                  <Text style={styles.sectionTitle}>Stage • {userStages.length}</Text>
                  <ScrollView 
                    horizontal 
                    showsHorizontalScrollIndicator={false}
                    contentContainerStyle={styles.stageScrollContent}
                  >
                    {userStages.map((video) => (
                      <StageCard key={video.id} video={video} />
                    ))}
                  </ScrollView>
                  
                  {/* Premium Stage Content */}
                  {!isPremium && videos.some(v => v.userId === id && v.type === 'stage' && v.isPremium) && (
                    <View style={styles.premiumContentContainer}>
                      <View style={styles.premiumContentHeader}>
                        <Lock size={16} color={Colors.primary} />
                        <Text style={styles.premiumContentTitle}>Premium Content</Text>
                      </View>
                      <Text style={styles.premiumContentText}>
                        This creator has premium stage content that requires a subscription to view.
                      </Text>
                      <TouchableOpacity 
                        style={styles.premiumButton}
                        onPress={() => router.push('/premium')}
                      >
                        <Text style={styles.premiumButtonText}>Upgrade to Premium</Text>
                      </TouchableOpacity>
                    </View>
                  )}
                </View>
              ) : (
                <View style={styles.emptyContainer}>
                  <Theater size={40} color={Colors.textLight} />
                  <Text style={styles.emptyText}>No stage content yet</Text>
                </View>
              )}
            </>
          )}
          
          {activeTab === 'playlists' && (
            <>
              {userPlaylists.length > 0 ? (
                <View>
                  <Text style={styles.sectionTitle}>Playlists • {userPlaylists.length}</Text>
                  <View style={styles.playlistsGrid}>
                    {userPlaylists.map((playlist) => (
                      <PlaylistCard 
                        key={playlist.id} 
                        playlist={playlist} 
                        videoCount={playlist.videoIds.length}
                      />
                    ))}
                  </View>
                </View>
              ) : (
                <View style={styles.emptyContainer}>
                  <ListVideo size={40} color={Colors.textLight} />
                  <Text style={styles.emptyText}>No playlists yet</Text>
                </View>
              )}
            </>
          )}
          
          {activeTab === 'photos' && (
            <>
              {userPhotos.length > 0 ? (
                <View>
                  <Text style={styles.sectionTitle}>Photos • {userPhotos.length}</Text>
                  <View style={styles.photosGrid}>
                    {userPhotos.map((photo) => (
                      <TouchableOpacity 
                        key={photo.id} 
                        style={styles.photoItem}
                        onPress={() => handlePhotoPress(photo.id)}
                        activeOpacity={0.9}
                      >
                        <Image 
                          source={{ uri: photo.imageUrl }} 
                          style={styles.photoImage}
                        />
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>
              ) : (
                <View style={styles.emptyContainer}>
                  <ImageIcon size={40} color={Colors.textLight} />
                  <Text style={styles.emptyText}>No photos yet</Text>
                </View>
              )}
            </>
          )}
        </View>
      </ScrollView>

      {/* Collab Request Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={collabModalVisible}
        onRequestClose={handleCloseModal}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Collaboration Request</Text>
              <TouchableOpacity onPress={handleCloseModal}>
                <X size={24} color={Colors.text} />
              </TouchableOpacity>
            </View>
            
            <Text style={styles.modalSubtitle}>
              Send a collaboration request to {user.name}
            </Text>
            
            <TextInput
              style={styles.messageInput}
              placeholder="Write your collaboration request..."
              placeholderTextColor={Colors.textLight}
              multiline
              numberOfLines={4}
              value={collabMessage}
              onChangeText={setCollabMessage}
            />
            
            <TouchableOpacity 
              style={[
                styles.sendButton,
                !collabMessage.trim() && styles.sendButtonDisabled
              ]}
              onPress={handleSendCollabRequest}
              disabled={!collabMessage.trim()}
            >
              <Text style={styles.sendButtonText}>Send Request</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  notFoundContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  notFoundText: {
    fontSize: 18,
    color: Colors.text,
    marginBottom: 20,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    color: Colors.background,
    fontWeight: '500',
  },
  bannerContainer: {
    height: 150,
    position: 'relative',
  },
  banner: {
    width: '100%',
    height: '100%',
  },
  headerActions: {
    position: 'absolute',
    top: 16,
    left: 16,
    right: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  shareButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileHeader: {
    alignItems: 'center',
    paddingHorizontal: 16,
    marginTop: -50,
  },
  avatarContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    borderWidth: 4,
    borderColor: Colors.background,
    overflow: 'hidden',
    marginBottom: 16,
  },
  avatar: {
    width: '100%',
    height: '100%',
  },
  userName: {
    fontSize: 22,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 4,
  },
  verifiedBadge: {
    color: Colors.primary,
  },
  userHandle: {
    fontSize: 16,
    color: Colors.textLight,
    marginBottom: 16,
  },
  statsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  statItem: {
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  statValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
  },
  statLabel: {
    fontSize: 14,
    color: Colors.textLight,
  },
  statDivider: {
    width: 1,
    height: 24,
    backgroundColor: Colors.border,
  },
  bioContainer: {
    width: '100%',
    marginBottom: 12,
  },
  bioText: {
    fontSize: 14,
    color: Colors.text,
    lineHeight: 20,
    textAlign: 'center',
  },
  readMoreText: {
    fontSize: 14,
    color: Colors.primary,
    fontWeight: '500',
  },
  websiteContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  websiteText: {
    fontSize: 14,
    color: Colors.primary,
    marginLeft: 6,
  },
  actionButtonsContainer: {
    flexDirection: 'row',
    marginBottom: 24,
  },
  followButton: {
    paddingHorizontal: 24,
    paddingVertical: 10,
    backgroundColor: Colors.primary,
    borderRadius: 20,
    marginRight: 12,
  },
  followingButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: Colors.border,
  },
  followButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.background,
  },
  followingButtonText: {
    color: Colors.text,
  },
  collabButton: {
    paddingHorizontal: 24,
    paddingVertical: 10,
    backgroundColor: Colors.secondary,
    borderRadius: 20,
    marginRight: 12,
  },
  collabButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.background,
  },
  bellButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.card,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.border,
  },
  // Updated tab styles for better spacing and alignment
  tabsScrollContainer: {
    paddingHorizontal: 0,
  },
  tabsContainer: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
    width: '100%',
    justifyContent: 'space-around',
  },
  tabItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    minWidth: 80,
    gap: 6,
  },
  activeTabItem: {
    borderBottomWidth: 2,
    borderBottomColor: Colors.primary,
  },
  tabText: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.textLight,
  },
  activeTabText: {
    color: Colors.primary,
    fontWeight: '600',
  },
  tabContent: {
    padding: 16,
    paddingBottom: 32,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 16,
  },
  reelsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  stageScrollContent: {
    paddingBottom: 16,
  },
  playlistsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  photosGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  photoItem: {
    width: (width - 40) / 3,
    height: (width - 40) / 3,
    marginBottom: 8,
    borderRadius: 8,
    overflow: 'hidden',
  },
  photoImage: {
    width: '100%',
    height: '100%',
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyText: {
    fontSize: 16,
    color: Colors.textLight,
    marginTop: 16,
  },
  premiumContentContainer: {
    marginTop: 24,
    padding: 16,
    backgroundColor: Colors.card,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  premiumContentHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    gap: 8,
  },
  premiumContentTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.primary,
  },
  premiumContentText: {
    fontSize: 14,
    color: Colors.text,
    marginBottom: 16,
    lineHeight: 20,
  },
  premiumButton: {
    backgroundColor: Colors.primary,
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  premiumButtonText: {
    color: Colors.background,
    fontWeight: '600',
    fontSize: 14,
  },
  // Modal styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: '90%',
    backgroundColor: Colors.background,
    borderRadius: 12,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
  },
  modalSubtitle: {
    fontSize: 14,
    color: Colors.textLight,
    marginBottom: 16,
  },
  messageInput: {
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    padding: 12,
    height: 120,
    textAlignVertical: 'top',
    marginBottom: 16,
    color: Colors.text,
  },
  sendButton: {
    backgroundColor: Colors.primary,
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  sendButtonDisabled: {
    backgroundColor: Colors.border,
  },
  sendButtonText: {
    color: Colors.background,
    fontWeight: '600',
    fontSize: 16,
  },
});