import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Image, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useRouter } from 'expo-router';
import { Search, Check, X } from 'lucide-react-native';
import { users } from '@/mocks/users';
import { formatTimeAgo } from '@/utils/format';
import Colors from '@/constants/colors';
import Header from '@/components/Header';

// Define types for our data
interface Message {
  id: string;
  userId: string;
  lastMessage: string;
  timestamp: string;
  unread: boolean;
}

interface CollabRequest {
  id: string;
  userId: string;
  message: string;
  timestamp: string;
  status: 'pending' | 'accepted' | 'declined';
}

// Mock messages data
const messages: Message[] = [
  {
    id: '1',
    userId: '2',
    lastMessage: "Hey, I loved your latest video! Would you be interested in a collab?",
    timestamp: '2023-10-15T14:30:00Z',
    unread: true,
  },
  {
    id: '2',
    userId: '3',
    lastMessage: "Thanks for the feedback on my underwater photography!",
    timestamp: '2023-10-14T09:15:00Z',
    unread: false,
  },
  {
    id: '3',
    userId: '4',
    lastMessage: "Let's discuss the details of our ocean conservation project.",
    timestamp: '2023-10-12T18:45:00Z',
    unread: false,
  },
  {
    id: '4',
    userId: '5',
    lastMessage: "I'll send you the equipment list for the dive tomorrow.",
    timestamp: '2023-10-10T12:00:00Z',
    unread: false,
  },
];

// Mock collab requests data
const collabRequests: CollabRequest[] = [
  {
    id: '1',
    userId: '2',
    message: "I'd love to collaborate on an underwater photography tutorial. Let me know if you're interested!",
    timestamp: '2023-10-15T14:30:00Z',
    status: 'pending',
  },
  {
    id: '2',
    userId: '3',
    message: "Would you like to join me for a live stream about marine conservation next week?",
    timestamp: '2023-10-14T09:15:00Z',
    status: 'pending',
  },
  {
    id: '3',
    userId: '4',
    message: "Let's create a series about the Great Barrier Reef together. I have some amazing footage to share.",
    timestamp: '2023-10-12T18:45:00Z',
    status: 'accepted',
  },
  {
    id: '4',
    userId: '5',
    message: "I saw your surfing videos and would love to feature you in my upcoming documentary about ocean sports.",
    timestamp: '2023-10-10T12:00:00Z',
    status: 'declined',
  },
];

export default function MessagesHubScreen() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState('messages');
  const [searchQuery, setSearchQuery] = useState('');
  const [requests, setRequests] = useState(collabRequests);
  const [collabFilter, setCollabFilter] = useState('pending');
  
  const filteredMessages = searchQuery && activeTab === 'messages'
    ? messages.filter(message => {
        const user = users.find(u => u.id === message.userId);
        return user?.name.toLowerCase().includes(searchQuery.toLowerCase());
      })
    : messages;
  
  const filteredRequests = requests.filter(request => {
    if (searchQuery) {
      const user = users.find(u => u.id === request.userId);
      if (!user?.name.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false;
      }
    }
    
    if (collabFilter === 'pending') return request.status === 'pending';
    if (collabFilter === 'accepted') return request.status === 'accepted';
    if (collabFilter === 'declined') return request.status === 'declined';
    return true;
  });
  
  const handleAccept = (id: string) => {
    setRequests(requests.map(request => 
      request.id === id ? { ...request, status: 'accepted' } : request
    ));
  };
  
  const handleDecline = (id: string) => {
    setRequests(requests.map(request => 
      request.id === id ? { ...request, status: 'declined' } : request
    ));
  };
  
  const renderMessageItem = ({ item }: { item: Message }) => {
    const user = users.find(u => u.id === item.userId);
    
    if (!user) return null;
    
    return (
      <TouchableOpacity style={styles.messageItem}>
        <View style={styles.avatarContainer}>
          <Image source={{ uri: user.avatar }} style={styles.avatar} />
          {item.unread && <View style={styles.unreadBadge} />}
        </View>
        
        <View style={styles.messageContent}>
          <View style={styles.messageHeader}>
            <Text style={styles.username}>{user.name}</Text>
            <Text style={styles.timestamp}>{formatTimeAgo(item.timestamp)}</Text>
          </View>
          <Text 
            style={[
              styles.lastMessage,
              item.unread && styles.unreadMessage
            ]}
            numberOfLines={1}
          >
            {item.lastMessage}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };
  
  const renderRequestItem = ({ item }: { item: CollabRequest }) => {
    const user = users.find(u => u.id === item.userId);
    
    if (!user) return null;
    
    return (
      <View style={styles.requestItem}>
        <View style={styles.requestHeader}>
          <View style={styles.userInfo}>
            <Image source={{ uri: user.avatar }} style={styles.avatar} />
            <View>
              <Text style={styles.username}>{user.name}</Text>
              <Text style={styles.timestamp}>{formatTimeAgo(item.timestamp)}</Text>
            </View>
          </View>
          
          {item.status === 'pending' && (
            <View style={styles.actionButtons}>
              <TouchableOpacity 
                style={[styles.actionButton, styles.acceptButton]}
                onPress={() => handleAccept(item.id)}
              >
                <Check size={16} color={Colors.background} />
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[styles.actionButton, styles.declineButton]}
                onPress={() => handleDecline(item.id)}
              >
                <X size={16} color={Colors.background} />
              </TouchableOpacity>
            </View>
          )}
          
          {item.status === 'accepted' && (
            <View style={styles.statusBadge}>
              <Text style={styles.statusText}>Accepted</Text>
            </View>
          )}
          
          {item.status === 'declined' && (
            <View style={[styles.statusBadge, styles.declinedBadge]}>
              <Text style={[styles.statusText, styles.declinedText]}>Declined</Text>
            </View>
          )}
        </View>
        
        <Text style={styles.message}>{item.message}</Text>
        
        {item.status === 'accepted' && (
          <TouchableOpacity style={styles.messageButton}>
            <Text style={styles.messageButtonText}>Message</Text>
          </TouchableOpacity>
        )}
      </View>
    );
  };
  
  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar style="dark" />
      
      <Header showBackButton onBackPress={() => router.back()} />
      
      <View style={styles.tabsContainer}>
        <TouchableOpacity
          style={[
            styles.tabItem,
            activeTab === 'messages' && styles.activeTabItem,
          ]}
          onPress={() => setActiveTab('messages')}
        >
          <Text
            style={[
              styles.tabText,
              activeTab === 'messages' && styles.activeTabText,
            ]}
          >
            Chats
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.tabItem,
            activeTab === 'requests' && styles.activeTabItem,
          ]}
          onPress={() => setActiveTab('requests')}
        >
          <Text
            style={[
              styles.tabText,
              activeTab === 'requests' && styles.activeTabText,
            ]}
          >
            Collab Requests
          </Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.searchContainer}>
        <View style={styles.searchInputContainer}>
          <Search size={20} color={Colors.textLight} style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder={activeTab === 'messages' ? "Search messages" : "Search collab requests"}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
      </View>
      
      {activeTab === 'requests' && (
        <View style={styles.collabFiltersContainer}>
          <TouchableOpacity
            style={[
              styles.collabFilterItem,
              collabFilter === 'pending' && styles.activeCollabFilter,
            ]}
            onPress={() => setCollabFilter('pending')}
          >
            <Text
              style={[
                styles.collabFilterText,
                collabFilter === 'pending' && styles.activeCollabFilterText,
              ]}
            >
              Pending
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.collabFilterItem,
              collabFilter === 'accepted' && styles.activeCollabFilter,
            ]}
            onPress={() => setCollabFilter('accepted')}
          >
            <Text
              style={[
                styles.collabFilterText,
                collabFilter === 'accepted' && styles.activeCollabFilterText,
              ]}
            >
              Accepted
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.collabFilterItem,
              collabFilter === 'declined' && styles.activeCollabFilter,
            ]}
            onPress={() => setCollabFilter('declined')}
          >
            <Text
              style={[
                styles.collabFilterText,
                collabFilter === 'declined' && styles.activeCollabFilterText,
              ]}
            >
              Declined
            </Text>
          </TouchableOpacity>
        </View>
      )}
      
      {activeTab === 'messages' ? (
        <FlatList
          data={filteredMessages}
          keyExtractor={(item) => item.id}
          renderItem={renderMessageItem}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Text style={styles.emptyText}>No messages found</Text>
            </View>
          }
        />
      ) : (
        <FlatList
          data={filteredRequests}
          keyExtractor={(item) => item.id}
          renderItem={renderRequestItem}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.listContent}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Text style={styles.emptyText}>
                {collabFilter === 'pending' 
                  ? 'No pending collaboration requests' 
                  : collabFilter === 'accepted'
                  ? 'No accepted collaborations yet'
                  : 'No declined collaborations'
                }
              </Text>
            </View>
          }
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  tabsContainer: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  tabItem: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
  },
  activeTabItem: {
    borderBottomWidth: 2,
    borderBottomColor: Colors.primary,
  },
  tabText: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.textLight,
  },
  activeTabText: {
    color: Colors.primary,
  },
  searchContainer: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  searchInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.card,
    borderRadius: 24,
    paddingHorizontal: 16,
    height: 40,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: Colors.text,
  },
  collabFiltersContainer: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  collabFilterItem: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
  },
  activeCollabFilter: {
    borderBottomWidth: 2,
    borderBottomColor: Colors.primary,
  },
  collabFilterText: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.textLight,
  },
  activeCollabFilterText: {
    color: Colors.primary,
  },
  messageItem: {
    flexDirection: 'row',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  avatarContainer: {
    position: 'relative',
    marginRight: 12,
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  unreadBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: Colors.primary,
    borderWidth: 2,
    borderColor: Colors.background,
  },
  messageContent: {
    flex: 1,
    justifyContent: 'center',
  },
  messageHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  username: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.text,
  },
  timestamp: {
    fontSize: 12,
    color: Colors.textLight,
  },
  lastMessage: {
    fontSize: 14,
    color: Colors.textLight,
  },
  unreadMessage: {
    color: Colors.text,
    fontWeight: '500',
  },
  listContent: {
    padding: 16,
  },
  requestItem: {
    backgroundColor: Colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  requestHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  actionButtons: {
    flexDirection: 'row',
  },
  actionButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 8,
  },
  acceptButton: {
    backgroundColor: Colors.success,
  },
  declineButton: {
    backgroundColor: Colors.error,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    backgroundColor: Colors.success,
    borderRadius: 12,
  },
  declinedBadge: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: Colors.error,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '500',
    color: Colors.background,
  },
  declinedText: {
    color: Colors.error,
  },
  message: {
    fontSize: 14,
    color: Colors.text,
    marginBottom: 16,
    lineHeight: 20,
  },
  messageButton: {
    alignSelf: 'flex-start',
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: Colors.primary,
    borderRadius: 16,
  },
  messageButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.background,
  },
  emptyContainer: {
    padding: 32,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: Colors.textLight,
    textAlign: 'center',
  },
});